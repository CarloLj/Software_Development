package com.chris.project.Activities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.chris.project.R;

public class SignupActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
    }
}
