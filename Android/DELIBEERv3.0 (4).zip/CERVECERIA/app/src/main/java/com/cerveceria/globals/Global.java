package com.cerveceria.globals;

import com.cerveceria.POJOs.*;

import java.util.ArrayList;

public class Global {
    public static OrdenPOJO orden = new OrdenPOJO();
    public static ClientePOJO usuario = new ClientePOJO();
    public static ArrayList<CarritoPOJO> carrito = new ArrayList<>();
}
