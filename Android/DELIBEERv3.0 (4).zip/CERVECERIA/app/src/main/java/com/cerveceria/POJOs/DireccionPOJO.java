package com.cerveceria.POJOs;

public class DireccionPOJO {
    private int iid, numeroext, numeroint, idcliente;
    private String nombredest, apellidodest, telefono, codigopostal, colonia, calle, referencias;

    public int getIid() {
        return iid;
    }

    public void setIid(int iid) {
        this.iid = iid;
    }

    public int getNumeroext() {
        return numeroext;
    }

    public void setNumeroext(int numeroext) {
        this.numeroext = numeroext;
    }

    public int getNumeroint() {
        return numeroint;
    }

    public void setNumeroint(int numeroint) {
        this.numeroint = numeroint;
    }

    public int getIdcliente() {
        return idcliente;
    }

    public void setIdcliente(int idcliente) {
        this.idcliente = idcliente;
    }

    public String getNombredest() {
        return nombredest;
    }

    public void setNombredest(String nombredest) {
        this.nombredest = nombredest;
    }

    public String getApellidodest() {
        return apellidodest;
    }

    public void setApellidodest(String apellidodest) {
        this.apellidodest = apellidodest;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getCodigopostal() {
        return codigopostal;
    }

    public void setCodigopostal(String codigopostal) {
        this.codigopostal = codigopostal;
    }

    public String getColonia() {
        return colonia;
    }

    public void setColonia(String colonia) {
        this.colonia = colonia;
    }

    public String getCalle() {
        return calle;
    }

    public void setCalle(String calle) {
        this.calle = calle;
    }

    public String getReferencias() {
        return referencias;
    }

    public void setReferencias(String referencias) {
        this.referencias = referencias;
    }
}
