package com.example.practica_3;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.Toast;

import Global.Globales;
import POJOS.Persona;


public class AddActivity extends AppCompatActivity {
EditText Nombre,ApellidoP,ApellidoM,Telefono;
ImageButton Enviar;
RadioButton Femenino,Masculino;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        Nombre=findViewById(R.id.Nombre);
        ApellidoP=findViewById(R.id.Paterno);
        ApellidoM=findViewById(R.id.Materno);
        Telefono=findViewById(R.id.Telefono);
        Femenino=findViewById(R.id.radioButton);
        Masculino=findViewById(R.id.radioButton2);
        Enviar = findViewById(R.id.SEND);


}

    public void Guardar(View view){
        Persona nuevaPersona= new Persona();

        nuevaPersona.setNombre(Nombre.getText().toString());
        nuevaPersona.setApellidoP(ApellidoP.getText().toString());
        nuevaPersona.setApellidoM(ApellidoM.getText().toString());
        nuevaPersona.setTelefono(Telefono.getText().toString());

        if(Femenino.isChecked()){
            nuevaPersona.setSexo(true);
        }
        else if (Masculino.isChecked()){
            nuevaPersona.setSexo(false);
        }

        Globales.Registro.add(nuevaPersona);

        Toast toast = Toast.makeText(getApplicationContext(),"Guardado!",Toast.LENGTH_SHORT);
        toast.setGravity(Gravity.CENTER,0,0);
        toast.show();




        finish();


    }
}
