package com.example.practica_3;

import android.Manifest;
import android.app.AppComponentFactory;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;

import Global.Globales;

public class Perfil extends AppCompatActivity {
    TextView nombre, apellido_p,apellido_m,telefono;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.perfil);

        nombre = findViewById(R.id.nombre);
        apellido_p = findViewById(R.id.apellido_p);
        apellido_m = findViewById(R.id.apellido_m);
        telefono = findViewById(R.id.telefono);

        int pos;
        pos = getIntent().getIntExtra("posicion",-1);

        nombre.setText(Globales.Registro.get(pos).getNombre());
        apellido_p.setText(Globales.Registro.get(pos).getApellidoP());
        apellido_m.setText(Globales.Registro.get(pos).getApellidoM());
        telefono.setText(Globales.Registro.get(pos).getTelefono());



    }

    public void llamar(View view){
        Intent llamada = new Intent(Intent.ACTION_CALL, Uri.parse("tel:"+ telefono.getText().toString()));

        if(ActivityCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CALL_PHONE},10);
            return;
        }
        startActivity(llamada);
    }
}
