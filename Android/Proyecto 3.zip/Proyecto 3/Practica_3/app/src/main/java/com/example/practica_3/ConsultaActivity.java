package com.example.practica_3;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.example.practica_3.Adaptadores.Adaptador_Consulta;

public class ConsultaActivity extends AppCompatActivity {
    RecyclerView rv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_consulta);

        rv = findViewById(R.id.LISTA);

        Adaptador_Consulta adaptador_consulta = new Adaptador_Consulta();

        adaptador_consulta.context = this;

        LinearLayoutManager llm = new LinearLayoutManager(this,LinearLayoutManager.VERTICAL,false);

        rv.setLayoutManager(llm);
        rv.setAdapter(adaptador_consulta);
    }
}
