package com.example.practica_3;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class LoginAcivity extends AppCompatActivity {

    Button ok;
    EditText usuario, contra;
    SharedPreferences archivo;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        ok = findViewById(R.id.ok);
        usuario = findViewById(R.id.usario_login);
        contra = findViewById(R.id.contraseña_login);

        archivo = this.getSharedPreferences("SUPERARCHIVO", Context.MODE_PRIVATE);

        if(archivo.contains("usuario")){
            Intent i= new Intent(this, MainActivity.class);
            startActivity(i);
        }

        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ingresar();
            }
        });
    }

    public void ingresar(){
        if(usuario.getText().toString().equals("Angel") && contra.getText().toString().equals("contraseña123")){
            Intent i= new Intent(this, MainActivity.class);


            SharedPreferences.Editor editor = archivo.edit();
            editor.putString("usuario","Angel");
            editor.putString("contraseña","contraseña123");
            editor.putBoolean("validar",true);
            editor.commit();

            startActivity(i);
            finish();
        }else{
            usuario.setText("");
            contra.setText("");
        }

    }
}
