package Global;

import java.util.ArrayList;

import POJOS.Persona;

public class Globales {
    public static final ArrayList<Persona> Registro = new ArrayList<>();
    public static final ArrayList<String> Imagenes = new ArrayList<>();
}
