package com.example.practica_3.Adaptadores;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.practica_3.Perfil;
import com.example.practica_3.R;
import com.squareup.picasso.Picasso;

import java.util.Random;

import Global.Globales;

public class Adaptador_Consulta extends RecyclerView.Adapter<Adaptador_Consulta.Miniactivity> {
    public Context context;


    @NonNull
    @Override
    public Miniactivity onCreateViewHolder(@NonNull ViewGroup viewGroup, int i){
        View v=View.inflate(context,R.layout.mivista,null);
        Miniactivity obj= new Miniactivity(v);
        return obj;
    }


    int x = 0;
    @Override
    public void onBindViewHolder(@NonNull Adaptador_Consulta.Miniactivity miniactivity, int i) {
        final int indice = i;

        miniactivity.Nombre.setText(Globales.Registro.get(i).getNombre());
        miniactivity.Nombre.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent a= new Intent(context, Perfil.class);
                a.putExtra("posicion",indice);
                context.startActivity(a);
            }

        });

        if(x == Globales.Imagenes.size() -1 ){
            x = 0;
        }
            Picasso.get()
                    .load(Globales.Imagenes.get(x++))
                    .into(miniactivity.imagen);
    }



    @Override
    public int getItemCount() {

        return Globales.Registro.size();

    }

    class Miniactivity extends RecyclerView.ViewHolder{
        public TextView Nombre;
        public ImageView imagen;


        public Miniactivity(@NonNull View itemView) {
            super(itemView);

            Nombre=itemView.findViewById(R.id.nombre_vista);
            imagen=itemView.findViewById(R.id.imagen_vista);
        }
    }
}
