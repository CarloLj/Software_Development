package com.example.practica_3;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

import Global.Globales;

public class MainActivity extends AppCompatActivity {
    Button Alta, Consultas;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        Alta= findViewById(R.id.Altas);
        Consultas=findViewById(R.id.Consulta);

        Globales.Imagenes.add("https://www.recreoviral.com/wp-content/uploads/2015/07/Cara-de-Nicolas-Cage-en-los-personajes-de-Game-Of-Thrones-7.jpg");
        Globales.Imagenes.add("https://as01.epimg.net/us/imagenes/2019/04/23/tikitakas/1555971301_854257_1555971434_noticia_normal.jpg");
        Globales.Imagenes.add("https://pbs.twimg.com/profile_images/901947348699545601/hqRMHITj_400x400.jpg");
        Globales.Imagenes.add("https://www.recreoviral.com/wp-content/uploads/2015/07/Cara-de-Nicolas-Cage-en-los-personajes-de-Game-Of-Thrones-4.jpg");
        Globales.Imagenes.add("https://www.recreoviral.com/wp-content/uploads/2015/07/Cara-de-Nicolas-Cage-en-los-personajes-de-Game-Of-Thrones-13.jpg");
        Globales.Imagenes.add("https://e.rpp-noticias.io/medium/2016/05/24/1499761jpg.jpg");
        Globales.Imagenes.add("https://www.recreoviral.com/wp-content/uploads/2015/07/Cara-de-Nicolas-Cage-en-los-personajes-de-Game-Of-Thrones-8.jpg");


    }

    public void Altas(View view) {
        Intent i= new Intent(MainActivity.this, AddActivity.class);
        startActivity(i);
    }

    public void Consultas(View view) {
        Intent j= new Intent(MainActivity.this, ConsultaActivity.class);
        startActivity(j);
    }
}
