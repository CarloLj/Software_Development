package com.Carlo.Lujan;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class ResultActivity extends AppCompatActivity {

    TextView SAL1, SAL2, SAL3, SAL4;
    String a,b,c,d,x,y;
    float SUMAF1YF2, MULTIPLICATIVO, TOLERANCIA, MAXx, MINn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        SAL1 = findViewById(R.id.RESULTADO);
        SAL2 = findViewById(R.id.RESULTADO2);
        SAL3 = findViewById(R.id.MAX);
        SAL4 = findViewById(R.id.MIN);

        result();
    }

    public void result(){
        a = getIntent().getExtras().getString("RESULTADOFRANJA1");
        b = getIntent().getExtras().getString("RESULTADOFRANJA2");
        c = getIntent().getExtras().getString("RESULTADOFRANJA3");
        d = getIntent().getExtras().getString("RESULTADOFRANJA4");

        SUMAF1YF2 = Float.parseFloat(a+b);
        MULTIPLICATIVO = Float.parseFloat(c);
        TOLERANCIA = Float.parseFloat(d);

        if(MULTIPLICATIVO == 0){ //negro
            SUMAF1YF2 = SUMAF1YF2 *1;
            x = "Ω";
        }
        if(MULTIPLICATIVO == 1){ //cafe
            SUMAF1YF2 = SUMAF1YF2 *10;
            x = "Ω";
        }
        if(MULTIPLICATIVO == 2){ //rojo
            SUMAF1YF2 = SUMAF1YF2 /10;
            x = "KΩ";
        }
        if(MULTIPLICATIVO == 3){ //naranja
            SUMAF1YF2 = SUMAF1YF2 *1;
            x = "KΩ";
        }
        if(MULTIPLICATIVO == 4){ //amarillo
            SUMAF1YF2 = SUMAF1YF2 *10;
            x = "KΩ";
        }
        if(MULTIPLICATIVO == 5){ //verde
            SUMAF1YF2 = SUMAF1YF2 /10;
            x = "MΩ";
        }
        if(MULTIPLICATIVO == 6){ //azul
            SUMAF1YF2 = SUMAF1YF2 *1;
            x = "MΩ";
        }
        if(MULTIPLICATIVO == 7){ //morado
            SUMAF1YF2 = SUMAF1YF2 *10;
            x = "MΩ";
        }
        if(MULTIPLICATIVO == 8){ //gris
            SUMAF1YF2 = SUMAF1YF2 /10;
            x = "GΩ";
        }
        if(MULTIPLICATIVO == 9){ //blanco
            SUMAF1YF2 = SUMAF1YF2 *1;
            x = "GΩ";
        }
        if(MULTIPLICATIVO == 10){ //dorado
            SUMAF1YF2 = SUMAF1YF2 /10;
            x = "Ω";
        }
        if(MULTIPLICATIVO == 11){ //plateado
            SUMAF1YF2 = SUMAF1YF2 /100;
            x = "Ω";
        }

        if(TOLERANCIA == 1){
            y = "±1%" ;
            MINn =  SUMAF1YF2 - (SUMAF1YF2 /100);
            MAXx = (SUMAF1YF2 /100) + SUMAF1YF2;
        }
        if(TOLERANCIA == 2){
            y = "±2%" ;
            MINn =  SUMAF1YF2 - (SUMAF1YF2 /50);
            MAXx = (SUMAF1YF2 /50) + SUMAF1YF2;
        }
        if(TOLERANCIA == 4){
            y = "±5%" ;
            MINn =  SUMAF1YF2 - (SUMAF1YF2 /20);
            MAXx = (SUMAF1YF2 /20) + SUMAF1YF2;
        }
        if(TOLERANCIA == 5){
            y = "±0.5%" ;
            MINn =  SUMAF1YF2 - (SUMAF1YF2 /200);
            MAXx = (SUMAF1YF2 /200) + SUMAF1YF2;
        }
        if(TOLERANCIA == 6){
            y = "±0.25%" ;
            MINn =  SUMAF1YF2 - (SUMAF1YF2 /400);
            MAXx = (SUMAF1YF2 /400) + SUMAF1YF2;
        }
        if(TOLERANCIA == 7){
            y = "±0.1%" ;
            MINn =  SUMAF1YF2 - (SUMAF1YF2 /1000);
            MAXx = (SUMAF1YF2 /1000) + SUMAF1YF2;
        }
        if(TOLERANCIA == 8){
            y = "±0.05%" ;
            MINn =  SUMAF1YF2 - (SUMAF1YF2 /2000);
            MAXx = (SUMAF1YF2 /2000) + SUMAF1YF2;
        }
        if(TOLERANCIA == 10){
            y = "±5%" ;
            MINn =  SUMAF1YF2 - (SUMAF1YF2 /20);
            MAXx = (SUMAF1YF2 /20) + SUMAF1YF2;
        }
        if(TOLERANCIA == 11){
            y = "±10%" ;
            MINn =  SUMAF1YF2 - (SUMAF1YF2 /10);
            MAXx = (SUMAF1YF2 /10) + SUMAF1YF2;
        }
        SAL1.setText(""+ SUMAF1YF2 +" "+x);
        SAL2.setText(y);
        SAL3.setText("" + MAXx +" "+ x +" Maximo");
        SAL4.setText("" + MINn +" "+ x +" Minimo");
    }
}


