package com.Carlo.Lujan;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.view.View.OnClickListener;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    boolean F1SELEC = false, F2SELEC = false, F3SELEC = false, F4SELEC = false;
    boolean F1ASIGN = false, F2ASIGN = false, F3ASIGN = false, F4ASIGN = false;
    Button F1, F2, F3, F4, CALCULAR;
    Button NEGRO, CAFE, ROJO, AMARILLO, NARANJA, VERDE, AZUL, BLANCO, DORADO, PLATEADO, MORADO, GRIS;
    TextView MODO, VF1, VF2, VF3, VF4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final Intent i = new Intent(this, ResultActivity.class);

        CALCULAR = findViewById(R.id.igual);
        F1 = findViewById(R.id.BANDA1);
        F2 = findViewById(R.id.BANDA2);
        F3 = findViewById(R.id.BANDA3);
        F4 = findViewById(R.id.BANDA4);
        NEGRO = findViewById(R.id.negro);
        CAFE = findViewById(R.id.cafe);
        ROJO = findViewById(R.id.rojo);
        NARANJA = findViewById(R.id.naranja);
        AMARILLO = findViewById(R.id.amarillo);
        VERDE = findViewById(R.id.verde);
        AZUL = findViewById(R.id.azul);
        BLANCO = findViewById(R.id.blanco);
        GRIS = findViewById(R.id.gris);
        DORADO = findViewById(R.id.dorado);
        PLATEADO = findViewById(R.id.plateado);
        MORADO = findViewById(R.id.morado);
        MODO = findViewById(R.id.modo);

        VF1 = findViewById(R.id.VALOR_F1);
        VF2 = findViewById(R.id.VALOR_F2);
        VF3 = findViewById(R.id.VALOR_F3);
        VF4 = findViewById(R.id.VALOR_F4);

       CALCULAR.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {

                if (F1ASIGN=false) {
                    Toast.makeText(MainActivity.this,"Hace falta FRANJA 1", Toast.LENGTH_SHORT).show();
                }else if(F2ASIGN=false) {
                    Toast.makeText(MainActivity.this,"Hace falta FRANJA 2", Toast.LENGTH_SHORT).show();
                }else if(F3ASIGN=false) {
                    Toast.makeText(MainActivity.this, "Hace falta FRANJA 3", Toast.LENGTH_SHORT).show();
                }else if(F4ASIGN=false) {
                        Toast.makeText(MainActivity.this,"Hace falta FRANJA 4", Toast.LENGTH_SHORT).show();
                }else if((F1ASIGN=true)||(F2ASIGN=true)||(F3ASIGN=true)||(F4ASIGN=true)){
                    i.putExtra("RESULTADOFRANJA1", VF1.getText().toString());
                    i.putExtra("RESULTADOFRANJA2", VF2.getText().toString());
                    i.putExtra("RESULTADOFRANJA3", VF3.getText().toString());
                    i.putExtra("RESULTADOFRANJA4", VF4.getText().toString());
                    startActivity(i);
                }

            }
        });

        F1.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                F1SELEC = true;
                F2SELEC = false;
                F3SELEC = false;
                F4SELEC = false;

                MODO.setText("FRANJA 1");

                NEGRO.setVisibility(View.VISIBLE);CAFE.setVisibility(View.VISIBLE);ROJO.setVisibility(View.VISIBLE);
                NARANJA.setVisibility(View.VISIBLE);AMARILLO.setVisibility(View.VISIBLE);VERDE.setVisibility(View.VISIBLE);
                AZUL.setVisibility(View.VISIBLE);MORADO.setVisibility(View.VISIBLE);GRIS.setVisibility(View.VISIBLE);
                BLANCO.setVisibility(View.VISIBLE);DORADO.setVisibility(View.INVISIBLE);PLATEADO.setVisibility(View.INVISIBLE);

                NEGRO.setText("0");CAFE.setText("1");
                ROJO.setText("2");NARANJA.setText("3");
                AMARILLO.setText("4");VERDE.setText("5");
                AZUL.setText("6");MORADO.setText("7");
                GRIS.setText("8");BLANCO.setText("9");
            }
        });


        F2.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                F1SELEC = false;
                F2SELEC = true;
                F3SELEC = false;
                F4SELEC = false;

                MODO.setText("FRANJA 2");

                NEGRO.setVisibility(View.VISIBLE);CAFE.setVisibility(View.VISIBLE);ROJO.setVisibility(View.VISIBLE);
                NARANJA.setVisibility(View.VISIBLE);AMARILLO.setVisibility(View.VISIBLE);VERDE.setVisibility(View.VISIBLE);
                AZUL.setVisibility(View.VISIBLE);MORADO.setVisibility(View.VISIBLE);GRIS.setVisibility(View.VISIBLE);
                BLANCO.setVisibility(View.VISIBLE);DORADO.setVisibility(View.INVISIBLE);PLATEADO.setVisibility(View.INVISIBLE);

                NEGRO.setText("0");CAFE.setText("1");
                ROJO.setText("2");NARANJA.setText("3");
                AMARILLO.setText("4");VERDE.setText("5");
                AZUL.setText("6");MORADO.setText("7");
                GRIS.setText("8");BLANCO.setText("9");
            }
        });

        F3.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                F1SELEC = false;
                F2SELEC = false;
                F3SELEC = true;
                F4SELEC = false;

                MODO.setText("Multiplicativo");

                NEGRO.setVisibility(View.VISIBLE);CAFE.setVisibility(View.VISIBLE);
                ROJO.setVisibility(View.VISIBLE);NARANJA.setVisibility(View.VISIBLE);
                AMARILLO.setVisibility(View.VISIBLE);VERDE.setVisibility(View.VISIBLE);
                AZUL.setVisibility(View.VISIBLE);MORADO.setVisibility(View.VISIBLE);
                GRIS.setVisibility(View.VISIBLE);BLANCO.setVisibility(View.VISIBLE);
                DORADO.setVisibility(View.VISIBLE);PLATEADO.setVisibility(View.VISIBLE);

                NEGRO.setText("x10^0");CAFE.setText("x10^1");
                ROJO.setText("x10^2");NARANJA.setText("x10^3");
                AMARILLO.setText("x10^4");VERDE.setText("x10^5");
                AZUL.setText("x10^6");MORADO.setText("x10^7");
                GRIS.setText("x10^8");BLANCO.setText("x10^9");
                DORADO.setText("x10^-1");PLATEADO.setText("x10^-2");
            }
        });

        F4.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                F1SELEC = false;
                F2SELEC = false;
                F3SELEC = false;
                F4SELEC = true;

                MODO.setText("Tolerancia");

                NEGRO.setVisibility(View.INVISIBLE);CAFE.setVisibility(View.VISIBLE);ROJO.setVisibility(View.VISIBLE);
                NARANJA.setVisibility(View.INVISIBLE);AMARILLO.setVisibility(View.VISIBLE);VERDE.setVisibility(View.VISIBLE);
                AZUL.setVisibility(View.VISIBLE);MORADO.setVisibility(View.VISIBLE);GRIS.setVisibility(View.VISIBLE);
                BLANCO.setVisibility(View.INVISIBLE);DORADO.setVisibility(View.VISIBLE);PLATEADO.setVisibility(View.VISIBLE);

                CAFE.setText("±1%");ROJO.setText("±2%");
                AMARILLO.setText("±5%");VERDE.setText("±0.5%");
                AZUL.setText("±0.25%");MORADO.setText("±0.1%");
                GRIS.setText("±0.05%");DORADO.setText("±5%");
                PLATEADO.setText("±10%");

            }
        });
    }


    public void setBlack(View view) {
         if (F1SELEC) {
             F1.setBackgroundColor(Color.parseColor("#000000"));
            VF1.setText("0");
            F1ASIGN = true;
         } else if (F2SELEC) {
           F2.setBackgroundColor(Color.parseColor("#000000"));
           VF2.setText("0");
            F2ASIGN = true;
         } else if (F3SELEC) {
            F3.setBackgroundColor(Color.parseColor("#000000"));
           VF3.setText("0");
            F3ASIGN = true;
        } else if (F4SELEC) {
             F4.setBackgroundColor(Color.parseColor("#000000"));
            VF4.setText("0");
            F4ASIGN = true;
         }
    }

    public void setBrown(View view) {
         if (F1SELEC) {
            F1.setBackgroundColor(Color.parseColor("#6d5e24"));
            VF1.setText("1");
            F1ASIGN = true;
         } else if (F2SELEC) {
             F2.setBackgroundColor(Color.parseColor("#6d5e24"));
           VF2.setText("1");
            F2ASIGN = true;
        } else if (F3SELEC) {
           F3.setBackgroundColor(Color.parseColor("#6d5e24"));
           VF3.setText("1");
           F3ASIGN = true;
        } else if (F4SELEC) {
           F4.setBackgroundColor(Color.parseColor("#6d5e24"));
           VF4.setText("1");
           F4ASIGN = true;
        }
    }

    public void setRed(View view) {
        if (F1SELEC) {
            F1.setBackgroundColor(Color.parseColor("#8B0000"));
            VF1.setText("2");
            F1ASIGN = true;
        } else if (F2SELEC) {
            F2.setBackgroundColor(Color.parseColor("#8B0000"));
            VF2.setText("2");
            F2ASIGN = true;
        } else if (F3SELEC) {
            F3.setBackgroundColor(Color.parseColor("#8B0000"));
            VF3.setText("2");
            F3ASIGN = true;
        } else if (F4SELEC) {
            F4.setBackgroundColor(Color.parseColor("#8B0000"));
            VF4.setText("2");
            F4ASIGN = true;
        }
    }

    public void setYellow(View view) {
        if (F1SELEC) {
            F1.setBackgroundColor(Color.parseColor("#FFFF00"));
            VF1.setText("4");
            F1ASIGN = true;
        } else if (F2SELEC) {
            F2.setBackgroundColor(Color.parseColor("#FFFF00"));
            VF2.setText("4");
            F2ASIGN = true;
        } else if (F3SELEC) {
            F3.setBackgroundColor(Color.parseColor("#FFFF00"));
            VF3.setText("4");
            F3ASIGN = true;
        } else if (F4SELEC) {
            F4.setBackgroundColor(Color.parseColor("#FFFF00"));
            VF4.setText("4");
            F4ASIGN = true;
        }
    }

    public void setOrange(View view) {
        if (F1SELEC) {
            F1.setBackgroundColor(Color.parseColor("#FF8C00"));
            VF1.setText("3");
            F1ASIGN = true;
        } else if (F2SELEC) {
            F2.setBackgroundColor(Color.parseColor("#FF8C00"));
            VF2.setText("3");
            F2ASIGN = true;
        } else if (F3SELEC) {
            F3.setBackgroundColor(Color.parseColor("#FF8C00"));
            VF3.setText("3");
            F3ASIGN = true;
        } else if (F4SELEC) {
            F4.setBackgroundColor(Color.parseColor("#FF8C00"));
            VF4.setText("3");
            F4ASIGN = true;
        }
    }

    public void setGreen(View view) {
        if (F1SELEC) {
            F1.setBackgroundColor(Color.parseColor("#228B22"));
            VF1.setText("5");
            F1ASIGN = true;
        } else if (F2SELEC) {
            F2.setBackgroundColor(Color.parseColor("#228B22"));
            VF2.setText("5");
            F2ASIGN = true;
        } else if (F3SELEC) {
            F3.setBackgroundColor(Color.parseColor("#228B22"));
            VF3.setText("5");
            F3ASIGN = true;
        } else if (F4SELEC) {
            F4.setBackgroundColor(Color.parseColor("#228B22"));
            VF4.setText("5");
            F4ASIGN = true;
        }
    }

    public void setBlue(View view) {
        if (F1SELEC) {
            F1.setBackgroundColor(Color.parseColor("#0000CD"));
            VF1.setText("6");
            F1ASIGN = true;
        } else if (F2SELEC) {
            F2.setBackgroundColor(Color.parseColor("#0000CD"));
            VF2.setText("6");
            F2ASIGN = true;
        } else if (F3SELEC) {
            F3.setBackgroundColor(Color.parseColor("#0000CD"));
            VF3.setText("6");
            F3ASIGN = true;
        } else if (F4SELEC) {
            F4.setBackgroundColor(Color.parseColor("#0000CD"));
            VF4.setText("6");
            F4ASIGN = true;
        }
    }

    public void setPurple(View view) {
        if (F1SELEC) {
            F1.setBackgroundColor(Color.parseColor("#800080"));
            VF1.setText("7");
            F1ASIGN = true;
        } else if (F2SELEC) {
            F2.setBackgroundColor(Color.parseColor("#800080"));
            VF2.setText("7");
            F2ASIGN = true;
        } else if (F3SELEC) {
            F3.setBackgroundColor(Color.parseColor("#800080"));
            VF3.setText("7");
            F3ASIGN = true;
        } else if (F4SELEC) {
            F4.setBackgroundColor(Color.parseColor("#800080"));
            VF4.setText("7");
            F4ASIGN = true;
        }
    }

    public void setGray(View view) {
        if (F1SELEC) {
            F1.setBackgroundColor(Color.parseColor("#BEBEBE"));
            VF1.setText("8");
            F1ASIGN = true;
        } else if (F2SELEC) {
            F2.setBackgroundColor(Color.parseColor("#BEBEBE"));
            VF2.setText("8");
            F2ASIGN = true;
        } else if (F3SELEC) {
            F3.setBackgroundColor(Color.parseColor("#BEBEBE"));
            VF3.setText("8");
            F3ASIGN = true;
        } else if (F4SELEC) {
            F4.setBackgroundColor(Color.parseColor("#BEBEBE"));
            VF4.setText("8");
            F4ASIGN = true;
        }
    }

    public void setWhite(View view) {
        if (F1SELEC) {
            F1.setBackgroundColor(Color.parseColor("#FFFFFF"));
            VF1.setText("9");
            F1ASIGN = true;
        } else if (F2SELEC) {
            F2.setBackgroundColor(Color.parseColor("#FFFFFF"));
            VF2.setText("9");
            F2ASIGN = true;
        } else if (F3SELEC) {
            F3.setBackgroundColor(Color.parseColor("#FFFFFF"));
            VF3.setText("9");
            F3ASIGN = true;
        } else if (F4SELEC) {
            F4.setBackgroundColor(Color.parseColor("#FFFFFF"));
            VF4.setText("9");
            F4ASIGN = true;
        }
    }

    public void setDorado(View view) {
        if (F1SELEC) {
            F1.setBackgroundColor(Color.parseColor("#FFD700"));
            VF1.setText("10");
            F1ASIGN = true;
        } else if (F2SELEC) {
            F2.setBackgroundColor(Color.parseColor("#FFD700"));
            VF2.setText("10");
            F2ASIGN = true;
        } else if (F3SELEC) {
            F3.setBackgroundColor(Color.parseColor("#FFD700"));
            VF3.setText("10");
            F3ASIGN = true;
        } else if (F4SELEC) {
            F4.setBackgroundColor(Color.parseColor("#FFD700"));
            VF4.setText("10");
            F4ASIGN = true;
        }
    }

    public void setPlateado(View view) {
        if (F1SELEC) {
            F1.setBackgroundColor(Color.parseColor("#F5F5DC"));
            VF1.setText("11");
            F1ASIGN = true;
        } else if (F2SELEC) {
            F2.setBackgroundColor(Color.parseColor("#F5F5DC"));
            VF2.setText("11");
            F2ASIGN = true;
        } else if (F3SELEC) {
            F3.setBackgroundColor(Color.parseColor("#F5F5DC"));
            VF3.setText("11");
            F3ASIGN = true;
        } else if (F4SELEC) {
            F4.setBackgroundColor(Color.parseColor("#F5F5DC"));
            VF4.setText("11");
            F4ASIGN = true;
        }
    }
}

