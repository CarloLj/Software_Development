package com.altas2.Global;

import com.altas2.POJOS.Persona;

import java.util.ArrayList;

public class Globales {

    public static final ArrayList<Persona> Registro = new ArrayList<>();
    public static final ArrayList<String> posicion = new ArrayList<>();
}
