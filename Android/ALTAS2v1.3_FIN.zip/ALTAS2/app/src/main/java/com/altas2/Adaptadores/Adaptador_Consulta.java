package com.altas2.Adaptadores;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.altas2.Global.Globales;
import com.altas2.R;
import com.squareup.picasso.Picasso;
import com.altas2.PerfilActivity;

import static com.altas2.Global.Globales.posicion;

public class Adaptador_Consulta extends RecyclerView.Adapter<Adaptador_Consulta.Miniactivity> {
    public Context context;

    @NonNull
    @Override
    public Miniactivity onCreateViewHolder(@NonNull ViewGroup viewGroup, int i){
        View v=View.inflate(context,R.layout.mivista,null);
        Miniactivity obj= new Miniactivity(v);
        return obj;
    }



    @Override
    public void onBindViewHolder(@NonNull Adaptador_Consulta.Miniactivity miniactivity, int i) {
        final int indice = i;
        miniactivity.Nombre.setText(Globales.Registro.get(i).getNombre());
        miniactivity.Nombre.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent a= new Intent(context, PerfilActivity.class);
                a.putExtra("posicion",indice);
                context.startActivity(a);
            }
        });
            Picasso.get().load(Globales.posicion.get(indice)).into(miniactivity.imagen);
    }



    @Override
    public int getItemCount() {

        return Globales.Registro.size();

    }

    class Miniactivity extends RecyclerView.ViewHolder{
        public TextView Nombre;
        public ImageView imagen;


        public Miniactivity(@NonNull View itemView) {
            super(itemView);

            Nombre=itemView.findViewById(R.id.Nombree);
            imagen=itemView.findViewById(R.id.Imagen);
        }
    }
}
