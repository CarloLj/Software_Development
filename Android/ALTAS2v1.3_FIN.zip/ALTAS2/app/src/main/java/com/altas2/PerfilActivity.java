package com.altas2;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;

import com.altas2.Global.Globales;

public class PerfilActivity extends AppCompatActivity {
    TextView nombre, apellido_p,apellido_m,telefono;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.perfl);

        nombre = findViewById(R.id.NOMBRE);
        apellido_p = findViewById(R.id.APELLIDOP);
        apellido_m = findViewById(R.id.APELLIDOM);
        telefono = findViewById(R.id.TEL);

        int pos;
        pos = getIntent().getIntExtra("posicion",-1);

        nombre.setText(Globales.Registro.get(pos).getNombre());
        apellido_p.setText(Globales.Registro.get(pos).getApellidoP());
        apellido_m.setText(Globales.Registro.get(pos).getApellidoM());
        telefono.setText(Globales.Registro.get(pos).getTelefono());

    }

    public void Llamar(View view){
        Intent llamada = new Intent(Intent.ACTION_CALL, Uri.parse("tel:"+ telefono.getText().toString()));

        if(ActivityCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CALL_PHONE}, 10);
            return;
        }
        startActivity(llamada);
    }
}