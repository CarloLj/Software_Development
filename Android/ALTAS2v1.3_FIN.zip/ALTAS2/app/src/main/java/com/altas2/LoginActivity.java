package com.altas2;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

    Button ingresar;
    EditText usuario, contra;
    SharedPreferences archivo;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        setContentView(R.layout.activity_login);

        ingresar = findViewById(R.id.Ingresar);
        usuario = findViewById(R.id.Usuario);
        contra = findViewById(R.id.Contraseña);

        archivo = this.getSharedPreferences("Ingrese", Context.MODE_PRIVATE);

        if(archivo.contains("usuario")){
            Intent i= new Intent(this, MainActivity.class);
            startActivity(i);
        }

    }

    public void Ingresar(View view) {
        if(usuario.getText().toString().equals("Carlo") && contra.getText().toString().equals("1234")){
            Intent i= new Intent(this, MainActivity.class);


            SharedPreferences.Editor editor = archivo.edit();
            editor.putString("usuario","Carlo");
            editor.putString("contraseña","1234");
            editor.putBoolean("validar",true);
            editor.commit();

            startActivity(i);
            finish();
        }else{
            usuario.setText("");
            contra.setText("");
            Toast toast = Toast.makeText(getApplicationContext(),"Ingrese un dato!",Toast.LENGTH_SHORT);
            toast.setGravity(Gravity.CENTER,0,0);
            toast.show();
        }

    }
}
