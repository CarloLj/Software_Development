package com.altas2;

import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.support.v4.app.Person;
import android.support.v7.app.AppCompatActivity;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

import com.altas2.Global.Globales;
import com.altas2.POJOS.Persona;


public class AñadirActivity extends AppCompatActivity {

    EditText Nombre,ApellidoP,ApellidoM,Telefono;
    Button Guardar;
    RadioButton Masculino, Femenino;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        Nombre=findViewById(R.id.NOMBRE);
        ApellidoP=findViewById(R.id.APELLIDOP);
        ApellidoM=findViewById(R.id.APELLIDOM);
        Telefono=findViewById(R.id.TEL);
        Femenino=findViewById(R.id.mujer);
        Masculino=findViewById(R.id.hombre);
        Guardar = findViewById(R.id.GUARDAR);
    }

    public void Dec(View view) {
        boolean checked = ((RadioButton)view).isChecked();
    }

    public void Guardar(View view) {
        Persona nuevaPersona= new Persona();

        nuevaPersona.setNombre(Nombre.getText().toString());
        nuevaPersona.setApellidoP(ApellidoP.getText().toString());
        nuevaPersona.setApellidoM(ApellidoM.getText().toString());
        nuevaPersona.setTelefono(Telefono.getText().toString());

        if(Femenino.isChecked()){
            nuevaPersona.setSexo(true);
        }
        else if (Masculino.isChecked()){
            nuevaPersona.setSexo(false);
        }

        Globales.Registro.add(nuevaPersona);

        Toast toast = Toast.makeText(getApplicationContext(),"Guardado!",Toast.LENGTH_SHORT);
        toast.setGravity(Gravity.CENTER,0,0);
        toast.show();
        finish();

    }

    public void Back(View view) {
        Intent o = new Intent(this, MainActivity.class);
        startActivity(o);
    }


}
