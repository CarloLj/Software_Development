package com.altas2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.altas2.Global.Globales;
import com.squareup.picasso.Picasso;

public class MainActivity extends AppCompatActivity {

    Button Altas, Consultar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Altas = findViewById(R.id.ALTAS);
        Consultar = findViewById(R.id.Consultar);

        Globales.posicion.add("https://images.sftcdn.net/images/t_app-cover-l,f_auto/p/18daa71a-96d1-11e6-a693-00163ed833e7/674522305/minecraft-pocket-edition-screenshot.jpg");
        Globales.posicion.add("https://cdn.vegaoo.es/images/rep_art/gra/307/8/307894/espada-minecraft-nino.jpg");
        Globales.posicion.add("https://images.halloweencostumes.com/products/41883/1-1/minecraft-creeper-prestige-boys-costume.jpg");
        Globales.posicion.add("https://images.techhive.com/images/article/2017/01/microsoft-minecraft-pocket-edition-2-100704557-large.jpg");
        Globales.posicion.add("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQuKD_q7oaWSLDUAoOU7urNSfsdlqIhhnrjmo8UB4iwiHw4B0Dn");
    }


    public void Abrir_Altas(View view) {
        Intent a = new Intent(MainActivity.this, AñadirActivity.class);
        startActivity(a);
    }

    public void Consultar(View view) {
        Intent i = new Intent(MainActivity.this, ConsultaActivity.class);
        startActivity(i);


    }
}


