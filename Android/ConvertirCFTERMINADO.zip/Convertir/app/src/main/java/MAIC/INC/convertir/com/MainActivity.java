package MAIC.INC.convertir.com;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText centigrados;
    EditText Fahrenheit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

            centigrados = findViewById(R.id.ed_entrada);
            Fahrenheit = findViewById(R.id.ed_salida);

    }

    public void convertiracentigrados(View view) {

        String DatoEntra;
        String DatoSale;

        double gradosE, gradosS;
        DatoEntra = centigrados.getText().toString();

        if (DatoEntra.equals("")) {
            Toast.makeText(MainActivity.this, " No hay dato a convertir ", Toast.LENGTH_SHORT).show();
        }

        else
        {
            gradosE=Double.parseDouble(DatoEntra);
            gradosS=gradosFahrenheit(gradosE);

            DatoSale="" +gradosS;
            Fahrenheit.setText(DatoSale);
        }
    }

    public double gradosFahrenheit(double n)
    {
    return n * (9.0/5.0) + 32.0;

    }

    public void convertirafahrenheit(View view) {

        String DatoEntra;
        String DatoSale;

        double gradosE, gradosS;
        DatoEntra = Fahrenheit.getText().toString();

        if (DatoEntra.equals("")) {
            Toast.makeText(MainActivity.this, " No hay dato a convertir ", Toast.LENGTH_SHORT).show();
        }
        else
        {
            gradosE=Double.parseDouble(DatoEntra);
            gradosS=gradosCentrigrados(gradosE);

            DatoSale="" +gradosS;
            centigrados.setText(DatoSale);
        }
    }

    public double gradosCentrigrados(double i)
    {
        return (i-32.0) * (5.0/9.0);

    }
}
