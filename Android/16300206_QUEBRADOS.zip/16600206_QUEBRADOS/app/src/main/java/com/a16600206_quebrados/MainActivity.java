package com.a16600206_quebrados;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText num1,num2,den1,den2;
    TextView A,B;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        num1 = findViewById(R.id.N1);
        num2 = findViewById(R.id.N2);
        den1 = findViewById(R.id.D1);
        den2 = findViewById(R.id.D2);
        A = findViewById(R.id.res_numerador);
        B = findViewById(R.id.res_denominador);
    }

    public void SUMA(View view){
        int NUMERADOR1,NUMERADOR2,DENOMINADOR1,DENOMINADOR2;
        int SALIDADENOMINADOR,SALIDANUMERADOR,common;


        NUMERADOR1 = Integer.parseInt(num1.getText().toString());
        NUMERADOR2 = Integer.parseInt(num2.getText().toString());
        DENOMINADOR1 = Integer.parseInt(den1.getText().toString());
        DENOMINADOR2 = Integer.parseInt(den2.getText().toString());

        SALIDADENOMINADOR = DENOMINADOR1*DENOMINADOR2;
        SALIDANUMERADOR = (DENOMINADOR1*NUMERADOR2)+(DENOMINADOR2*NUMERADOR1);

        A.setText(""+SALIDANUMERADOR);
        B.setText(""+SALIDADENOMINADOR);
    }

    public void IGUAL(View view) {
        SUMA(view);
    }
}