/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servertest;

// Fig. 24.14: TicTacToeServerTest.java
// Tests the TicTacToeServer.
import javax.swing.JFrame;

public class ServerTestTest {

    public static void main(String args[]) {
        ServerTest application = new ServerTest();
        application.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        application.execute();
    } // end main
} // end class TicTacToeServerTest
