﻿using System;
using System.Collections.Generic;

namespace Cocoteca.Models.Cliente.Equipo_3
{
    public partial class MtoCatUsuarios
    {

        public int Idusuario { get; set; }
        public string IDidentity { get; set; }

    }
}
