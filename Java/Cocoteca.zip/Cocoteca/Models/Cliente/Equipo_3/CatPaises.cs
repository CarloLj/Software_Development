﻿using System;
using System.Collections.Generic;

namespace Cocoteca.Models.Cliente.Equipo_3
{
    public partial class CatPaises
    {

        public int Idpais { get; set; }
        public string Nombre { get; set; }
        public string Iso3 { get; set; }
    }
}
