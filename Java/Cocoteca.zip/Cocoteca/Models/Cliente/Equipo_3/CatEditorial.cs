﻿using System;
using System.Collections.Generic;

namespace Cocoteca.Models.Cliente.Equipo_3
{
    public partial class CatEditorial
    {
     

        public int Ideditorial { get; set; }
        public string Nombre { get; set; }

       
    }
}
