﻿using System;
using System.Collections.Generic;

namespace Cocoteca.Models.Cliente.Equipo_3
{
    public  class CatCategorias
    {
        public int Idcategoria { get; set; }
        public string Nombre { get; set; }

    }
}
