/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package crud;
import java.util.Scanner;
import java.util.Arrays;
/**
 * CRUD
 * esta clase hace un crud de un arreglo de peliculas
 * @author Angel
 */
public class CRUD {

    static Scanner in;
    static Pelicula[] peliculas;
    static Criterio criterioParaString;
    static Criterio criterioParaFloat;
    static Criterio criterioParaInt;
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        peliculas = new Pelicula[0];
        
        testData();
        
        criterioParaString = new Criterio(){
            @Override
            public boolean criterio(Object obj1, Object obj2){
                if(((String)obj1).compareTo(((String)obj2)) > 0){
                    return true;
                }
                if(((String)obj1).compareTo(((String)obj2)) < 0){
                    return false;
                }
                return false;
            }
        };
        criterioParaFloat = new Criterio(){
            @Override
            public boolean criterio(Object obj1, Object obj2){
                return (Float)obj1 > (Float)obj2;
            }
        };   
        criterioParaInt = new Criterio(){
            @Override
            public boolean criterio(Object obj1, Object obj2){
                return (Integer)obj1 > (Integer)obj2;
            }
        };
        
        
        in = new Scanner(System.in);
        int opc = 0;
        do{
            System.out.println("Menu");
            System.out.println("1) Insertar");
            System.out.println("2) Busqueda");
            System.out.println("3) Actualizar");
            System.out.println("4) Eliminar");
            System.out.println("5) Mostrar todas");
            System.out.println("6) Salir");
            opc = Integer.parseInt(in.nextLine());
            switch(opc){
                case 1:
                    insertar();
                    break;
                case 2:
                    try{
                        System.out.println(peliculas[busqueda()]);
                    }catch(java.lang.ArrayIndexOutOfBoundsException e){
                        System.out.println("No econtrando...");
                    }
                    break;
                case 3:
                    peliculas = actualizar(peliculas,busqueda());
                    break;
                case 4:
                    peliculas = eliminar(peliculas,busqueda());
                    break;
                case 5:
                    imprimirPeliculas(peliculas);
                    break;
                case 6:
                    break;
                default:
                    System.out.println("Opcion no valida...");
            }
        }while(opc != 5);
    }
    
    static void insertar(){
        Pelicula nuevaPelicula = new Pelicula();
        System.out.print("Nombre: ");
        nuevaPelicula.setNombre(in.nextLine().toString());
        System.out.print("Año: ");
        nuevaPelicula.setAño(Integer.parseInt(in.nextLine()));
        System.out.print("Categoria: ");
        nuevaPelicula.setCategoria(in.nextLine().toString());
        System.out.print("Director: ");
        nuevaPelicula.setDirector(in.nextLine().toString());
        System.out.print("Recaudacion: ");
        nuevaPelicula.setRecaudacion(Float.parseFloat(in.nextLine()));
        Pelicula[] aux = new Pelicula[peliculas.length + 1];
        for(int i = 0; i<peliculas.length;i++){
            aux[i] = peliculas[i]; 
        }
        aux[aux.length -1] = nuevaPelicula;
        peliculas = aux;
    }
    
    static int busqueda(){
        int opc = 0;
        int n = 0;
        String dato;
         System.out.println("Buscar por: ");
         System.out.println("1) Nombre");
         System.out.println("2) Año");
         System.out.println("3) Categoria");
         System.out.println("4) Director");
         System.out.println("5) Recaudacion");
         
         opc = Integer.parseInt(in.nextLine());
         
         Criterio cString = new Criterio(){
                    @Override
                    public boolean criterio(Object obj1, Object obj2){
                    if(((String)obj1).compareTo(((String)obj2)) < 0){
                        return true;
                    }
                    if(((String)obj1).compareTo(((String)obj2)) > 0){
                        return false;
                    }
                    return false;
                }
            };
         Criterio compareTwoStrings = new Criterio(){
                     @Override
                     public boolean criterio(Object obj1, Object obj2){
                         return ((String)obj1).equals((String)obj2);
                     }
         };
         
         switch(opc){
             case 1:
                 System.out.print("nombre: ");
                 dato = in.nextLine().toString();
                 metodoBurbuja(peliculas,criterioParaString, new PeliculaAttribute(){
                     @Override
                     public Object GET(Pelicula p){
                            return p.getNombre();
                        }
                 });
                  n = busquedaBinaria(peliculas,dato,cString,new PeliculaAttribute(){
                     @Override
                     public Object GET(Pelicula p){
                            return p.getNombre();
                        }
                 },compareTwoStrings);
                 break;
             case 2:
                 System.out.print("año: ");
                 dato = in.nextLine().toString();
                 metodoBurbuja(peliculas,criterioParaString, new PeliculaAttribute(){
                     @Override
                     public Object GET(Pelicula p){
                            return "" +p.getAño();
                        }
                 });
                  n = busquedaBinaria(peliculas,dato,cString,new PeliculaAttribute(){
                     @Override
                     public Object GET(Pelicula p){
                            return "" +p.getAño();
                        }
                 },compareTwoStrings);
                 break;
             case 3:
                 System.out.print("categoria: ");
                 dato = in.nextLine().toString();
                 metodoBurbuja(peliculas,criterioParaString, new PeliculaAttribute(){
                     @Override
                     public Object GET(Pelicula p){
                            return p.getCategoria();
                        }
                 });
                  n = busquedaBinaria(peliculas,dato,cString,new PeliculaAttribute(){
                     @Override
                     public Object GET(Pelicula p){
                            return p.getCategoria();
                        }
                 },compareTwoStrings);
                 break;
             case 4:
                 System.out.print("director: ");
                 dato = in.nextLine().toString();
                 metodoBurbuja(peliculas,criterioParaString, new PeliculaAttribute(){
                     @Override
                     public Object GET(Pelicula p){
                            return p.getDirector();
                        }
                 });
                  n = busquedaBinaria(peliculas,dato,cString,new PeliculaAttribute(){
                     @Override
                     public Object GET(Pelicula p){
                            return p.getDirector();
                        }
                 },compareTwoStrings);
                 break;
             case 5:
                 System.out.print("año: ");
                 dato = in.nextLine().toString();
                 metodoBurbuja(peliculas,criterioParaString, new PeliculaAttribute(){
                     @Override
                     public Object GET(Pelicula p){
                            return "" +p.getRecaudacion();
                        }
                 });
                  n = busquedaBinaria(peliculas,dato,cString,new PeliculaAttribute(){
                     @Override
                     public Object GET(Pelicula p){
                            return "" +p.getRecaudacion();
                        }
                 },compareTwoStrings);
                 break;
             default:
                 System.out.println("opcion no valida...");
         }
         return n;
    }
                 
    
    static void imprimirPeliculas(Pelicula[] peliculas){
        
        for(int i = 0; i<peliculas.length;i++){
            System.out.println(peliculas[i]);
        }
    }
    
    public static void metodoBurbuja(Object[] array, Criterio c, PeliculaAttribute pa)
    {
        for(int i = 0; i < array.length; i++){
            for(int j = 0; j < array.length - i - 1; j++){
                if(c.criterio(pa.GET((Pelicula)array[j]),pa.GET((Pelicula)array[j+1]))){
                    Object aux = array[j];
                    array[j] = array[j+1];
                    array[j+1] = aux;
                }
            }
        }
    }
    
    public static int busquedaBinaria(Object[] array, Object dato ,Criterio c, PeliculaAttribute pa, Criterio a)
    {
        int n = array.length;
        int centro,inf=0,sup=n-1;
        while(inf<=sup){
            centro = (sup+inf)/2;
            if(a.criterio(pa.GET((Pelicula)array[centro]), dato)) return centro;
            else if(c.criterio(dato, pa.GET((Pelicula)array[centro]))){
                sup = centro-1;
            }else{
                inf = centro+1;
            }
        }
        return -1;
    }
    
    public static Pelicula[] eliminar(Pelicula[] peliculas,int n){
        if (peliculas == null
            || n < 0
            || n >= peliculas.length) { 
  
            return peliculas; 
        } 
  
        Pelicula[] anotherArray = new Pelicula[peliculas.length - 1]; 
  
        for (int i = 0, k = 0; i < peliculas.length; i++) { 
            if (i == n) { 
                continue; 
            } 
            anotherArray[k++] = peliculas[i]; 
        } 
        return anotherArray; 
    }

    public static Pelicula[] actualizar(Pelicula[] peliculas, int n){
        Pelicula nuevaPelicula = new Pelicula();
        System.out.print("Nombre: ");
        nuevaPelicula.setNombre(in.nextLine().toString());
        System.out.print("Año: ");
        nuevaPelicula.setAño(Integer.parseInt(in.nextLine()));
        System.out.print("Categoria: ");
        nuevaPelicula.setCategoria(in.nextLine().toString());
        System.out.print("Director: ");
        nuevaPelicula.setDirector(in.nextLine().toString());
        System.out.print("Recaudacion: ");
        nuevaPelicula.setRecaudacion(Float.parseFloat(in.nextLine()));
        if (peliculas == null
            || n < 0
            || n >= peliculas.length) { 
  
            return peliculas; 
        } 
  
        Pelicula[] anotherArray = new Pelicula[peliculas.length]; 
  
        for (int i = 0; i < peliculas.length; i++) {  
            if (i == n) { 
                anotherArray[i] = nuevaPelicula;
            } else
                anotherArray[i] = peliculas[i]; 
        } 
        return anotherArray; 
    }
    
    public static void testData(){
        peliculas = new Pelicula[5];
        Pelicula a = new Pelicula("Zorros",2019,"Accion","Mark",1232421f);    
        peliculas[0]  = a;
        a = new Pelicula("Ardillas",2015,"Comedia","Josh",123f);
        peliculas[1]  = a;
        a = new Pelicula("Carros 2",2020,"Niños","Drake",192113f);
        peliculas[2]  = a;
        a = new Pelicula("Carros",2017,"Niños","Drake",1244333f);
        peliculas[3]  = a;
        a = new Pelicula("Cocos y mangos",2011,"Comida","Chef",30f);
        peliculas[4]  = a;
    }
}

