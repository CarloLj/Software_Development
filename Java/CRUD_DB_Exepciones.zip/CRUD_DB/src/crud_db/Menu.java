/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package crud_db;

import static crud_db.CRUD_DB.in;
import java.util.ArrayList;

/**
 * Menu
 * Esta clase muestra un menu y regresa el resultado de lo elegido por el 
 * usuario
 * @author Angel
 */
public class Menu {
    ArrayList<String> opciones;
    String titulo;
    /**
     * Menu
     * Constructor recibe:
     * @param opciones las opciones que se van a mostrar
     * @param titulo el titulo del menu
     */
    public Menu(ArrayList<String> opciones, String titulo){
        this.opciones = new ArrayList(opciones);
        this.titulo = titulo;
    }
    
    /**
     * Show
     * Este metodo muestra el menu y lanza las excepciones de menu si la opcion
     * no es valida
     * @return regresa la opcion seleccionada por el usuario, si seentra en una 
     * excepcion regresa -1
     * @throws MenuException se da si el numero ingresado no esta en el menu o 
     * si no es un numero entero
     */
    public int Show() throws MenuException{
        int opc;
        System.out.println(titulo);
        for(int i = 0; i<opciones.size();i++){
            System.out.println((i + 1) + ") " + opciones.get(i));
        }
        System.out.print("->");
        try{
            opc = Integer.parseInt(in.nextLine());
        }catch(java.lang.NumberFormatException e){
            opc = -1;
            throw new MenuException("No se ingreso un numero: " + e.getMessage());
        }
        if(opc > opciones.size()){
            opc = -1;
            throw new MenuException("La opcion no esta en el menu");
        }
        if(opciones.size()> 0 && opc < 1){
            opc = -1;
            throw new MenuException("La opcion no esta en el menu");
        }
        return opc;
    }
}
