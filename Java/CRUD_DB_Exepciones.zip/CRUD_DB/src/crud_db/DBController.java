/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package crud_db;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
/**
 * DBController
 * controlador de la base de datos que nos permite hacer todas las operaciones
 * CRUD a la base de datos peliculas
 * @author Angel
 */
public class DBController {
    
    private Connection connection;
    
    public DBController(){
        try{
            Class.forName("com.mysql.jdbc.Driver");
            connection = DriverManager.getConnection("jdbc:mysql://localhost/peliculas","root","");
        }catch(java.lang.ClassNotFoundException e){
            System.out.println("Error al cargar el driver :c " + e);
        }catch(SQLException e){
            System.out.println("Error al cargar el driver :c " + e);
        }
    }
    
    public boolean insertarPelicula(Pelicula p){
        
        try{
            String sql = "INSERT INTO pelicula(nombre,año,categoria,director,recaudacion) VALUES (?,?,?,?,?)" ; 
            PreparedStatement stmt = connection.prepareStatement(sql);

            stmt.setString(1, p.getNombre());
            stmt.setInt(2, p.getAño());
            stmt.setString(3, p.getCategoria());
            stmt.setString(4, p.getDirector());
            stmt.setFloat(5, p.getRecaudacion());
            
            stmt.executeUpdate();
        }catch(SQLException e){
            return false;
        }
        return true;
    }
    
    public boolean actualizarPelicula(Pelicula p){
        
        try{
            String sql = "UPDATE pelicula SET nombre=?,año=?,categoria=?,director=?,recaudacion=? WHERE id=?" ; 
            PreparedStatement stmt = connection.prepareStatement(sql);

            stmt.setString(1, p.getNombre());
            stmt.setInt(2, p.getAño());
            stmt.setString(3, p.getCategoria());
            stmt.setString(4, p.getDirector());
            stmt.setFloat(5, p.getRecaudacion());
            
            stmt.setInt(6, p.getId());
            
            stmt.executeUpdate();
        }catch(SQLException e){
            return false;
        }
        return true;
    }
      
    public boolean eliminarPelicula(Pelicula p){
          try{
            String sql = "DELETE FROM pelicula WHERE id=?" ; 
            PreparedStatement stmt = connection.prepareStatement(sql);

            stmt.setInt(1, p.getId());
            
            stmt.executeUpdate();
        }catch(SQLException e){
            return false;
        }
        return true;
    }
    
    public ArrayList<Pelicula> obtenerPeliculas(){
        ArrayList<Pelicula> peliculas = new ArrayList<Pelicula>();
        ResultSet result;
       
        try{
            PreparedStatement stmt = connection.prepareStatement("SELECT * FROM pelicula");   
            result = stmt.executeQuery();
            
            while(result.next()){
                Pelicula p = new Pelicula(
                        result.getInt("id"),
                        result.getString("nombre"),
                        result.getInt("año"),
                        result.getString("categoria"),
                        result.getString("director"),
                        result.getFloat("recaudacion")
                );
                
                peliculas.add(p);
            }
            
        }catch(SQLException e){
            System.out.println("Error en la consulta");
            return null;
        }
        
        return peliculas;
    }
}
