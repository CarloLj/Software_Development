/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package crud_db;

/**
 * Criterio
 * interfaz que se usa para comparar dos objetos 
 * @author Angel
 */
public interface Criterio {
     public boolean criterio(Object obj1, Object obj2);
}
