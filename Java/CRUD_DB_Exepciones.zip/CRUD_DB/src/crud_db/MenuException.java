package crud_db;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * MenuException
 * Excepcion para las opciones del menu
 * @author Angel
 */
public class MenuException extends Exception{
    public MenuException(String msg){
        super(msg);
    }
}
