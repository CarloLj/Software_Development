/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package crud_db;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Arrays;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 * CRUD_DB
 * Este crud es igual al crud del crud de arreglos, pero adaptado para que use
 * el controlador de la base de datos
 * @author Angel
 */
public class CRUD_DB {

    static Scanner in;
    static DBController controller;
    static Criterio criterioParaString;
    static Criterio criterioParaFloat;
    static Criterio criterioParaInt;
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ArrayList opciones = new ArrayList();
        opciones.add("Insertar");
        opciones.add("Busqueda");
        opciones.add("Actualizar");
        opciones.add("Eliminar");
        opciones.add("Mostrar todas");
        opciones.add("Salir");
            
        Menu menu = new Menu(opciones,"Menu");
        
        controller = new DBController();
        
        criterioParaString = new Criterio(){
            @Override
            public boolean criterio(Object obj1, Object obj2){
                if(((String)obj1).compareTo(((String)obj2)) > 0){
                    return true;
                }
                if(((String)obj1).compareTo(((String)obj2)) < 0){
                    return false;
                }
                return false;
            }
        };
        criterioParaFloat = new Criterio(){
            @Override
            public boolean criterio(Object obj1, Object obj2){
                return (Float)obj1 > (Float)obj2;
            }
        };   
        criterioParaInt = new Criterio(){
            @Override
            public boolean criterio(Object obj1, Object obj2){
                return (Integer)obj1 > (Integer)obj2;
            }
        };
        
        
        in = new Scanner(System.in);
        int opc = -1;
        do{
            opc = -1;
            try {  
                opc = menu.Show();
            } catch (MenuException ex) {
                System.out.println("Opcion no valida: " + ex.getMessage());
            }
            if(opc != -1){
                switch(opc){
                case 1:
                    insertar();
                    break;
                case 2:
                    Pelicula peli = busqueda();
                    if(peli != null){
                         System.out.println(peli);
                    }else{
                         System.out.println("Pelicula no encontrada...");
                    }
                    break;
                case 3:
                    actualizar(busqueda());
                    break;
                case 4:
                    eliminar(busqueda());
                    break;
                case 5:
                    imprimirPeliculas(controller.obtenerPeliculas());
                    break;
                case 6:
                    break;
                default:
                    System.out.println("Opcion no valida...");
            }
            }else{
                System.out.println("Opcion no valida...");
            }
        }while(opc != 6);
    }
    
    /**
     * Insertar
     * Este metodo inserta una nueva pelicula a la base de datos de peliculas
     */
    static void insertar(){
        Pelicula nuevaPelicula = new Pelicula();
        System.out.print("Nombre: ");
        nuevaPelicula.setNombre(in.nextLine().toString());
        System.out.print("Año: ");
        nuevaPelicula.setAño(Integer.parseInt(in.nextLine()));
        System.out.print("Categoria: ");
        nuevaPelicula.setCategoria(in.nextLine().toString());
        System.out.print("Director: ");
        nuevaPelicula.setDirector(in.nextLine().toString());
        System.out.print("Recaudacion: ");
        nuevaPelicula.setRecaudacion(Float.parseFloat(in.nextLine()));
        
        controller.insertarPelicula(nuevaPelicula);
    }
    /**
     * busqueda
     * metodo que muestra un menu y llama al metodo de busqueda binaria 
     * para poder buscar una pelicula por cualquiera de los 5 atributos
     * @return retorna la pelicula encontrda, en caso de no encontrar retorna 
     * null
     */
    static Pelicula busqueda(){
        ArrayList opciones = new ArrayList();
        opciones.add("Nombre");
        opciones.add("Año");
        opciones.add("Categoria");
        opciones.add("Director");
        opciones.add("Recaudacion");
        opciones.add("Regresar");
            
        Menu menu = new Menu(opciones,"Buscar por:");
        int opc = -1;
        Object n = null;
        String dato;
        do{
            try {
                opc = menu.Show();
            } catch (MenuException ex) {
               System.out.println("Opcion no valida: " + ex.getMessage());
            }
        }while(opc == -1);
         
        if(opc == 6)
            return null;
         Criterio cString = new Criterio(){
                    @Override
                    public boolean criterio(Object obj1, Object obj2){
                    if(((String)obj1).compareTo(((String)obj2)) < 0){
                        return true;
                    }
                    if(((String)obj1).compareTo(((String)obj2)) > 0){
                        return false;
                    }
                    return false;
                }
            };
         Criterio compareTwoStrings = new Criterio(){
                     @Override
                     public boolean criterio(Object obj1, Object obj2){
                         return ((String)obj1).equals((String)obj2);
                     }
         };
         ArrayList<Object> peliculas = new ArrayList<Object>(controller.obtenerPeliculas());
         switch(opc){
             case 1:
                 System.out.print("nombre: ");
                 dato = in.nextLine().toString();
                 metodoBurbuja(peliculas,criterioParaString, new PeliculaAttribute(){
                     @Override
                     public Object GET(Pelicula p){
                            return p.getNombre();
                        }
                 });
                  n = busquedaBinaria(peliculas,dato,cString,new PeliculaAttribute(){
                     @Override
                     public Object GET(Pelicula p){
                            return p.getNombre();
                        }
                 },compareTwoStrings);
                 break;
             case 2:
                 System.out.print("año: ");
                 dato = in.nextLine().toString();
                 metodoBurbuja(peliculas,criterioParaString, new PeliculaAttribute(){
                     @Override
                     public Object GET(Pelicula p){
                            return "" +p.getAño();
                        }
                 });
                  n = busquedaBinaria(peliculas,dato,cString,new PeliculaAttribute(){
                     @Override
                     public Object GET(Pelicula p){
                            return "" +p.getAño();
                        }
                 },compareTwoStrings);
                 break;
             case 3:
                 System.out.print("categoria: ");
                 dato = in.nextLine().toString();
                 metodoBurbuja(peliculas,criterioParaString, new PeliculaAttribute(){
                     @Override
                     public Object GET(Pelicula p){
                            return p.getCategoria();
                        }
                 });
                  n = busquedaBinaria(peliculas,dato,cString,new PeliculaAttribute(){
                     @Override
                     public Object GET(Pelicula p){
                            return p.getCategoria();
                        }
                 },compareTwoStrings);
                 break;
             case 4:
                 System.out.print("director: ");
                 dato = in.nextLine().toString();
                 metodoBurbuja(peliculas,criterioParaString, new PeliculaAttribute(){
                     @Override
                     public Object GET(Pelicula p){
                            return p.getDirector();
                        }
                 });
                  n = busquedaBinaria(peliculas,dato,cString,new PeliculaAttribute(){
                     @Override
                     public Object GET(Pelicula p){
                            return p.getDirector();
                        }
                 },compareTwoStrings);
                 break;
             case 5:
                 System.out.print("año: ");
                 dato = in.nextLine().toString();
                 metodoBurbuja(peliculas,criterioParaString, new PeliculaAttribute(){
                     @Override
                     public Object GET(Pelicula p){
                            return "" +p.getRecaudacion();
                        }
                 });
                  n = busquedaBinaria(peliculas,dato,cString,new PeliculaAttribute(){
                     @Override
                     public Object GET(Pelicula p){
                            return "" +p.getRecaudacion();
                        }
                 },compareTwoStrings);
                 break;
             default:
                 System.out.println("opcion no valida...");
         }
         return (Pelicula)n;
    }
                 
    /**
     * imprimirPeliculas
     * Imprime las peliculas que se le pase como parametro
     * @param peliculas Lista de peliculas a imprimir
     */
    static void imprimirPeliculas(ArrayList<Pelicula> peliculas){
        
        for(int i = 0; i<peliculas.size();i++){
            System.out.println(peliculas.get(i));
        }
    }
    
    /**
     * metodoBurbuja
     * metodo que se usa para ordenar las peliculas dependiendo de que 
     * atributo
     * @param array lista a ordenar
     * @param c criterio que se usa para comparar y ordenar las peliculas en
     * base al siguiente parametro
     * @param pa attributo por el cual se van a ordenar las peliculas
     */
    public static void metodoBurbuja(ArrayList<Object> array, Criterio c, PeliculaAttribute pa)
    {
        for(int i = 0; i < array.size(); i++){
            for(int j = 0; j < array.size() - i - 1; j++){
                if(c.criterio(pa.GET((Pelicula)array.get(j)),pa.GET((Pelicula)array.get(j+i)))){
                    Object aux = array.get(j);
                    array.set(j,array.get(j+1));
                    array.set(j+1, aux);
                }
            }
        }
    }
    
    /**
     * busquedaBinaria
     * reliza la busqueda de un objeto en una lista por el metodo binario
     * @param array lista de objetos en donde se va a buscar
     * @param dato dato que se busca en la lista
     * @param c criterio de comparacion (mayor o menor) para mover el centro
     * @param pa atributo que se busca de la clase
     * @param a criterio de igualdad para saber si son iguales el dato
     * y el arreglo en el que va el ciclo
     * @return retorna el objeto encontrado
     */
    public static Object busquedaBinaria(ArrayList<Object> array, Object dato ,Criterio c, PeliculaAttribute pa, Criterio a)
    {
        int n = array.size();
        int centro,inf=0,sup=n-1;
        while(inf<=sup){
            centro = (sup+inf)/2;
            if(a.criterio(pa.GET((Pelicula)array.get(centro)), dato)) return array.get(centro);
            else if(c.criterio(dato, pa.GET((Pelicula)array.get(centro)))){
                sup = centro-1;
            }else{
                inf = centro+1;
            }
        }
        return null;
    }
    
    /**
     * eliminar 
     * este metodo elimina una pelicula de bd
     * @param p pelicula a eliminar
     */
    public static void eliminar(Pelicula p){
       if(p != null){
           controller.eliminarPelicula(p);
       }else{
           System.out.println("pelicula no encontrada...");
       }
    }

    /**
     * actualizar
     * este metodo actualiza una pelicuala en la base de datos
     * @param p pelicual a actualizar con datos nuevos
     */
    public static void actualizar(Pelicula p){
        
        if(p != null){
            Pelicula nuevaPelicula = new Pelicula();
        System.out.print("Nombre: ");
        nuevaPelicula.setNombre(in.nextLine().toString());
        System.out.print("Año: ");
        nuevaPelicula.setAño(Integer.parseInt(in.nextLine()));
        System.out.print("Categoria: ");
        nuevaPelicula.setCategoria(in.nextLine().toString());
        System.out.print("Director: ");
        nuevaPelicula.setDirector(in.nextLine().toString());
        System.out.print("Recaudacion: ");
        nuevaPelicula.setRecaudacion(Float.parseFloat(in.nextLine()));
        
        nuevaPelicula.setId(p.getId());
        
        controller.actualizarPelicula(nuevaPelicula);
        }else{
            System.out.println("pelicula no encontrada...");
        }
        
    }
    
}
