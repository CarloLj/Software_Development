/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DB;

import Modelos.CatCategorias;
import Modelos.CatDirecciones;
import Modelos.CatEditorial;
import Modelos.CatEstados;
import Modelos.CatEstadosMunicipios;
import Modelos.CatMunicipios;
import Modelos.CatPaises;
import Modelos.MtoCatLibros;
import Modelos.MtoCatUsuarios;
import Modelos.TraCompras;
import Modelos.TraConceptoCompra;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;

/**
 *
 * @author Propietario
 */
public class DBController {
    
    private Connection con;
    
      /**
      * Constructor
      */
    public DBController(){
        try{
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            con = DriverManager.getConnection(
                    "jdbc:sqlserver://ANGEL;"
                    + "databaseName=Cocoteca;"
                    + "user=sql_user;"
                    + "password=123;"
            );
        }catch(java.lang.ClassNotFoundException e){
            System.out.println("Error al cargar el driver :c 1" + e);
        }catch(SQLException e){
            System.out.println("Error al cargar el driver :c 2" + e);
        }
    }
    
    
    /*****************************************************************************/
    /*****************************************************************************/
    /******************************CatCategorias**********************************/
    /*****************************************************************************/
    /*****************************************************************************/
    
    public boolean insertarCatCategorias(CatCategorias x){
        try{
            String sql = "INSERT INTO dbo.Cat_Categorias(Nombre) VALUES (?)" ; 
            PreparedStatement stmt = con.prepareStatement(sql);

            stmt.setString(1, x.getNombre());
            
            stmt.executeUpdate();
        }catch(SQLException e){
            return false;
        }
        return true;
    }
    
    public boolean actualizarCatCategorias(CatCategorias x){
        try{
            String sql = "UPDATE dbo.Cat_Categorias SET Nombre=? WHERE IDCategoria=?" ; 
            PreparedStatement stmt = con.prepareStatement(sql);

            stmt.setString(1, x.getNombre());
            stmt.setInt(2, x.getIdCategoria());
            
            stmt.executeUpdate();
        }catch(SQLException e){
            return false;
        }
        return true;
    }
    
    public boolean eliminarCatCategorias(CatCategorias x){
        try{
            String sql = "DELETE FROM dbo.Cat_Categorias WHERE IDCategoria=?" ; 
            PreparedStatement stmt = con.prepareStatement(sql);

            stmt.setInt(1, x.getIdCategoria());
            
            stmt.executeUpdate();
        }catch(SQLException e){
            return false;
        }
        return true;
    }
    
    public boolean eliminarCatCategorias(int x){
         try{
            String sql = "DELETE FROM dbo.Cat_Categorias WHERE IDCategoria=?" ; 
            PreparedStatement stmt = con.prepareStatement(sql);

            stmt.setInt(1, x);
            
            stmt.executeUpdate();
        }catch(SQLException e){
            return false;
        }
        return true;
    }
    
    public ArrayList<CatCategorias> obtenerCatCategorias(){
        ArrayList<CatCategorias> categorias = new ArrayList<CatCategorias>();
        ResultSet result;
       
        try{
            PreparedStatement stmt = con.prepareStatement("SELECT * FROM dbo.Cat_Categorias");   
            result = stmt.executeQuery();
            
            while(result.next()){
                CatCategorias p = new CatCategorias(
                        result.getInt("IDCategoria"),
                        result.getString("Nombre")
                );
             
                categorias.add(p);
            }
            
        }catch(SQLException e){
            System.out.println("Error en la consulta");
            return null;
        }
        
        return categorias;
    }
    
    public CatCategorias obtenerCatCategoria(int id){
        ArrayList<CatCategorias> categorias = new ArrayList<CatCategorias>(obtenerCatCategorias());
        
        for(int i = 0; i<categorias.size(); i++){
            if(categorias.get(i).getIdCategoria() == id)
                return categorias.get(i);
        }
        
        return null;
    }
    
    
    
    /*****************************************************************************/
    /*****************************************************************************/
    /******************************CatDirecciones*********************************/
    /*****************************************************************************/
    /*****************************************************************************/
    
    public boolean insertarCatDirecciones(CatDirecciones x){
        try{
            String sql = "INSERT INTO dbo.Cat_Direcciones(IDUsuario,IDMunicipio,NoInterior,NoExterior,CodigoPostal,Calle) VALUES (?,?,?,?,?,?)" ; 
            PreparedStatement stmt = con.prepareStatement(sql);

            stmt.setInt(1, x.getIdUsuario());
            stmt.setInt(2, x.getIdMunicipio());
            stmt.setString(3, x.getNoInterior());
            stmt.setInt(4, x.getNoExterior());
            stmt.setInt(5, x.getCodigoPostal());
            stmt.setString(6, x.getCalle());
            
            stmt.executeUpdate();
        }catch(SQLException e){
            return false;
        }
        return true;
    }
    
    public boolean actualizarCatDirecciones(CatDirecciones x){
        try{
            String sql = "UPDATE dbo.Cat_Direcciones SET IDUsuario=?,IDMunicipio=?,NoInterior=?,NoExterior=?,CodigoPostal=?,Calle=? WHERE IDDireccion=?"; 
            PreparedStatement stmt = con.prepareStatement(sql);

            stmt.setInt(1, x.getIdUsuario());
            stmt.setInt(2, x.getIdMunicipio());
            stmt.setString(3, x.getNoInterior());
            stmt.setInt(4, x.getNoExterior());
            stmt.setInt(5, x.getCodigoPostal());
            stmt.setString(6, x.getCalle());
            
            stmt.setInt(7, x.getIdDireccion());
            
            stmt.executeUpdate();
        }catch(SQLException e){
            return false;
        }
        return true;
    }
    
    public boolean eliminarCatDirecciones(CatDirecciones x){
        try{
            String sql = "DELETE FROM dbo.Cat_Direcciones WHERE IDDireccion=?" ; 
            PreparedStatement stmt = con.prepareStatement(sql);

            stmt.setInt(1, x.getIdDireccion());
            
            stmt.executeUpdate();
        }catch(SQLException e){
            return false;
        }
        return true;
    }
    
    public boolean eliminarCatDirecciones(int x){
         try{
            String sql = "DELETE FROM dbo.Cat_Direcciones WHERE IDDireccion=?" ; 
            PreparedStatement stmt = con.prepareStatement(sql);

            stmt.setInt(1, x);
            
            stmt.executeUpdate();
        }catch(SQLException e){
            return false;
        }
        return true;
    }
    
    public ArrayList<CatDirecciones> obtenerCatDirecciones(){
        ArrayList<CatDirecciones> direcciones = new ArrayList<CatDirecciones>();
        ResultSet result;
       
        try{
            PreparedStatement stmt = con.prepareStatement("SELECT * FROM dbo.Cat_Direcciones");   
            result = stmt.executeQuery();
            
            while(result.next()){
                CatDirecciones p = new CatDirecciones(
                        result.getInt("IDDireccion"),
                        result.getInt("IDUsuario"),
                        result.getInt("IDMunicipio"),
                        result.getInt("NoExterior"),
                        result.getInt("CodigoPostal"),
                        result.getString("NoInterior"),
                        result.getString("Calle")
                );
             
                direcciones.add(p);
            }
            
        }catch(SQLException e){
            System.out.println("Error en la consulta");
            return null;
        }
        
        return direcciones;
    }
    
    public CatDirecciones obtenerCatDireccion(int id){
        ArrayList<CatDirecciones> direcciones = new ArrayList<CatDirecciones>(obtenerCatDirecciones());
        
        for(int i = 0; i<direcciones.size(); i++){
            if(direcciones.get(i).getIdDireccion() == id)
                return direcciones.get(i);
        }
        
        return null;
    }
    
    
    
    /*****************************************************************************/
    /*****************************************************************************/
    /******************************CatEditorial***********************************/
    /*****************************************************************************/
    /*****************************************************************************/
    
    public boolean insertarCatEditorial(CatEditorial x){
        try{
            String sql = "INSERT INTO dbo.Cat_Editorial(Nombre) VALUES (?)" ; 
            PreparedStatement stmt = con.prepareStatement(sql);

            stmt.setString(1, x.getNombre());
            
            stmt.executeUpdate();
        }catch(SQLException e){
            return false;
        }
        return true;
    }
    
    public boolean actualizarCatEditorial(CatEditorial x){
        try{
            String sql = "UPDATE dbo.Cat_Editorial SET Nombre=? WHERE IDEditorial=?"; 
            PreparedStatement stmt = con.prepareStatement(sql);

            stmt.setString(1, x.getNombre());
            
            stmt.setInt(2, x.getIdEditorial());
            
            stmt.executeUpdate();
        }catch(SQLException e){
            return false;
        }
        return true;
    }
    
    public boolean eliminarCatEditorial(CatEditorial x){
        try{
            String sql = "DELETE FROM dbo.Cat_Editorial WHERE IDEditorial=?" ; 
            PreparedStatement stmt = con.prepareStatement(sql);

            stmt.setInt(1, x.getIdEditorial());
            
            stmt.executeUpdate();
        }catch(SQLException e){
            return false;
        }
        return true;
    }
    
    public boolean eliminarCatEditoriales(int x){
         try{
            String sql = "DELETE FROM dbo.Cat_Editorial WHERE IDEditorial=?" ; 
            PreparedStatement stmt = con.prepareStatement(sql);

            stmt.setInt(1, x);
            
            stmt.executeUpdate();
        }catch(SQLException e){
            return false;
        }
        return true;
    }
    
    public ArrayList<CatEditorial> obtenerCatEditoriales(){
        ArrayList<CatEditorial> editoriales = new ArrayList<CatEditorial>();
        ResultSet result;
       
        try{
            PreparedStatement stmt = con.prepareStatement("SELECT * FROM dbo.Cat_Editorial");   
            result = stmt.executeQuery();
            
            while(result.next()){
                CatEditorial p = new CatEditorial(
                        result.getInt("IDEditorial"),
                        result.getString("Nombre")
                );
             
                editoriales.add(p);
            }
            
        }catch(SQLException e){
            System.out.println("Error en la consulta");
            return null;
        }
        
        return editoriales;
    }
    
    public CatEditorial obtenerCatEditorial(int id){
        ArrayList<CatEditorial> editoriales = new ArrayList<CatEditorial>(obtenerCatEditoriales());
        
        for(int i = 0; i<editoriales.size(); i++){
            if(editoriales.get(i).getIdEditorial() == id)
                return editoriales.get(i);
        }
        
        return null;
    }
    
    
    
    /*****************************************************************************/
    /*****************************************************************************/
    /******************************CatEstados*************************************/
    /*****************************************************************************/
    /*****************************************************************************/
    
    public boolean insertarCatEstados(CatEditorial x){
        try{
            String sql = "INSERT INTO dbo.Cat_Estados(Nombre) VALUES (?)" ; 
            PreparedStatement stmt = con.prepareStatement(sql);

            stmt.setString(1, x.getNombre());
            
            stmt.executeUpdate();
        }catch(SQLException e){
            return false;
        }
        return true;
    }
    
    public boolean actualizarCatEstados(CatEstados x){
        try{
            String sql = "UPDATE dbo.Cat_Estados SET Nombre=? WHERE IDEstado=?"; 
            PreparedStatement stmt = con.prepareStatement(sql);

            stmt.setString(1, x.getNombre());
            
            stmt.setInt(2, x.getIdEstados());
            
            stmt.executeUpdate();
        }catch(SQLException e){
            return false;
        }
        return true;
    }
    
    public boolean eliminarCatEstados(CatEstados x){
        try{
            String sql = "DELETE FROM dbo.Cat_Estados WHERE IDEstado=?" ; 
            PreparedStatement stmt = con.prepareStatement(sql);

            stmt.setInt(1, x.getIdEstados());
            
            stmt.executeUpdate();
        }catch(SQLException e){
            return false;
        }
        return true;
    }
    
    public boolean eliminarCatEstados(int x){
         try{
            String sql = "DELETE FROM dbo.Cat_Estados WHERE IDEstado=?" ; 
            PreparedStatement stmt = con.prepareStatement(sql);

            stmt.setInt(1, x);
            
            stmt.executeUpdate();
        }catch(SQLException e){
            return false;
        }
        return true;
    }
    
    public ArrayList<CatEstados> obtenerCatEstados(){
        ArrayList<CatEstados> estados = new ArrayList<CatEstados>();
        ResultSet result;
       
        try{
            PreparedStatement stmt = con.prepareStatement("SELECT * FROM dbo.Cat_Estados");   
            result = stmt.executeQuery();
            
            while(result.next()){
                CatEstados p = new CatEstados(
                        result.getInt("IDEstado"),
                        result.getString("Nombre")
                );
             
                estados.add(p);
            }
            
        }catch(SQLException e){
            System.out.println("Error en la consulta");
            return null;
        }
        
        return estados;
    }
    
    public CatEstados obtenerCatEstados(int id){
        ArrayList<CatEstados> estados = new ArrayList<CatEstados>(obtenerCatEstados());
        
        for(int i = 0; i<estados.size(); i++){
            if(estados.get(i).getIdEstados() == id)
                return estados.get(i);
        }
        
        return null;
    }
    
    
    
    /*****************************************************************************/
    /*****************************************************************************/
    /***************************CatEstadosMunicipios******************************/
    /*****************************************************************************/
    /*****************************************************************************/
    
    public boolean insertarCatEstadosMunicipios(CatEstadosMunicipios x){
        try{
            String sql = "INSERT INTO dbo.Cat_EstadosMunicipios(IDEstado,IDMunicipio) VALUES (?,?)" ; 
            PreparedStatement stmt = con.prepareStatement(sql);

            stmt.setInt(1, x.getIdEstado());
            stmt.setInt(2, x.getIdMunicipio());
            
            stmt.executeUpdate();
        }catch(SQLException e){
            return false;
        }
        return true;
    }
    
    public boolean actualizarCatEstadosMunicipios(CatEstadosMunicipios x){
        try{
            String sql = "UPDATE dbo.Cat_EstadosMunicipios SET IDEstado=?,IDMunicipio=? WHERE IDEstadoMunicipio=?"; 
            PreparedStatement stmt = con.prepareStatement(sql);

            stmt.setInt(1, x.getIdEstado());
            stmt.setInt(2, x.getIdMunicipio());
            
            stmt.setInt(3, x.getIdEstadoMunicipio());
            
            stmt.executeUpdate();
        }catch(SQLException e){
            return false;
        }
        return true;
    }
    
    public boolean eliminarCatEstadosMunicipios(CatEstadosMunicipios x){
        try{
            String sql = "DELETE FROM dbo.Cat_EstadosMunicipios WHERE IDEstadoMunicipio=?" ; 
            PreparedStatement stmt = con.prepareStatement(sql);

            stmt.setInt(1, x.getIdEstadoMunicipio());
            
            stmt.executeUpdate();
        }catch(SQLException e){
            return false;
        }
        return true;
    }
    
    public boolean eliminarCatEstadosMunicipios(int x){
         try{
            String sql = "DELETE FROM dbo.Cat_EstadosMunicipios WHERE IDEstadoMunicipio=?" ; 
            PreparedStatement stmt = con.prepareStatement(sql);

            stmt.setInt(1, x);
            
            stmt.executeUpdate();
        }catch(SQLException e){
            return false;
        }
        return true;
    }
    
    public ArrayList<CatEstadosMunicipios> obtenerCatEstadosMunicipios(){
        ArrayList<CatEstadosMunicipios> estadoMunicipios = new ArrayList<CatEstadosMunicipios>();
        ResultSet result;
       
        try{
            PreparedStatement stmt = con.prepareStatement("SELECT * FROM dbo.Cat_EstadosMunicipios");   
            result = stmt.executeQuery();
            
            while(result.next()){
                CatEstadosMunicipios p = new CatEstadosMunicipios(
                        result.getInt("IDEstadoMunicipio"),
                        result.getInt("IDEstado"),
                        result.getInt("IDMunicipio")
                );
             
                estadoMunicipios.add(p);
            }
            
        }catch(SQLException e){
            System.out.println("Error en la consulta");
            return null;
        }
        
        return estadoMunicipios;
    }
    
    public CatEstadosMunicipios obtenerCatEstadosMunicipios(int id){
        ArrayList<CatEstadosMunicipios> estadoMunicipios = new ArrayList<CatEstadosMunicipios>(obtenerCatEstadosMunicipios());
        
        for(int i = 0; i<estadoMunicipios.size(); i++){
            if(estadoMunicipios.get(i).getIdEstadoMunicipio() == id)
                return estadoMunicipios.get(i);
        }
        
        return null;
    }
    
    
    
    /*****************************************************************************/
    /*****************************************************************************/
    /***************************CatMunicipios*************************************/
    /*****************************************************************************/
    /*****************************************************************************/
    
    public boolean insertarCatMunicipios(CatMunicipios x){
        try{
            String sql = "INSERT INTO dbo.Cat_Municipios(Nombre) VALUES (?)" ; 
            PreparedStatement stmt = con.prepareStatement(sql);

            stmt.setString(1, x.getNombre());
            
            stmt.executeUpdate();
        }catch(SQLException e){
            return false;
        }
        return true;
    }
    
    public boolean actualizarCatMunicipios(CatMunicipios x){
        try{
            String sql = "UPDATE dbo.Cat_Municipios SET Nombre=? WHERE IDMunicipio=?"; 
            PreparedStatement stmt = con.prepareStatement(sql);

            stmt.setString(1, x.getNombre());
            stmt.setInt(2, x.getIdMunicipio());
            
            stmt.executeUpdate();
        }catch(SQLException e){
            return false;
        }
        return true;
    }
    
    public boolean eliminarCatMunicipios(CatMunicipios x){
        try{
            String sql = "DELETE FROM dbo.Cat_Municipios WHERE IDMunicipio=?" ; 
            PreparedStatement stmt = con.prepareStatement(sql);

            stmt.setInt(1, x.getIdMunicipio());
            
            stmt.executeUpdate();
        }catch(SQLException e){
            return false;
        }
        return true;
    }
    
    public boolean eliminarCatMunicipios(int x){
         try{
            String sql = "DELETE FROM dbo.Cat_Municipios WHERE IDMunicipio=?" ; 
            PreparedStatement stmt = con.prepareStatement(sql);

            stmt.setInt(1, x);
            
            stmt.executeUpdate();
        }catch(SQLException e){
            return false;
        }
        return true;
    }
    
    public ArrayList<CatMunicipios> obtenerCatMunicipios(){
        ArrayList<CatMunicipios> municipios = new ArrayList<CatMunicipios>();
        ResultSet result;
       
        try{
            PreparedStatement stmt = con.prepareStatement("SELECT * FROM dbo.Cat_Municipios");   
            result = stmt.executeQuery();
            
            while(result.next()){
                CatMunicipios p = new CatMunicipios(
                        result.getInt("IDMunicipio"),
                        result.getString("Nombre")
                );
             
                municipios.add(p);
            }
            
        }catch(SQLException e){
            System.out.println("Error en la consulta");
            return null;
        }
        
        return municipios;
    }
    
    public CatMunicipios obtenerCatMunicipios(int id){
        ArrayList<CatMunicipios> municipios = new ArrayList<CatMunicipios>(obtenerCatMunicipios());
        
        for(int i = 0; i<municipios.size(); i++){
            if(municipios.get(i).getIdMunicipio() == id)
                return municipios.get(i);
        }
        
        return null;
    }
    
    
    
    /*****************************************************************************/
    /*****************************************************************************/
    /***************************CatPaises*****************************************/
    /*****************************************************************************/
    /*****************************************************************************/
    
    public boolean insertarCatPaises(CatPaises x){
        try{
            String sql = "INSERT INTO dbo.Cat_Paises(Nombre,ISO3) VALUES (?,?)" ; 
            PreparedStatement stmt = con.prepareStatement(sql);

            stmt.setString(1, x.getNombre());
            stmt.setString(2, x.getIso3());
            
            stmt.executeUpdate();
        }catch(SQLException e){
            return false;
        }
        return true;
    }
    
    public boolean actualizarCatPaises(CatPaises x){
        try{
            String sql = "UPDATE dbo.Cat_Paises SET Nombre=?,ISO3=? WHERE IDPais=?"; 
            PreparedStatement stmt = con.prepareStatement(sql);

            stmt.setString(1, x.getNombre());
            stmt.setString(2, x.getIso3());
            stmt.setInt(3, x.getIdPais());
            
            stmt.executeUpdate();
        }catch(SQLException e){
            return false;
        }
        return true;
    }
    
    public boolean eliminarCatPaises(CatPaises x){
        try{
            String sql = "DELETE FROM dbo.Cat_Paises WHERE IDPais=?" ; 
            PreparedStatement stmt = con.prepareStatement(sql);

            stmt.setInt(1, x.getIdPais());
            
            stmt.executeUpdate();
        }catch(SQLException e){
            return false;
        }
        return true;
    }
    
    public boolean eliminarCatPaises(int x){
         try{
            String sql = "DELETE FROM dbo.Cat_Paises WHERE IDPais=?" ; 
            PreparedStatement stmt = con.prepareStatement(sql);

            stmt.setInt(1, x);
            
            stmt.executeUpdate();
        }catch(SQLException e){
            return false;
        }
        return true;
    }
    
    public ArrayList<CatPaises> obtenerCatPaises(){
        ArrayList<CatPaises> paises = new ArrayList<CatPaises>();
        ResultSet result;
       
        try{
            PreparedStatement stmt = con.prepareStatement("SELECT * FROM dbo.Cat_Paises");   
            result = stmt.executeQuery();
            
            while(result.next()){
                CatPaises p = new CatPaises(
                        result.getInt("IDPais"),
                        result.getString("Nombre"),
                        result.getString("ISO3")
                );
             
                paises.add(p);
            }
            
        }catch(SQLException e){
            System.out.println("Error en la consulta");
            return null;
        }
        
        return paises;
    }
    
    public CatPaises obtenerCatPaises(int id){
        ArrayList<CatPaises> paises = new ArrayList<CatPaises>(obtenerCatPaises());
        
        for(int i = 0; i<paises.size(); i++){
            if(paises.get(i).getIdPais() == id)
                return paises.get(i);
        }
        
        return null;
    }
    
    
    
    /*****************************************************************************/
    /*****************************************************************************/
    /******************************CatLibros**************************************/
    /*****************************************************************************/
    /*****************************************************************************/
    
    public boolean insertarCatLibros(MtoCatLibros x){
        try{
            String sql = "INSERT INTO dbo.MtoCat_Libros(ISBN,Titulo,Autor,Sinopsis,Descontinuado,Paginas,Revision,Ano,Precio,Stock,IDEtorial,IDPais,IDCategoria,Imagen) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)" ; 
            PreparedStatement stmt = con.prepareStatement(sql);

            stmt.setString(1, x.getIsbn());
            stmt.setString(2, x.getTitulo());
            stmt.setString(3, x.getAutor());
            stmt.setString(4, x.getSinopsis());
            stmt.setBoolean(5, x.isDescontinuado());
            stmt.setInt(6, x.getPaginas());
            stmt.setInt(7, x.getRevision());
            stmt.setInt(8, x.getAno());
            stmt.setFloat(9, x.getPrecio());
            stmt.setInt(10, x.getStock());
            stmt.setInt(11, x.getIdEditorial());
            stmt.setInt(12, x.getIdPais());
            stmt.setInt(13, x.getIdCategoria());
            stmt.setString(14, x.getImagen());
            
            stmt.executeUpdate();
        }catch(SQLException e){
            return false;
        }
        return true;
    }
    
    public boolean actualizarMtoCatLibros(MtoCatLibros x){
        try{
            String sql = "UPDATE dbo.MtoCat_Libros SET ISBN=?,Titulo=?,Autor=?,Sinopsis=?,Descontinuado=?,Paginas=?,Revision=?,Ano=?,Precio=?,Stock=?,IDEtorial=?,IDPais=?,IDCategoria=?,Imagen=? WHERE IDLibro=?"; 
            PreparedStatement stmt = con.prepareStatement(sql);

            stmt.setString(1, x.getIsbn());
            stmt.setString(2, x.getTitulo());
            stmt.setString(3, x.getAutor());
            stmt.setString(4, x.getSinopsis());
            stmt.setBoolean(5, x.isDescontinuado());
            stmt.setInt(6, x.getPaginas());
            stmt.setInt(7, x.getRevision());
            stmt.setInt(8, x.getAno());
            stmt.setFloat(9, x.getPrecio());
            stmt.setInt(10, x.getStock());
            stmt.setInt(11, x.getIdEditorial());
            stmt.setInt(12, x.getIdPais());
            stmt.setInt(13, x.getIdCategoria());
            stmt.setString(14, x.getImagen());
            stmt.setInt(15, x.getIdLibro());
            
            stmt.executeUpdate();
        }catch(SQLException e){
            return false;
        }
        return true;
    }
    
    public boolean eliminarMtoCatLibros(MtoCatLibros x){
        try{
            String sql = "DELETE FROM dbo.MtoCat_Libros WHERE IDLibro=?" ; 
            PreparedStatement stmt = con.prepareStatement(sql);

            stmt.setInt(1, x.getIdLibro());
            
            stmt.executeUpdate();
        }catch(SQLException e){
            return false;
        }
        return true;
    }
    
    public boolean eliminarMtoCatLibros(int x){
         try{
            String sql = "DELETE FROM dbo.MtoCat_Libros WHERE IDLibro=?" ; 
            PreparedStatement stmt = con.prepareStatement(sql);

            stmt.setInt(1, x);
            
            stmt.executeUpdate();
        }catch(SQLException e){
            return false;
        }
        return true;
    }
    
    public ArrayList<MtoCatLibros> obtenerMtoCatLibros(){
        ArrayList<MtoCatLibros> direcciones = new ArrayList<MtoCatLibros>();
        ResultSet result;
       
        try{
            PreparedStatement stmt = con.prepareStatement("SELECT * FROM dbo.MtoCat_Libros");   
            result = stmt.executeQuery();
            
            while(result.next()){
                MtoCatLibros p = new MtoCatLibros(
                        result.getInt("IDLibro"),
                        result.getString("ISBN"),
                        result.getString("Titulo"),
                        result.getString("Autor"),
                        result.getString("Sinopsis"),
                        result.getBoolean("Descontinuado"),
                        result.getInt("Paginas"),
                        result.getInt("Revision"),
                        result.getInt("Ano"),
                        result.getFloat("Precio"),
                        result.getInt("Stock"),
                        result.getInt("IDEtorial"),
                        result.getInt("IDPais"),
                        result.getInt("IDCategoria"),
                        result.getString("Imagen")
                );
             
                direcciones.add(p);
            }
            
        }catch(SQLException e){
            System.out.println("Error en la consulta");
            return null;
        }
        
        return direcciones;
    }
    
    public MtoCatLibros obtenerMtoCatLibros(int id){
        ArrayList<MtoCatLibros> libros = new ArrayList<MtoCatLibros>(obtenerMtoCatLibros());
        
        for(int i = 0; i<libros.size(); i++){
            if(libros.get(i).getIdLibro() == id)
                return libros.get(i);
        }
        
        return null;
    }
    
    
    
    /*****************************************************************************/
    /*****************************************************************************/
    /******************************MtoCatUsuarios*********************************/
    /*****************************************************************************/
    /*****************************************************************************/
    
    public boolean insertarMtoCatUsuarios(MtoCatUsuarios x){
        try{
            String sql = "INSERT INTO dbo.MtoCat_Usuarios(Nombre,Apellido) VALUES (?,?)" ; 
            PreparedStatement stmt = con.prepareStatement(sql);

            stmt.setString(1, x.getNombre());
            stmt.setString(2, x.getApellido());
            
            stmt.executeUpdate();
        }catch(SQLException e){
            return false;
        }
        return true;
    }
    
    public boolean actualizarMtoCatUsuarios(MtoCatUsuarios x){
        try{
            String sql = "UPDATE dbo.MtoCat_Usuarios SET Nombre=?,Apellido=? WHERE IDUsuario=?"; 
            PreparedStatement stmt = con.prepareStatement(sql);

            stmt.setString(1, x.getNombre());
            stmt.setString(2, x.getApellido());
            stmt.setInt(3, x.getIdUsuario());
            
            stmt.executeUpdate();
        }catch(SQLException e){
            return false;
        }
        return true;
    }
    
    public boolean eliminarMtoCatUsuarios(MtoCatUsuarios x){
        try{
            String sql = "DELETE FROM dbo.MtoCat_Usuarios WHERE IDUsuario=?" ; 
            PreparedStatement stmt = con.prepareStatement(sql);

            stmt.setInt(1, x.getIdUsuario());
            
            stmt.executeUpdate();
        }catch(SQLException e){
            return false;
        }
        return true;
    }
    
    public boolean eliminarMtoCatUsuarios(int x){
         try{
            String sql = "DELETE FROM dbo.MtoCat_Usuarios WHERE IDDireccion=?" ; 
            PreparedStatement stmt = con.prepareStatement(sql);

            stmt.setInt(1, x);
            
            stmt.executeUpdate();
        }catch(SQLException e){
            return false;
        }
        return true;
    }
    
    public ArrayList<MtoCatUsuarios> obtenerMtoCatUsuarios(){
        ArrayList<MtoCatUsuarios> usuarios = new ArrayList<MtoCatUsuarios>();
        ResultSet result;
       
        try{
            PreparedStatement stmt = con.prepareStatement("SELECT * FROM dbo.MtoCat_Usuarios");   
            result = stmt.executeQuery();
            
            while(result.next()){
                MtoCatUsuarios p = new MtoCatUsuarios(
                        result.getInt("IDUsuario"),
                        result.getString("Nombre"),
                        result.getString("Apellido")
                );
             
                usuarios.add(p);
            }
            
        }catch(SQLException e){
            System.out.println("Error en la consulta");
            return null;
        }
        
        return usuarios;
    }
    
    public MtoCatUsuarios obtenerMtoCatUsuario(int id){
        ArrayList<MtoCatUsuarios> usuarios = new ArrayList<MtoCatUsuarios>(obtenerMtoCatUsuarios());
        
        for(int i = 0; i<usuarios.size(); i++){
            if(usuarios.get(i).getIdUsuario() == id)
                return usuarios.get(i);
        }
        
        return null;
    }
    
    
    /*****************************************************************************/
    /*****************************************************************************/
    /******************************TraCompras*************************************/
    /*****************************************************************************/
    /*****************************************************************************/
    
    public boolean insertarTraCompras(TraCompras x){
        try{
            String sql = "INSERT INTO dbo.Tra_Compras(PrecioTotal,FechaCompra,Pagado,IDUsuario) VALUES (?,?,?,?)" ; 
            PreparedStatement stmt = con.prepareStatement(sql);

            stmt.setFloat(1, x.getPrecioTotal());
            stmt.setString(2, x.getFechaCompra());
            stmt.setBoolean(3,x.isPagado());
            stmt.setInt(4, x.getIdUsuario());
            
            stmt.executeUpdate();
        }catch(SQLException e){
            return false;
        }
        return true;
    }
    
    public boolean actualizarTraCompras(TraCompras x){
        try{
            String sql = "UPDATE dbo.Tra_Compras SET PrecioTotal=?,FechaCompra=?,Pagado=?,IDUsuario=? WHERE IDCompra=?"; 
            PreparedStatement stmt = con.prepareStatement(sql);

            stmt.setFloat(1, x.getPrecioTotal());
            stmt.setString(2, x.getFechaCompra());
            stmt.setBoolean(3,x.isPagado());
            stmt.setInt(4, x.getIdUsuario());
            
            stmt.setInt(5, x.getIdCompra());
            
            stmt.executeUpdate();
        }catch(SQLException e){
            return false;
        }
        return true;
    }
    
    public boolean eliminarTraCompras(TraCompras x){
        try{
            String sql = "DELETE FROM dbo.Tra_Compras WHERE IDCompra=?" ; 
            PreparedStatement stmt = con.prepareStatement(sql);

            stmt.setInt(1, x.getIdCompra());
            
            stmt.executeUpdate();
        }catch(SQLException e){
            return false;
        }
        return true;
    }
    
    public boolean eliminarTraCompras(int x){
         try{
            String sql = "DELETE FROM  dbo.Tra_Compras WHERE IDCompra=?" ; 
            PreparedStatement stmt = con.prepareStatement(sql);

            stmt.setInt(1, x);
            
            stmt.executeUpdate();
        }catch(SQLException e){
            return false;
        }
        return true;
    }
    
    public ArrayList<TraCompras> obtenerTraCompras(){
        ArrayList<TraCompras> compras = new ArrayList<TraCompras>();
        ResultSet result;
       
        try{
            PreparedStatement stmt = con.prepareStatement("SELECT * FROM dbo.Tra_Compras");   
            result = stmt.executeQuery();
            
            while(result.next()){
                TraCompras p = new TraCompras(
                        result.getInt("IDCompra"),
                        result.getFloat("PrecioTotal"),
                        result.getString("FechaCompra"),
                        result.getBoolean("Pagado"),
                        result.getInt("IDUsuario")
                );
             
                compras.add(p);
            }
            
        }catch(SQLException e){
            System.out.println("Error en la consulta");
            return null;
        }
        
        return compras;
    }
    
    public TraCompras obtenerTraCompra(int id){
        ArrayList<TraCompras> compras = new ArrayList<TraCompras>(obtenerTraCompras());
        
        for(int i = 0; i<compras.size(); i++){
            if(compras.get(i).getIdCompra() == id)
                return compras.get(i);
        }
        
        return null;
    }
    
    
    
    /*****************************************************************************/
    /*****************************************************************************/
    /****************************TraConceptoCompras*******************************/
    /*****************************************************************************/
    /*****************************************************************************/
    
    public boolean insertarTraConceptoCompras(TraConceptoCompra x){
        try{
            String sql = "INSERT INTO dbo.Tra_ConceptoCompra(IDCompra,IDLibro,Cantidad) VALUES (?,?,?)" ; 
            PreparedStatement stmt = con.prepareStatement(sql);

            stmt.setInt(1, x.getIdCompra());
            stmt.setInt(2, x.getIdLibro());
            stmt.setInt(3, x.getCantidad());
            
            stmt.executeUpdate();
        }catch(SQLException e){
            return false;
        }
        return true;
    }
    
    public boolean actualizarTraConceptoCompras(TraConceptoCompra x){
        try{
            String sql = "UPDATE dbo.Tra_ConceptoCompra SET IDCompra=?,IDLibro=?,Cantidad=? WHERE Tra_Compras=?"; 
            PreparedStatement stmt = con.prepareStatement(sql);

            stmt.setInt(1, x.getIdCompra());
            stmt.setInt(2, x.getIdLibro());
            stmt.setInt(3, x.getCantidad());

            stmt.setInt(4, x.getTraCompras());
            
            stmt.executeUpdate();
        }catch(SQLException e){
            return false;
        }
        return true;
    }
    
    public boolean eliminarTraConceptoCompras(TraConceptoCompra x){
        try{
            String sql = "DELETE FROM dbo.Tra_ConceptoCompra WHERE Tra_Compras=?" ; 
            PreparedStatement stmt = con.prepareStatement(sql);

            stmt.setInt(1, x.getTraCompras());
            
            stmt.executeUpdate();
        }catch(SQLException e){
            return false;
        }
        return true;
    }
    
    public boolean eliminarTraConceptoCompras(int x){
         try{
            String sql = "DELETE FROM dbo.Tra_ConceptoCompra WHERE Tra_Compras=?" ; 
            PreparedStatement stmt = con.prepareStatement(sql);

            stmt.setInt(1, x);
            
            stmt.executeUpdate();
        }catch(SQLException e){
            return false;
        }
        return true;
    }
    
    public ArrayList<TraConceptoCompra> obtenerTraConceptoCompras(){
        ArrayList<TraConceptoCompra> compras = new ArrayList<TraConceptoCompra>();
        ResultSet result;
       
        try{
            PreparedStatement stmt = con.prepareStatement("SELECT * FROM dbo.Tra_ConceptoCompra");   
            result = stmt.executeQuery();
            
            while(result.next()){
                TraConceptoCompra p = new TraConceptoCompra(
                        result.getInt("Tra_Compras"),
                        result.getInt("IDCompra"),
                        result.getInt("IDLibro"),
                        result.getInt("Cantidad")
                );
             
                compras.add(p);
            }
            
        }catch(SQLException e){
            System.out.println("Error en la consulta");
            return null;
        }
        
        return compras;
    }
    
    public TraConceptoCompra obtenerTraConceptoCompra(int id){
        ArrayList<TraConceptoCompra> conceptos = new ArrayList<TraConceptoCompra>(obtenerTraConceptoCompras());
        
        for(int i = 0; i<conceptos.size(); i++){
            if(conceptos.get(i).getIdCompra() == id)
                return conceptos.get(i);
        }
        
        return null;
    }
    
}
