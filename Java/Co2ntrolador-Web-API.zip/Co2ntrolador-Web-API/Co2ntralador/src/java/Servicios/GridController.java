/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servicios;

import DB.DBController;
import Modelos.MtoCatLibros;
import java.util.ArrayList;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;


@Path("api/[controller]") 
@Produces(MediaType.APPLICATION_JSON) 
@Consumes(MediaType.APPLICATION_JSON) 
public class GridController {
    
   
    @GET  
    @Produces(MediaType.APPLICATION_JSON)
    public Response getCategorias(){
         DBController db = new DBController();
         return Response.ok(db.obtenerCatCategorias()).build();    
    }
    
    
    
    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getBook(@PathParam("id") int id){
         DBController db = new DBController();
         
         ArrayList<MtoCatLibros> libros = new ArrayList<MtoCatLibros>(db.obtenerMtoCatLibros());
          ArrayList<MtoCatLibros> librosFinal = new ArrayList<MtoCatLibros>();
         for(int i=0; i< libros.size();i++){
             if(libros.get(i).getIdCategoria() == id){
                 librosFinal.add(libros.get(i));
             }
         }
         
         return Response.ok(librosFinal).build();    
    }
}
