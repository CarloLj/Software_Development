/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servicios;

import DB.DBController;
import com.google.gson.Gson;
import Modelos.CatEditorial;
import java.util.ArrayList;
import javax.ws.rs.Consumes; 
import javax.ws.rs.DELETE;
import javax.ws.rs.GET; 
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path; 
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces; 
import javax.ws.rs.core.MediaType; 
import javax.ws.rs.core.Response; 

@Path("api/CatEditorial") 
@Produces(MediaType.APPLICATION_JSON) 
@Consumes(MediaType.APPLICATION_JSON)
/**
 * Controlador para editoriales
 * @author Mauricio Andres Flores Perez
 */
public class CatEditorialService {
    
    @GET  
    @Produces(MediaType.APPLICATION_JSON)
    public Response getEditoriales() { 
        Gson gson = new Gson();
        DBController db = new DBController();
        String Json = gson.toJson(db.obtenerCatEditoriales());
        return Response.ok(Json).build();
    }
    
    @GET  
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getEditorial(@PathParam("id") int id) { 
        Gson gson = new Gson();
        DBController db = new DBController();
        String Json = gson.toJson(db.obtenerCatEditorial(id));
        return Response.ok(Json).build();
    }
    
    @DELETE 
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response deleteEditorial(@PathParam("id") int id) { 
        DBController db = new DBController();
        db.eliminarCatEditoriales(id);
        return Response.ok().build();
    }
    
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response postEditorial(CatEditorial edit){
        DBController db = new DBController();
        db.insertarCatEditorial(edit);
        return Response.status(Response.Status.CREATED).entity(edit).build();
    }
    
    @PUT
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response putEditorial(CatEditorial edit){
        DBController db = new DBController();
        db.actualizarCatEditorial(edit);
        return Response.status(Response.Status.CREATED).entity(edit).build();
    }
    
}
