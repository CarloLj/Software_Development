/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servicios;

import DB.DBController;
import Modelos.MtoCatLibros;
import Modelos.TraCompras;
import com.google.gson.Gson;
import java.util.ArrayList;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("api/TraCompras") 
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class TraComprasService {
   
    @GET  
    @Produces(MediaType.APPLICATION_JSON)
    public Response getTraCompras() { 
        DBController db = new DBController();
        Gson gson = new Gson();
        ArrayList<TraCompras> compra = new ArrayList<TraCompras>(db.obtenerTraCompras());
        String Json = gson.toJson(compra);
        return Response.ok(Json).build();
    }
    
    @GET  
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getTraCompra(@PathParam("id") int id) { 
        DBController db = new DBController();
        TraCompras compra = db.obtenerTraCompra(id);
        Gson gson = new Gson();
        String txt = gson.toJson(compra);
        return Response.ok(txt).build();
    }
    
    @DELETE 
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response delteTraCompras(@PathParam("id") int id) { 
        DBController db = new DBController();
        db.eliminarTraCompras(id);
        return Response.ok().build();
    }
    
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response postTraCompras(TraCompras compra){
        DBController db = new DBController();
        db.insertarTraCompras(compra);
        return Response.status(Response.Status.CREATED).entity(compra).build();
    }
}

