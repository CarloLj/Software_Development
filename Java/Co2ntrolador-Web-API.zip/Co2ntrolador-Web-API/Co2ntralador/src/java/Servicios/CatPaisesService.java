/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servicios;

import DB.DBController;
import Modelos.CatPaises;
import com.google.gson.Gson;
import java.util.ArrayList;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

/**
 *
 * @author usuario
 */
@Path("api/CatPaises") 
@Produces(MediaType.APPLICATION_JSON) 
@Consumes(MediaType.APPLICATION_JSON)
public class CatPaisesService {
    @GET  
    @Produces(MediaType.APPLICATION_JSON)
    public Response getCatPaises() {
        
        DBController db = new DBController();
        ArrayList<CatPaises> cat = new ArrayList<CatPaises>(db.obtenerCatPaises());
        Gson gson = new Gson();
        String Json = gson.toJson(cat);
        //return Response.ok(txt,MediaType.APPLICATION_JSON).build();   
        return Response.ok(Json).build();

    } 
    @GET
    @Path("/{id}")
    public Response getCatPaises(@PathParam("id")int id)
    {
        DBController db = new DBController();
        CatPaises cat = db.obtenerCatPaises(id);
        Gson gson = new Gson();
        String Json = gson.toJson(cat);
        //return Response.ok(txt,MediaType.APPLICATION_JSON).build();   
        return Response.ok(Json).build();
    }
}
