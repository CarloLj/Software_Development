/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servicios;

import DB.DBController;
import Modelos.CatCategorias;
import Modelos.MtoCatLibros;
import java.util.ArrayList;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;


@Path("api/Inicio") 
@Produces(MediaType.APPLICATION_JSON) 
@Consumes(MediaType.APPLICATION_JSON) 
public class InicioPagWebController {
    
    @GET  
    @Produces(MediaType.APPLICATION_JSON)
    public Response getInicio(){
        DBController db = new DBController();
        ArrayList<CatCategorias> categorias = new ArrayList<CatCategorias>(db.obtenerCatCategorias()); 
        ArrayList<CatCategorias> categorias2 = new ArrayList<CatCategorias>(); 
        
        if(categorias.size() > 5){
            
            for(int i = 0; i<5;i++){
                categorias2.add(categorias.get(i));
            }
            
        }else{
            
            for(int i = 0; i<categorias.size();i++){
                categorias2.add(categorias.get(i));
            }
        }
         return Response.ok(categorias2).build(); 
    }
    
    @GET  
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response cantidadLibros(int id){
        int n = 0;
        
        DBController db = new DBController();
        ArrayList<MtoCatLibros> libros = new ArrayList<MtoCatLibros>(db.obtenerMtoCatLibros());
        
        for(int i=0; i<libros.size();i++){
            if(!libros.get(i).isDescontinuado() && libros.get(i).getIdCategoria() == id && libros.get(i).getStock() > 0)
                n++;
        }
        
        return Response.ok(n).build();    
    }
}
