/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servicios;

import DB.DBController;
import Modelos.CatCategorias;
import com.google.gson.Gson;
import java.util.ArrayList;
import javax.ws.rs.Consumes; 
import javax.ws.rs.GET; 
import javax.ws.rs.Path; 
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces; 
import javax.ws.rs.core.MediaType; 
import javax.ws.rs.core.Response; 

@Path("api/CatCategorias") 
@Produces(MediaType.APPLICATION_JSON) 
@Consumes(MediaType.APPLICATION_JSON) 
public class CatCategoriasService {
   
    @GET  
    @Produces(MediaType.APPLICATION_JSON)
    public Response getCatCategorias() { 
        DBController db = new DBController();
        ArrayList<CatCategorias> cat = new ArrayList<CatCategorias>(db.obtenerCatCategorias());
        String txt ="";
        Gson gson = new Gson();
        String Json="";
        for(int i= 0; i <cat.size(); i++){
            txt += cat.get(i).getNombre()+", ";
            Json = gson.toJson(db.obtenerCatCategoria(i).getNombre());
        }   
        return Response.ok(Json).build();

    } 
    
    @GET  
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getCatCategoria(@PathParam("id") int id) { 
        DBController db = new DBController();
        CatCategorias cat = db.obtenerCatCategoria(id);
        Gson gson = new Gson();
        String Json = gson.toJson(cat);
        String txt ="";
        txt += cat.getNombre();
        //return Response.ok(txt,MediaType.APPLICATION_JSON).build();   
        return Response.ok(Json).build();
    }
    
    
}
