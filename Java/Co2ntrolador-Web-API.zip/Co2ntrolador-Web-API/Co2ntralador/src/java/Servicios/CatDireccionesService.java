/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servicios;

import DB.DBController;
import com.google.gson.Gson;
import Modelos.CatDirecciones;
import java.util.ArrayList;
import javax.ws.rs.Consumes; 
import javax.ws.rs.DELETE;
import javax.ws.rs.GET; 
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path; 
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces; 
import javax.ws.rs.core.MediaType; 
import javax.ws.rs.core.Response; 

@Path("api/CatDirecciones") 
@Produces(MediaType.APPLICATION_JSON) 
@Consumes(MediaType.APPLICATION_JSON) 
/**
 * Controlador para las direcciones
 * @author Mauricio Andres Flores Perez
 */
public class CatDireccionesService {
    
    @GET  
    @Produces(MediaType.APPLICATION_JSON)
    public Response getDirecciones() { 
        Gson gson = new Gson();
        DBController db = new DBController();
        String Json = gson.toJson(db.obtenerCatDirecciones());
        return Response.ok(Json).build();
    }
    
    @GET  
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getDireccion(@PathParam("id") int id) {
        Gson gson = new Gson();
        DBController db = new DBController();
        String Json = gson.toJson(db.obtenerCatDireccion(id));
        return Response.ok(Json).build();
    }
    
    @DELETE 
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response deleteDireccion(@PathParam("id") int id) { 
        DBController db = new DBController();
        db.eliminarCatDirecciones(id);
        return Response.ok().build();
    }
    
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response postDireccion(CatDirecciones direcciones){
        DBController db = new DBController();
        db.insertarCatDirecciones(direcciones);
        return Response.status(Response.Status.CREATED).entity(direcciones).build();
    }
    
    @PUT
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response putDireccione(CatDirecciones direcciones){
        DBController db = new DBController();
        db.actualizarCatDirecciones(direcciones);
        return Response.status(Response.Status.CREATED).entity(direcciones).build();
    }
}
