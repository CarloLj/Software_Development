/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servicios;

import DB.DBController;
import Modelos.CatDirecciones;
import Modelos.CatEstados;
import Modelos.TraCompras;
import Modelos.TraConceptoCompra;
import java.util.ArrayList;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("api/[controller]") 
@Produces(MediaType.APPLICATION_JSON) 
@Consumes(MediaType.APPLICATION_JSON) 
public class DatosClienteService {
    
    @GET  
    @Path("Estado/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getEstados(@PathParam("id") int id) { 
        DBController db = new DBController();
        return Response.ok(db.obtenerCatEstados(id)).build();
    }
    
    @GET  
    @Path("DireccionExiste/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getDireccionExistente(@PathParam("id") int id) { 
        DBController db = new DBController();
        
        ArrayList<CatDirecciones> direcciones = new ArrayList<CatDirecciones>(db.obtenerCatDirecciones());
        
        for(int i=0; i<direcciones.size(); i++){
            if(direcciones.get(i).getIdUsuario() == id)
                return Response.ok(true).build();
        }
        
         return Response.ok(false).build();
    }
    
    @GET  
    @Path("Usuario/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getMtoCatUsuarios(@PathParam("id") int id) { 
        DBController db = new DBController();
        
        return Response.ok(db.obtenerMtoCatUsuario(id)).build();
    }
    
    
    @GET  
    @Path("Compra/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getCompras(@PathParam("id") int id) { 
        DBController db = new DBController();
        ArrayList<TraCompras> compras = new ArrayList<TraCompras>(db.obtenerTraCompras());
        ArrayList<TraCompras> compras2 = new ArrayList<TraCompras>();
        
        for(int i=0; i<compras.size(); i++){
            if(compras.get(i).getIdUsuario() == id)
                compras2.add(compras.get(i));
        }
        
        
        return Response.ok(compras2).build();
    }
    
    @GET  
    @Path("Compra/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getCompra(@PathParam("id") int id) { 
        DBController db = new DBController();
        ArrayList<TraConceptoCompra> conceptos = new ArrayList<TraConceptoCompra>(db.obtenerTraConceptoCompras());
        
        for(int i=0; i<conceptos.size(); i++){
            if(conceptos.get(i).getIdCompra() == id){
                 return Response.ok(conceptos.get(i)).build();
            }
        }
        
         return Response.ok(null).build();
    }
}
