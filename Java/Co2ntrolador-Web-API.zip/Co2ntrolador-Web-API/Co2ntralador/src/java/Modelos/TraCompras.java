/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelos;

import com.sun.istack.Nullable;
import java.time.LocalTime;
import java.util.ArrayList;

/**
 *
 * @author Propietario
 */
public class TraCompras {
    
    private int idCompra;
    private float precioTotal;
    private String fechaCompra;
    private boolean pagado;
    private int idUsuario;
    private ArrayList<TraConceptoCompra> traConceptoCompra;
    
    public TraCompras(){
        traConceptoCompra = new ArrayList<TraConceptoCompra>();
    }

    public TraCompras(int idCompra, float precioTotal, String fechaCompra, boolean pagado, int idUsuario) {
        this.idCompra = idCompra;
        this.precioTotal = precioTotal;
        this.fechaCompra = fechaCompra;
        this.pagado = pagado;
        this.idUsuario = idUsuario;
    }

    
    
    public int getIdCompra() {
        return idCompra;
    }

    public void setIdCompra(int idCompra) {
        this.idCompra = idCompra;
    }

    public float getPrecioTotal() {
        return precioTotal;
    }

    public void setPrecioTotal(float precioTotal) {
        this.precioTotal = precioTotal;
    }

    public String getFechaCompra() {
        return fechaCompra;
    }

    public void setFechaCompra(String fechaCompra) {
        this.fechaCompra = fechaCompra;
    }

    public boolean isPagado() {
        return pagado;
    }

    public void setPagado(boolean pagado) {
        this.pagado = pagado;
    }

    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    public ArrayList<TraConceptoCompra> getTraConceptoCompra() {
        return traConceptoCompra;
    }

    public void setTraConceptoCompra(ArrayList<TraConceptoCompra> traConceptoCompra) {
        this.traConceptoCompra = traConceptoCompra;
    }
    
    
}
