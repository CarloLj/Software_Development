/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelos;

import java.util.ArrayList;

/**
 *
 * @author Propietario
 */
public class CatPaises {
    
    private int idPais;
    private String nombre;
    private String iso3;
    private ArrayList<MtoCatLibros> mtoCatLibros;
    
    
    public CatPaises(){
        mtoCatLibros = new ArrayList<MtoCatLibros>();
    }

    public CatPaises(int idPais, String nombre, String iso3) {
        this.idPais = idPais;
        this.nombre = nombre;
        this.iso3 = iso3;
    }
    
    

    public int getIdPais() {
        return idPais;
    }

    public void setIdPais(int idPais) {
        this.idPais = idPais;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getIso3() {
        return iso3;
    }

    public void setIso3(String iso3) {
        this.iso3 = iso3;
    }

    public ArrayList<MtoCatLibros> getMtoCatLibros() {
        return mtoCatLibros;
    }

    public void setMtoCatLibros(ArrayList<MtoCatLibros> mtoCatLibros) {
        this.mtoCatLibros = mtoCatLibros;
    }
    
    
}
