/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelos;

/**
 *
 * @author Propietario
 */
public class CatDirecciones {
    
    private int idDireccion;
    private int idUsuario;
    private int idMunicipio;
    private int noExterior;
    private int codigoPostal;
    private String noInterior;
    private String calle;

    public CatDirecciones(int idDireccion, int idUsuario, int idMunicipio, int noExterior, int codigoPostal, String noInterior, String calle) {
        this.idDireccion = idDireccion;
        this.idUsuario = idUsuario;
        this.idMunicipio = idMunicipio;
        this.noExterior = noExterior;
        this.codigoPostal = codigoPostal;
        this.noInterior = noInterior;
        this.calle = calle;
    }

    public CatDirecciones(int idUsuario, int idMunicipio, int noExterior, int codigoPostal, String noInterior, String calle) {
        this.idUsuario = idUsuario;
        this.idMunicipio = idMunicipio;
        this.noExterior = noExterior;
        this.codigoPostal = codigoPostal;
        this.noInterior = noInterior;
        this.calle = calle;
    }
    

    public int getIdDireccion() {
        return idDireccion;
    }

    public void setIdDireccion(int idDireccion) {
        this.idDireccion = idDireccion;
    }

    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    public int getIdMunicipio() {
        return idMunicipio;
    }

    public void setIdMunicipio(int idMunicipio) {
        this.idMunicipio = idMunicipio;
    }

    public int getNoExterior() {
        return noExterior;
    }

    public void setNoExterior(int noExterior) {
        this.noExterior = noExterior;
    }

    public int getCodigoPostal() {
        return codigoPostal;
    }

    public void setCodigoPostal(int codigoPostal) {
        this.codigoPostal = codigoPostal;
    }

    public String getNoInterior() {
        return noInterior;
    }

    public void setNoInterior(String noInterior) {
        this.noInterior = noInterior;
    }

    public String getCalle() {
        return calle;
    }

    public void setCalle(String calle) {
        this.calle = calle;
    }
    
    
    
}
