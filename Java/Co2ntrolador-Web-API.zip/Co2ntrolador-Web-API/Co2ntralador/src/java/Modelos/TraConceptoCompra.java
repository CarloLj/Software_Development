/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelos;

/**
 *
 * @author Propietario
 */
public class TraConceptoCompra {
    
    private int traCompras;
    private int idCompra;
    private int idLibro;
    private int cantidad;

    public TraConceptoCompra(int traCompras, int idCompra, int idLibro, int cantidad) {
        this.traCompras = traCompras;
        this.idCompra = idCompra;
        this.idLibro = idLibro;
        this.cantidad = cantidad;
    }

    
    
    public int getTraCompras() {
        return traCompras;
    }

    public void setTraCompras(int traCompras) {
        this.traCompras = traCompras;
    }

    public int getIdCompra() {
        return idCompra;
    }

    public void setIdCompra(int idCompra) {
        this.idCompra = idCompra;
    }

    public int getIdLibro() {
        return idLibro;
    }

    public void setIdLibro(int idLibro) {
        this.idLibro = idLibro;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }
    
    
}
