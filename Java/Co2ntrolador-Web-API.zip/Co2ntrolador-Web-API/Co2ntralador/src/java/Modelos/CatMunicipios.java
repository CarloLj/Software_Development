/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelos;

import java.util.ArrayList;

/**
 *
 * @author Propietario
 */
public class CatMunicipios {
    
    private int idMunicipio;
    private String nombre;
    private ArrayList<CatDirecciones> catDirecciones;
    private ArrayList<CatEstadosMunicipios> catEstadosMunicipios;
    
    public CatMunicipios(){
        catDirecciones = new ArrayList<CatDirecciones>();
        catEstadosMunicipios = new ArrayList<CatEstadosMunicipios>();
    }

    public CatMunicipios(int idMunicipio, String nombre) {
        this.idMunicipio = idMunicipio;
        this.nombre = nombre;
        catDirecciones = new ArrayList<CatDirecciones>();
        catEstadosMunicipios = new ArrayList<CatEstadosMunicipios>();
    }
    
    public int getIdMunicipio() {
        return idMunicipio;
    }

    public void setIdMunicipio(int idMunicipio) {
        this.idMunicipio = idMunicipio;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public ArrayList<CatDirecciones> getCatDirecciones() {
        return catDirecciones;
    }

    public void setCatDirecciones(ArrayList<CatDirecciones> catDirecciones) {
        this.catDirecciones = catDirecciones;
    }

    public ArrayList<CatEstadosMunicipios> getCatEstadosMunicipios() {
        return catEstadosMunicipios;
    }

    public void setCatEstadosMunicipios(ArrayList<CatEstadosMunicipios> catEstadosMunicipios) {
        this.catEstadosMunicipios = catEstadosMunicipios;
    }
    
    
    
}
