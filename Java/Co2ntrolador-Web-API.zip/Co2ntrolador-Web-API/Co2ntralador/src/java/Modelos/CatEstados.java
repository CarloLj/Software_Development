/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelos;

import java.util.ArrayList;

/**
 *
 * @author Propietario
 */
public class CatEstados {
    
    private int idEstados;
    private String nombre;
    private ArrayList<CatEstadosMunicipios> catEstadosMunicipios;
    
    public CatEstados(){
        catEstadosMunicipios = new ArrayList<CatEstadosMunicipios>();
    }

    public CatEstados(int idEstados, String nombre) {
        this.idEstados = idEstados;
        this.nombre = nombre;
        catEstadosMunicipios = new ArrayList<CatEstadosMunicipios>();
    }
    
    

    public int getIdEstados() {
        return idEstados;
    }

    public void setIdEstados(int idEstados) {
        this.idEstados = idEstados;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public ArrayList<CatEstadosMunicipios> getCatEstadosMunicipios() {
        return catEstadosMunicipios;
    }

    public void setCatEstadosMunicipios(ArrayList<CatEstadosMunicipios> catEstadosMunicipios) {
        this.catEstadosMunicipios = catEstadosMunicipios;
    }
    
    
}
