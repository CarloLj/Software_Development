/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelos;

import java.util.ArrayList;

/**
 *
 * @author Propietario
 */
public class MtoCatLibros {
    
    private int idLibro;
    private String isbn;
    private String titulo;
    private String autor;
    private String sinopsis;
    private boolean descontinuado;
    private int paginas;
    private int revision;
    private int ano;
    private float precio;
    private int stock;
    private int idEditorial;
    private int idPais;
    private int idCategoria;
    private String imagen;
    
    private ArrayList<TraConceptoCompra> traConceptoCompra;
    
    public MtoCatLibros(){
        traConceptoCompra = new ArrayList<TraConceptoCompra>();
    }

    public MtoCatLibros(int idLibro, String isbn, String titulo, String autor, String sinopsis, boolean descontinuado, int paginas, int revision, int ano, float precio, int stock, int idEditorial, int idPais, int idCategoria, String imagen) {
        this.idLibro = idLibro;
        this.isbn = isbn;
        this.titulo = titulo;
        this.autor = autor;
        this.sinopsis = sinopsis;
        this.descontinuado = descontinuado;
        this.paginas = paginas;
        this.revision = revision;
        this.ano = ano;
        this.precio = precio;
        this.stock = stock;
        this.idEditorial = idEditorial;
        this.idPais = idPais;
        this.idCategoria = idCategoria;
        this.imagen = imagen;
    }
    
    

    public int getIdLibro() {
        return idLibro;
    }

    public void setIdLibro(int idLibro) {
        this.idLibro = idLibro;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getSinopsis() {
        return sinopsis;
    }

    public void setSinopsis(String sinopsis) {
        this.sinopsis = sinopsis;
    }

    public boolean isDescontinuado() {
        return descontinuado;
    }

    public void setDescontinuado(boolean descontinuado) {
        this.descontinuado = descontinuado;
    }

    public int getPaginas() {
        return paginas;
    }

    public void setPaginas(int paginas) {
        this.paginas = paginas;
    }

    public int getRevision() {
        return revision;
    }

    public void setRevision(int revision) {
        this.revision = revision;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }

    public float getPrecio() {
        return precio;
    }

    public void setPrecio(float precio) {
        this.precio = precio;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public int getIdEditorial() {
        return idEditorial;
    }

    public void setIdEditorial(int idEditorial) {
        this.idEditorial = idEditorial;
    }

    public int getIdPais() {
        return idPais;
    }

    public void setIdPais(int idPais) {
        this.idPais = idPais;
    }

    public int getIdCategoria() {
        return idCategoria;
    }

    public void setIdCategoria(int idCategoria) {
        this.idCategoria = idCategoria;
    }

    public String getImagen() {
        return imagen;
    }

    public void setImagen(String imagen) {
        this.imagen = imagen;
    }

    public ArrayList<TraConceptoCompra> getTraConceptoCompra() {
        return traConceptoCompra;
    }

    public void setTraConceptoCompra(ArrayList<TraConceptoCompra> traConceptoCompra) {
        this.traConceptoCompra = traConceptoCompra;
    }
    
    
    
    
}
