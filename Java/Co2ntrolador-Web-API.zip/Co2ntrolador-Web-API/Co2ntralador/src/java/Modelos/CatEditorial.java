/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelos;

import java.util.ArrayList;

/**
 *
 * @author Propietario
 */
public class CatEditorial {
    
    private int idEditorial;
    private String nombre;
    private ArrayList<MtoCatLibros> mtoCatLibros;
    
    public CatEditorial(){
        mtoCatLibros = new ArrayList<MtoCatLibros>();
    }

    public CatEditorial(int idEditorial, String nombre) {
        this.idEditorial = idEditorial;
        this.nombre = nombre;
        mtoCatLibros = new ArrayList<MtoCatLibros>();
    }
    
    public CatEditorial(String nombre) {
        this.nombre = nombre;
        mtoCatLibros = new ArrayList<MtoCatLibros>();
    }

    public int getIdEditorial() {
        return idEditorial;
    }

    public void setIdEditorial(int idEditorial) {
        this.idEditorial = idEditorial;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public ArrayList<MtoCatLibros> getMtoCatLibros() {
        return mtoCatLibros;
    }

    public void setMtoCatLibros(ArrayList<MtoCatLibros> mtoCatLibros) {
        this.mtoCatLibros = mtoCatLibros;
    }
    
    
}
