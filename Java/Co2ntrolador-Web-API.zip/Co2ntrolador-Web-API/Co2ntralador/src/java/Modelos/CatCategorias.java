/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelos;

import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @author Propietario
 */
public class CatCategorias {
    private int idCategoria;
    private String nombre;
    private ArrayList<MtoCatLibros> MtoCatLibro;
    
    public CatCategorias(){
        MtoCatLibro = new ArrayList<MtoCatLibros>();
    }

    public CatCategorias(int idCategoria, String nombre) {
        this.idCategoria = idCategoria;
        this.nombre = nombre;
        MtoCatLibro = new ArrayList<MtoCatLibros>();
    }
    
    public int getIdCategoria() {
        return idCategoria;
    }

    public void setIdCategoria(int idCategoria) {
        this.idCategoria = idCategoria;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public ArrayList<MtoCatLibros> getMtoCatLibro() {
        return MtoCatLibro;
    }

    public void setMtoCatLibro(ArrayList<MtoCatLibros> MtoCatLibro) {
        this.MtoCatLibro = MtoCatLibro;
    }
    
    
}
