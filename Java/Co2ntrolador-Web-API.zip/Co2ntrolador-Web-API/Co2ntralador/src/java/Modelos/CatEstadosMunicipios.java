/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelos;

/**
 *
 * @author Propietario
 */
public class CatEstadosMunicipios {
    
    private int idEstadoMunicipio;
    private int idEstado;
    private int idMunicipio;

    public CatEstadosMunicipios(int idEstadoMunicipio, int idEstado, int idMunicipio) {
        this.idEstadoMunicipio = idEstadoMunicipio;
        this.idEstado = idEstado;
        this.idMunicipio = idMunicipio;
    }

    
    public int getIdEstadoMunicipio() {
        return idEstadoMunicipio;
    }

    public void setIdEstadoMunicipio(int idEstadoMunicipio) {
        this.idEstadoMunicipio = idEstadoMunicipio;
    }

    public int getIdEstado() {
        return idEstado;
    }

    public void setIdEstado(int idEstado) {
        this.idEstado = idEstado;
    }

    public int getIdMunicipio() {
        return idMunicipio;
    }

    public void setIdMunicipio(int idMunicipio) {
        this.idMunicipio = idMunicipio;
    }
    
    
}
