// ConsoleApplication1.cpp: define el punto de entrada de la aplicaci�n de consola.
//

#include "stdafx.h"
#include <iostream>
#include <windows.h>
#include <conio.h>
#include <string>
#include <limits>  
#include <iomanip>

using namespace std;

int sena=1;

void gotoxy(int x, int y)
{
    COORD coord;
    coord.X = x;
    coord.Y = y;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}

void tabla(void);

float dato(int e =0)
{
	bool bandera=false;
    float dat=0;

	while(bandera==false)
	{
	   if (!(cin >> dat))
		{
			dat=0;
			cin.clear();
			cin.ignore(99999, '\n');
			gotoxy(40,5);
			cout << "Solo numeros, introduce de nuevo: ";
			dat=0;
			bandera=false;
		}
	   else
		   if (e!=3)
		   {
			   if (dat==0)
			   {
				  gotoxy(40,5);
				cout << "Solo numeros, introduce de nuevo: ";
					dat=0;
					bandera=false;
				}
				else
					bandera=true;
			   
		   }
		   else
			bandera=true;
   }
    return dat;
}

class METODO_GAUSS_JORDAN
{
public:
     void IngresarDatos();
     void ConvertirA0(int c);
     int ConvertirA1(int c);
     void MostrarMatriz();
	 void MostrarResultado();
     METODO_GAUSS_JORDAN();
    ~METODO_GAUSS_JORDAN();
private:
     float matriz[4][3];
};

void METODO_GAUSS_JORDAN::IngresarDatos()
{
 int i, nCol = 0;
 char columna[] = {'a','b','c','d'};
 
  	tabla();
  	for ( nCol = 0; nCol < 4; nCol++){
 		for( i=0; i<3; i++){
	    	gotoxy(4,1);
   		 	cout << "                                                   ";
    		gotoxy(4,1);
  			cout << "Ingrese los tres valores de " << columna[nCol] << "[ " << i+1 << " ] " <<endl;
   			gotoxy(5 + 8*nCol, 5 + 2*i);
    	   	this->matriz[nCol][i] = dato(nCol);
    	}	
  	}
   
    cout <<endl << endl << endl; 
 	cout<< " Esta es su matriz Ingresada" << endl;
    system("pause");
    //this->MostrarDatos();
}

void METODO_GAUSS_JORDAN::MostrarMatriz()
{
	int i, nCol = 0;
 char columna[] = {'a','b','c','d'};
 
  	tabla();
  	for ( nCol = 0; nCol < 4; nCol++){
 		for( i=0; i<3; i++){
	    	gotoxy(4,1);
   		 	cout << "                                                   ";
   			gotoxy(5 + 8*nCol, 5 + 2*i);
    	   cout<< fixed << setprecision(3)<<matriz[nCol][i];
    	}	
  	}
   
    cout <<endl << endl << endl; 
    system("pause");
}

int METODO_GAUSS_JORDAN::ConvertirA1(int c)
{
    int d=0;
	int f=0;
    float aux=0, n=0;
	f=c;
	aux=0;
    aux=matriz[c][c];
				if (c==2){
				if ((matriz[0][2]==0) && (matriz[1][2]==0)&&(matriz[2][2]==0)&&(matriz[3][2]==0)){
					cout<<"�La verificaci�n est� completada exitosamente!"<<endl;
					f=3;
			}
		}

	if(aux==0)
	{
		while(d<4){
		n=matriz[d][c];
		matriz[d][c]=matriz[d][c+1];
		matriz[d][c+1]=n;
		d++;
		
		}
	}
	aux=matriz[c][c];
	d=0;
    while(d<4){
        matriz[d][c]=matriz[d][c]/aux;
        d++;
    }
			return f;
}



void METODO_GAUSS_JORDAN::ConvertirA0(int c)
{
    float l=0;
    int x=0, sum=0;
    while(sum<2)
    {
        if (sena==c)
        {
            if (sena==2)
            {sena=0;}
            else
            {sena++;}
        }
        l=matriz[c][sena];
        for(x=0;x<4;x++)
        {
			matriz[x][sena]+=(matriz[x][c]*-1*l);
				
        }
		MostrarMatriz();
        if (sena==2)
        {sena=0;}
        else
        {sena++;}
        sum++;
    }
}

void METODO_GAUSS_JORDAN::MostrarResultado()
{
    cout<<"Resultado por el metodo GAUSS-JORDAN"<<endl<<"x: "<< fixed << setprecision(3) << matriz[3][0] << endl<<"y: "<< fixed << setprecision(3) << matriz[3][1] << endl<<"z: "<< fixed << setprecision(3) << matriz[3][2] << endl;
}

//Constructor y destructor
METODO_GAUSS_JORDAN::METODO_GAUSS_JORDAN()
{
}
METODO_GAUSS_JORDAN::~METODO_GAUSS_JORDAN()
{
    
}

void portada()
{
 system("cls");
    cout << "____________________________________________________" << endl;
    cout << "::::             Gauss Jordan Matriz            ::::" << endl;
    cout << "____________________________________________________" << endl;
    cout << "::::::::::::::::::::::::MENU::::::::::::::::::::::::" << endl;
    cout << "____________________________________________________" << endl;
    cout << "::::  A) Entrar al programa                     ::::" << endl;
 cout << "::::  B) Salir    <ESC>                         ::::" << endl;
    cout << "____________________________________________________" << endl;
}

void tabla()
{
 	system("cls");
    gotoxy(1,5);cout<<"|";gotoxy(1,6); cout<<"|";gotoxy(1,7); cout<<"|";gotoxy(1,8);cout<<"|";gotoxy(1,9);cout<<"|";
    gotoxy(27,5);cout<<"|";gotoxy(27,6);cout<<"|"; gotoxy(27,7);cout<<"|";gotoxy(27,8);cout<<"|";gotoxy(27,9);cout<<"|";
    gotoxy(36,5);cout<<"|";gotoxy(36,6);cout<<"|"; gotoxy(36,7);cout<<"|";gotoxy(36,8);cout<<"|";gotoxy(36,9);cout<<"|";
    gotoxy(4,4);cout<<"[a]";gotoxy(12,4);cout<<"[b]"; gotoxy(23,4);cout<<"[c]";gotoxy(30,4);cout<<"[d]";
}

int _tmain(int argc, _TCHAR* argv[])
{
    //Fuera del menu
    int total=0;
    char menu;
    METODO_GAUSS_JORDAN p;
 portada();
    do {
         gotoxy(1, 9);
   cout << "-> ";
   menu = _getch();
         switch (toupper(menu)){
          
          case 'A':{
           		p.IngresarDatos();
           		int cont=0;
            	for(cont=0;cont<3;cont++){
                	cont=p.ConvertirA1(cont);
					p.MostrarMatriz();
                	p.ConvertirA0(cont);
					
            	}
				cout<<"Resultado final"<<endl;
				p.MostrarMatriz();
            	p.MostrarResultado();
            	system("PAUSE");
            	portada();
            break;}

          case 'B':
          case 27:{
           		system("cls");
         		return 0;
            	}
        	default:
            	gotoxy(8, 10);
         		cout<<"Su opcion no es valida, seleccione <ESC>, A o B"<<endl;
        	break;
       }
 }while(toupper(menu) != 'B');
      
return 0;
 
}


