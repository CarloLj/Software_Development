#include "stdafx.h"
#include <iostream>
#include "windows.h"
#include "conio.h"
#include <ctype.h>
#include <stdlib.h>
#include <string>
#include <limits>

using namespace std;

float leerfloat( )
{
	bool bandera=false;
    float dat=0;

	while(bandera==false)
	{
	   if (!(cin >> dat))
		{
			dat=0;
			cin.clear();
			cin.ignore(99999, '\n');
			cout << "Solo numeros, introduce de nuevo\n ";
			dat=0;
			bandera=false;
		}
	   else
			bandera=true;
   }
    return dat;
}

int leerint()
{
	bool bandera=false;
    float dat=0;

	while(bandera==false)
	{
	   if (!(cin >> dat)||((dat < 1) || (dat-(int)dat > 0)))
		{
			dat=0;
			cin.clear();
			cin.ignore(99999, '\n');
			cout << "Solo numeros, introduce de nuevo\n ";
			dat=0;
			bandera=false;
	   }

	   else{
			if ((dat < 1) || (dat-(int)dat > 0))
			{
				dat=0;
				cin.clear();
				cin.ignore(99999, '\n');
				cout << "Solo numeros enteros, introduce de nuevo\n ";
				dat=0;
				bandera=false;
		   }
			else bandera=true;
	   }
   }
    return dat;
}


template <typename dato> class PILA {

private:
	dato pila[50];

public:
	int numerosTotales;
    PILA (){numerosTotales=0;};
	~PILA(){};

	void Agregar(int d){
		int NumA�adir=0;
		int Aux=numerosTotales;

			system("cls");
				if (numerosTotales < 50) {
				cout << "********************" << endl;
				cout << "||     ANADIR     ||" << endl;
				cout << "********************" << endl;
				cout << "Cuantos elementos mas quiere quiere agregar?" << endl;
				NumA�adir=leerint();

				if (NumA�adir+Aux>30){
					cout<<"Si a�ade ese elemento, sobrepasara los 50 espacios"<<endl;
					system("pause");

				}
				else{
					for(numerosTotales; numerosTotales<Aux+NumA�adir; numerosTotales++){
					cout << "Ingresa tu elemento "<< numerosTotales + 1 << endl;
					cout << "";
					if(d==1)pila[numerosTotales]=leerint();
					if(d==2)pila[numerosTotales]=leerfloat();
					if(d==3){
						bool bandera=false;

						while(bandera==false)
						{
							pila[numerosTotales]=_getche();
						   if (!(isalpha(pila[numerosTotales])))
							{
								cin.clear();
								cin.ignore(99999, '\n');
								cout <<  "\n No es una letra, vuelva a introducir\n";
								bandera=false;
							}
						   else
								bandera=true;
					   }
					}
					cout << "" << endl;
					}
				}
				}
				else {
					cout<<"Ya no hay espacio!"<<endl;
					system("PAUSE");
				}
			system("pause");
	}

	void Contar()
	{
		system("cls");
		cout << "*******************" << endl;
		cout << "||    CONTAR     ||" << endl;
		cout << "*******************" << endl;
		cout << "Hay "<<  numerosTotales << " numeros en la pila" << endl;
		system("pause");
	}

	void Eliminar()
{
		system("cls");
	if (numerosTotales > 0) {
		char e;
		system("cls");
		cout << "*********************" << endl;
		cout << "||     ELIMINAR    ||" << endl;
		cout << "----------------------------------------------------" << endl;		
		cout << "||  Desea borrar el ultimo elemento registrado?:: ||  " << endl;
		cout << "----------------------------------------------------" << endl;	
		cout << pila[numerosTotales -1] << endl;
		cout << "----------------------------------------------------" << endl;
		cout << "S/N" << endl;
		e = _getch();
		if (e =='S'|| e =='s') {
			numerosTotales--;
			cout << "Eliminado con exito!" << endl;
			system("PAUSE");
		}
		else {
			cout<<"OK"<<endl;
			system("PAUSE");
		}
	}
	else {
		cout << "No ha ingresado ningun valor a�n" << endl;
		system("PAUSE");
	}
}

	void Mostrar()
{
	system("cls");
	if (numerosTotales > 0) {
		cout << "Mostrando sus [" << numerosTotales <<"] numeros en la pila"<< endl;
		for (int i = 0; i < numerosTotales; i++) {
			cout << pila[i] << endl;
		}
		system("PAUSE");
	}
	else {
		cout << "No ha registrado ningun valor aun!" << endl;
		system("PAUSE");
	}
}
};

PILA <int> entero;
PILA <float> flotante;
PILA <char> caracter;

void imprime(int d)
{
	int salir;

	int QueHacer;
	system("cls");
	do{
		system("cls");
		cout<<"_____________________________"<<endl;
		cout<<"- Que desea hacer?          -" <<endl;
		cout<<"-[A] Agregar                -" <<endl;
		cout<<"-[B] Contar                 -" <<endl;
		cout<<"-[C] Eliminar               -" <<endl;
		cout<<"-[D] Mostrar                -" <<endl;
		cout<<"-[E] Salir a menu principal -" <<endl;
		cout<<"_____________________________"<<endl;
		QueHacer=_getch();
		switch(QueHacer){

		case 'A': case 'a':
			if(d==1)entero.Agregar(d);;
			if(d==2)flotante.Agregar(d);
			if(d==3)caracter.Agregar(d);
		break;
	
		case 'B': case 'b':
			if(d==1)entero.Contar();
			if(d==2)flotante.Contar();
			if(d==3)caracter.Contar();
		break;

		case 'C': case 'c':
			if(d==1)entero.Eliminar();
			if(d==2)flotante.Eliminar();
			if(d==3)caracter.Eliminar();
	    break;

		case 'D': case 'd':
			if(d==1)entero.Mostrar();
			if(d==2)flotante.Mostrar();
			if(d==3)caracter.Mostrar();
		break;

		case 'E': case 'e':
		
		default:break;
		}
	}while (QueHacer != 'E' && QueHacer != 'e');
}

int main()
{
	int salir;
	int QueHacer;
	system("cls");
	do{
		int decidir=0;
		system("cls");
		cout<<"_________________________"<<endl;
		cout<<"- Que pila desea hacer? -" <<endl;
		cout<<"-[A] Enteros            -" <<endl;
		cout<<"-[B] Flotantes          -" <<endl;
		cout<<"-[C] Caracteres         -" <<endl;
		cout<<"-[D] Salir              -" <<endl;
		cout<<"_________________________"<<endl;
		QueHacer=_getch();
		switch(QueHacer){

		case 'A': case 'a':
			decidir=1;
			imprime(decidir);
		break;
	
		case 'B': case 'b':
			decidir=2;
			imprime(decidir);
		break;

		case 'C': case 'c':
			decidir=3;
			imprime(decidir);
	    break;

		case 'D': case 'd':break;
		
		default:break;
		}
	}while (QueHacer != 'D' && QueHacer != 'd');
	return 0;
}
