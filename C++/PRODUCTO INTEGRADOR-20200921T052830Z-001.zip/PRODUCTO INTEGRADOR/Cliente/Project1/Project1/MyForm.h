#pragma once



namespace Project1 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::Net;
	using namespace System::Net::Sockets;
	using namespace System::Threading;
	using namespace System::Text;
	/// <summary>
	/// Resumen de MyForm
	/// </summary>
	int turno;
	int Ocupado[9];
	//OBJETO X;
	
	
	bool fin;
	char A1,A2,A3,B1,B2,B3,C1,C2,C3;
	int cont1,cont2, socket;
	
	public ref class MyForm : public System::Windows::Forms::Form
	{
		Socket^sck;
	private: System::Windows::Forms::Button^  button10;
	private: System::Windows::Forms::Button^  button11;

	private: System::Windows::Forms::TextBox^  textBox1;
	private: System::Windows::Forms::Label^  Turn;

	private: System::Windows::Forms::Button^  btnSalir;

	private: Microsoft::VisualBasic::PowerPacks::ShapeContainer^  shapeContainer1;
	private: Microsoft::VisualBasic::PowerPacks::RectangleShape^  rectangleShape3;
	private: Microsoft::VisualBasic::PowerPacks::RectangleShape^  rectangleShape2;
	private: Microsoft::VisualBasic::PowerPacks::RectangleShape^  rectangleShape1;
	private: Microsoft::VisualBasic::PowerPacks::RectangleShape^  rectangleShape4;
	private: System::Windows::Forms::Label^  label2;
			 Encoding^cod;
	public:
		MyForm(void)
		{
			InitializeComponent();
			//
			//TODO: agregar c�digo de constructor aqu�
			//
			cod=Encoding::UTF8;
			this->Turn->Text = "0";
			turno=0;
			for(int i=0;i<9;i++){
				Ocupado[i]=0;
			}
			fin=false;
			A1='0';
			A2='0';
			A3='0';

			B1='0';
			B2='0';
			B3='0';

			C1='0';
			C2='0';
			C3='0';
			socket=0;

		button1->Enabled=false;
		button2->Enabled=false;
		button3->Enabled=false;
		button4->Enabled=false;
		button5->Enabled=false;
		button6->Enabled=false;
		button7->Enabled=false;
		button8->Enabled=false;
		button9->Enabled=false;
		btnSalir->Enabled=false;
		button11->Enabled=false;
			cont1=cont2=0;
		}

	protected:
		/// <summary>
		/// Limpiar los recursos que se est�n utilizando.
		/// </summary>
		~MyForm()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^  button1;
	protected: 
	private: System::Windows::Forms::Button^  button2;
	private: System::Windows::Forms::Button^  button3;
	private: System::Windows::Forms::Button^  button4;
	private: System::Windows::Forms::Button^  button5;
	private: System::Windows::Forms::Button^  button6;
	private: System::Windows::Forms::Button^  button7;
	private: System::Windows::Forms::Button^  button8;
	private: System::Windows::Forms::Button^  button9;
	private: System::Windows::Forms::Label^  Nombre_Jugador1;
	private: System::Windows::Forms::Label^  Nombre_Jugador2;
	private: System::Windows::Forms::Label^  TURNO;
	private: System::Windows::Forms::Button^  button_New;
	private: System::Windows::Forms::Label^  contador1;
	private: System::Windows::Forms::Label^  contador2;
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Button^  Ayuda;
	private: System::ComponentModel::IContainer^  components;




	private:
		/// <summary>
		/// Variable del dise�ador requerida.
		/// </summary>


#pragma region Windows Form Designer generated code
		/// <summary>
		/// M�todo necesario para admitir el Dise�ador. No se puede modificar
		/// el contenido del m�todo con el editor de c�digo.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(MyForm::typeid));
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->button4 = (gcnew System::Windows::Forms::Button());
			this->button5 = (gcnew System::Windows::Forms::Button());
			this->button6 = (gcnew System::Windows::Forms::Button());
			this->button7 = (gcnew System::Windows::Forms::Button());
			this->button8 = (gcnew System::Windows::Forms::Button());
			this->button9 = (gcnew System::Windows::Forms::Button());
			this->Nombre_Jugador1 = (gcnew System::Windows::Forms::Label());
			this->Nombre_Jugador2 = (gcnew System::Windows::Forms::Label());
			this->TURNO = (gcnew System::Windows::Forms::Label());
			this->button_New = (gcnew System::Windows::Forms::Button());
			this->contador1 = (gcnew System::Windows::Forms::Label());
			this->contador2 = (gcnew System::Windows::Forms::Label());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->Ayuda = (gcnew System::Windows::Forms::Button());
			this->button10 = (gcnew System::Windows::Forms::Button());
			this->button11 = (gcnew System::Windows::Forms::Button());
			this->textBox1 = (gcnew System::Windows::Forms::TextBox());
			this->Turn = (gcnew System::Windows::Forms::Label());
			this->btnSalir = (gcnew System::Windows::Forms::Button());
			this->shapeContainer1 = (gcnew Microsoft::VisualBasic::PowerPacks::ShapeContainer());
			this->rectangleShape4 = (gcnew Microsoft::VisualBasic::PowerPacks::RectangleShape());
			this->rectangleShape3 = (gcnew Microsoft::VisualBasic::PowerPacks::RectangleShape());
			this->rectangleShape2 = (gcnew Microsoft::VisualBasic::PowerPacks::RectangleShape());
			this->rectangleShape1 = (gcnew Microsoft::VisualBasic::PowerPacks::RectangleShape());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->SuspendLayout();
			// 
			// button1
			// 
			this->button1->BackColor = System::Drawing::Color::White;
			this->button1->Font = (gcnew System::Drawing::Font(L"Goudy Stout", 21.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->button1->Location = System::Drawing::Point(43, 76);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(60, 60);
			this->button1->TabIndex = 0;
			this->button1->UseVisualStyleBackColor = false;
			this->button1->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button2
			// 
			this->button2->BackColor = System::Drawing::Color::White;
			this->button2->Font = (gcnew System::Drawing::Font(L"Goudy Stout", 21.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->button2->Location = System::Drawing::Point(121, 76);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(60, 60);
			this->button2->TabIndex = 1;
			this->button2->UseVisualStyleBackColor = false;
			this->button2->Click += gcnew System::EventHandler(this, &MyForm::button2_Click);
			// 
			// button3
			// 
			this->button3->BackColor = System::Drawing::Color::White;
			this->button3->Font = (gcnew System::Drawing::Font(L"Goudy Stout", 21.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->button3->Location = System::Drawing::Point(201, 76);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(60, 60);
			this->button3->TabIndex = 2;
			this->button3->UseVisualStyleBackColor = false;
			this->button3->Click += gcnew System::EventHandler(this, &MyForm::button3_Click);
			// 
			// button4
			// 
			this->button4->BackColor = System::Drawing::Color::White;
			this->button4->Font = (gcnew System::Drawing::Font(L"Goudy Stout", 21.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->button4->Location = System::Drawing::Point(43, 157);
			this->button4->Name = L"button4";
			this->button4->Size = System::Drawing::Size(60, 60);
			this->button4->TabIndex = 3;
			this->button4->UseVisualStyleBackColor = false;
			this->button4->Click += gcnew System::EventHandler(this, &MyForm::button4_Click);
			// 
			// button5
			// 
			this->button5->BackColor = System::Drawing::Color::White;
			this->button5->Font = (gcnew System::Drawing::Font(L"Goudy Stout", 21.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->button5->Location = System::Drawing::Point(121, 157);
			this->button5->Name = L"button5";
			this->button5->Size = System::Drawing::Size(60, 60);
			this->button5->TabIndex = 4;
			this->button5->UseVisualStyleBackColor = false;
			this->button5->Click += gcnew System::EventHandler(this, &MyForm::button5_Click);
			// 
			// button6
			// 
			this->button6->BackColor = System::Drawing::Color::White;
			this->button6->Font = (gcnew System::Drawing::Font(L"Goudy Stout", 21.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->button6->Location = System::Drawing::Point(201, 157);
			this->button6->Name = L"button6";
			this->button6->Size = System::Drawing::Size(60, 60);
			this->button6->TabIndex = 5;
			this->button6->UseVisualStyleBackColor = false;
			this->button6->Click += gcnew System::EventHandler(this, &MyForm::button6_Click);
			// 
			// button7
			// 
			this->button7->BackColor = System::Drawing::Color::White;
			this->button7->Font = (gcnew System::Drawing::Font(L"Goudy Stout", 21.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->button7->Location = System::Drawing::Point(43, 237);
			this->button7->Name = L"button7";
			this->button7->Size = System::Drawing::Size(60, 60);
			this->button7->TabIndex = 6;
			this->button7->UseVisualStyleBackColor = false;
			this->button7->Click += gcnew System::EventHandler(this, &MyForm::button7_Click);
			// 
			// button8
			// 
			this->button8->BackColor = System::Drawing::Color::White;
			this->button8->Font = (gcnew System::Drawing::Font(L"Goudy Stout", 21.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->button8->Location = System::Drawing::Point(121, 237);
			this->button8->Name = L"button8";
			this->button8->Size = System::Drawing::Size(60, 60);
			this->button8->TabIndex = 7;
			this->button8->UseVisualStyleBackColor = false;
			this->button8->Click += gcnew System::EventHandler(this, &MyForm::button8_Click);
			// 
			// button9
			// 
			this->button9->BackColor = System::Drawing::Color::White;
			this->button9->Font = (gcnew System::Drawing::Font(L"Goudy Stout", 21.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->button9->Location = System::Drawing::Point(201, 237);
			this->button9->Name = L"button9";
			this->button9->Size = System::Drawing::Size(60, 60);
			this->button9->TabIndex = 8;
			this->button9->UseVisualStyleBackColor = false;
			this->button9->Click += gcnew System::EventHandler(this, &MyForm::button9_Click);
			// 
			// Nombre_Jugador1
			// 
			this->Nombre_Jugador1->AutoSize = true;
			this->Nombre_Jugador1->Location = System::Drawing::Point(12, 29);
			this->Nombre_Jugador1->Name = L"Nombre_Jugador1";
			this->Nombre_Jugador1->Size = System::Drawing::Size(68, 13);
			this->Nombre_Jugador1->TabIndex = 9;
			this->Nombre_Jugador1->Text = L"JUGADOR 1";
			// 
			// Nombre_Jugador2
			// 
			this->Nombre_Jugador2->AutoSize = true;
			this->Nombre_Jugador2->Location = System::Drawing::Point(228, 29);
			this->Nombre_Jugador2->Name = L"Nombre_Jugador2";
			this->Nombre_Jugador2->Size = System::Drawing::Size(68, 13);
			this->Nombre_Jugador2->TabIndex = 10;
			this->Nombre_Jugador2->Text = L"JUGADOR 2";
			// 
			// TURNO
			// 
			this->TURNO->AutoSize = true;
			this->TURNO->Location = System::Drawing::Point(118, 52);
			this->TURNO->Name = L"TURNO";
			this->TURNO->Size = System::Drawing::Size(68, 13);
			this->TURNO->TabIndex = 11;
			this->TURNO->Text = L"JUGADOR 1";
			this->TURNO->Click += gcnew System::EventHandler(this, &MyForm::TURNO_Click);
			// 
			// button_New
			// 
			this->button_New->Enabled = false;
			this->button_New->Location = System::Drawing::Point(90, 171);
			this->button_New->Name = L"button_New";
			this->button_New->Size = System::Drawing::Size(123, 23);
			this->button_New->TabIndex = 12;
			this->button_New->Text = L"Nueva Partida";
			this->button_New->UseVisualStyleBackColor = true;
			this->button_New->Visible = false;
			this->button_New->Click += gcnew System::EventHandler(this, &MyForm::button_New_Click);
			// 
			// contador1
			// 
			this->contador1->AutoSize = true;
			this->contador1->Location = System::Drawing::Point(37, 52);
			this->contador1->Name = L"contador1";
			this->contador1->Size = System::Drawing::Size(13, 13);
			this->contador1->TabIndex = 13;
			this->contador1->Text = L"0";
			// 
			// contador2
			// 
			this->contador2->AutoSize = true;
			this->contador2->Location = System::Drawing::Point(257, 52);
			this->contador2->Name = L"contador2";
			this->contador2->Size = System::Drawing::Size(13, 13);
			this->contador2->TabIndex = 14;
			this->contador2->Text = L"0";
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(112, 39);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(85, 13);
			this->label1->TabIndex = 15;
			this->label1->Text = L"T U R N O  D E:";
			// 
			// Ayuda
			// 
			this->Ayuda->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"Ayuda.Image")));
			this->Ayuda->Location = System::Drawing::Point(311, -1);
			this->Ayuda->Name = L"Ayuda";
			this->Ayuda->Size = System::Drawing::Size(34, 34);
			this->Ayuda->TabIndex = 16;
			this->Ayuda->UseVisualStyleBackColor = true;
			this->Ayuda->Click += gcnew System::EventHandler(this, &MyForm::Ayuda_Click);
			// 
			// button10
			// 
			this->button10->Location = System::Drawing::Point(273, 271);
			this->button10->Name = L"button10";
			this->button10->Size = System::Drawing::Size(66, 23);
			this->button10->TabIndex = 17;
			this->button10->Text = L"Conectar";
			this->button10->UseVisualStyleBackColor = true;
			this->button10->Click += gcnew System::EventHandler(this, &MyForm::button10_Click);
			// 
			// button11
			// 
			this->button11->Location = System::Drawing::Point(273, 242);
			this->button11->Name = L"button11";
			this->button11->Size = System::Drawing::Size(66, 23);
			this->button11->TabIndex = 18;
			this->button11->Text = L"Recibir";
			this->button11->UseVisualStyleBackColor = true;
			this->button11->Click += gcnew System::EventHandler(this, &MyForm::button11_Click);
			// 
			// textBox1
			// 
			this->textBox1->Location = System::Drawing::Point(294, 124);
			this->textBox1->Name = L"textBox1";
			this->textBox1->Size = System::Drawing::Size(26, 20);
			this->textBox1->TabIndex = 20;
			this->textBox1->TextChanged += gcnew System::EventHandler(this, &MyForm::textBox1_TextChanged);
			// 
			// Turn
			// 
			this->Turn->AutoSize = true;
			this->Turn->Location = System::Drawing::Point(-3, -1);
			this->Turn->Name = L"Turn";
			this->Turn->Size = System::Drawing::Size(35, 13);
			this->Turn->TabIndex = 19;
			this->Turn->Text = L"Turno";
			this->Turn->Visible = false;
			this->Turn->Click += gcnew System::EventHandler(this, &MyForm::Turn_Click);
			// 
			// btnSalir
			// 
			this->btnSalir->Location = System::Drawing::Point(273, 213);
			this->btnSalir->Name = L"btnSalir";
			this->btnSalir->Size = System::Drawing::Size(66, 23);
			this->btnSalir->TabIndex = 22;
			this->btnSalir->Text = L"Salir";
			this->btnSalir->UseVisualStyleBackColor = true;
			this->btnSalir->Click += gcnew System::EventHandler(this, &MyForm::btnSalir_Click);
			// 
			// shapeContainer1
			// 
			this->shapeContainer1->Location = System::Drawing::Point(0, 0);
			this->shapeContainer1->Margin = System::Windows::Forms::Padding(0);
			this->shapeContainer1->Name = L"shapeContainer1";
			this->shapeContainer1->Shapes->AddRange(gcnew cli::array< Microsoft::VisualBasic::PowerPacks::Shape^  >(4) {this->rectangleShape4, 
				this->rectangleShape3, this->rectangleShape2, this->rectangleShape1});
			this->shapeContainer1->Size = System::Drawing::Size(344, 313);
			this->shapeContainer1->TabIndex = 23;
			this->shapeContainer1->TabStop = false;
			// 
			// rectangleShape4
			// 
			this->rectangleShape4->BackColor = System::Drawing::SystemColors::ActiveCaptionText;
			this->rectangleShape4->FillStyle = Microsoft::VisualBasic::PowerPacks::FillStyle::Solid;
			this->rectangleShape4->Location = System::Drawing::Point(36, 139);
			this->rectangleShape4->Name = L"rectangleShape4";
			this->rectangleShape4->Size = System::Drawing::Size(228, 12);
			// 
			// rectangleShape3
			// 
			this->rectangleShape3->BackColor = System::Drawing::SystemColors::ActiveCaptionText;
			this->rectangleShape3->FillStyle = Microsoft::VisualBasic::PowerPacks::FillStyle::Solid;
			this->rectangleShape3->Location = System::Drawing::Point(37, 220);
			this->rectangleShape3->Name = L"rectangleShape3";
			this->rectangleShape3->Size = System::Drawing::Size(228, 12);
			// 
			// rectangleShape2
			// 
			this->rectangleShape2->BackColor = System::Drawing::SystemColors::ActiveCaptionText;
			this->rectangleShape2->FillStyle = Microsoft::VisualBasic::PowerPacks::FillStyle::Solid;
			this->rectangleShape2->Location = System::Drawing::Point(105, 73);
			this->rectangleShape2->Name = L"rectangleShape2";
			this->rectangleShape2->Size = System::Drawing::Size(12, 228);
			// 
			// rectangleShape1
			// 
			this->rectangleShape1->BackColor = System::Drawing::SystemColors::ActiveCaptionText;
			this->rectangleShape1->FillStyle = Microsoft::VisualBasic::PowerPacks::FillStyle::Solid;
			this->rectangleShape1->Location = System::Drawing::Point(184, 73);
			this->rectangleShape1->Name = L"rectangleShape1";
			this->rectangleShape1->Size = System::Drawing::Size(12, 228);
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(274, 108);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(67, 13);
			this->label2->TabIndex = 24;
			this->label2->Text = L"Jugada rival:";
			// 
			// MyForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->CausesValidation = false;
			this->ClientSize = System::Drawing::Size(344, 313);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->btnSalir);
			this->Controls->Add(this->textBox1);
			this->Controls->Add(this->Turn);
			this->Controls->Add(this->button11);
			this->Controls->Add(this->button10);
			this->Controls->Add(this->Ayuda);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->contador2);
			this->Controls->Add(this->contador1);
			this->Controls->Add(this->button_New);
			this->Controls->Add(this->TURNO);
			this->Controls->Add(this->Nombre_Jugador2);
			this->Controls->Add(this->Nombre_Jugador1);
			this->Controls->Add(this->button9);
			this->Controls->Add(this->button8);
			this->Controls->Add(this->button7);
			this->Controls->Add(this->button6);
			this->Controls->Add(this->button5);
			this->Controls->Add(this->button4);
			this->Controls->Add(this->button3);
			this->Controls->Add(this->button2);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->shapeContainer1);
			this->Icon = (cli::safe_cast<System::Drawing::Icon^  >(resources->GetObject(L"$this.Icon")));
			this->MaximizeBox = false;
			this->Name = L"MyForm";
			this->Text = L"TIC TAC TOE CLIENTE";
			this->Load += gcnew System::EventHandler(this, &MyForm::MyForm_Load);
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
char GANADOR(char a1, char a2, char a3, char b1, char b2, char b3, char c1, char c2, char c3) {
	
	char Copia[3][3];

	Copia[0][0] = a1;              // a1  a2  a3
	Copia[0][1] = a2;              // b1  b2  b3
	Copia[0][2] = a3;              // c1  c2  c3

	Copia[1][0] = b1;
	Copia[1][1] = b2;
	Copia[1][2] = b3;

	Copia[2][0] = c1;
	Copia[2][1] = c2;
	Copia[2][2] = c3;

	//________________________________//

	//CASO 1        En fila

	int Ganador = 0;//indica si ya hay ganador

	for (int i = 0; i < 3; i++) {
			if (Copia[i][0] == Copia[i][1] && Copia[i][1] == Copia[i][2] && Copia[i][0]!='0') {
				Ganador = 1;
				if(i==0){
				this->button1->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(0)), static_cast<System::Int32>(static_cast<System::Byte>(192)), 
					static_cast<System::Int32>(static_cast<System::Byte>(0)));
				this->button2->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(0)), static_cast<System::Int32>(static_cast<System::Byte>(192)), 
					static_cast<System::Int32>(static_cast<System::Byte>(0)));
				this->button3->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(0)), static_cast<System::Int32>(static_cast<System::Byte>(192)), 
					static_cast<System::Int32>(static_cast<System::Byte>(0)));
				}
				if(i==1){
				this->button4->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(0)), static_cast<System::Int32>(static_cast<System::Byte>(192)), 
					static_cast<System::Int32>(static_cast<System::Byte>(0)));
				this->button5->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(0)), static_cast<System::Int32>(static_cast<System::Byte>(192)), 
					static_cast<System::Int32>(static_cast<System::Byte>(0)));
				this->button6->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(0)), static_cast<System::Int32>(static_cast<System::Byte>(192)), 
					static_cast<System::Int32>(static_cast<System::Byte>(0)));
				}
				if(i==2){
				this->button7->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(0)), static_cast<System::Int32>(static_cast<System::Byte>(192)), 
					static_cast<System::Int32>(static_cast<System::Byte>(0)));
				this->button8->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(0)), static_cast<System::Int32>(static_cast<System::Byte>(192)), 
					static_cast<System::Int32>(static_cast<System::Byte>(0)));
				this->button9->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(0)), static_cast<System::Int32>(static_cast<System::Byte>(192)), 
					static_cast<System::Int32>(static_cast<System::Byte>(0)));
				}
				return Copia[i][0];
			}
	}

	//CASO 2    En columna

	for (int i = 0; i < 3; i++) {
		if (Copia[0][i] == Copia[1][i] && Copia[1][i] == Copia[2][i]&& Copia[0][i]!='0') {
			Ganador = 1;
				if(i==0){
				this->button1->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(0)), static_cast<System::Int32>(static_cast<System::Byte>(192)), 
					static_cast<System::Int32>(static_cast<System::Byte>(0)));
				this->button4->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(0)), static_cast<System::Int32>(static_cast<System::Byte>(192)), 
					static_cast<System::Int32>(static_cast<System::Byte>(0)));
				this->button7->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(0)), static_cast<System::Int32>(static_cast<System::Byte>(192)), 
					static_cast<System::Int32>(static_cast<System::Byte>(0)));
				}
				if(i==1){
				this->button2->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(0)), static_cast<System::Int32>(static_cast<System::Byte>(192)), 
					static_cast<System::Int32>(static_cast<System::Byte>(0)));
				this->button5->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(0)), static_cast<System::Int32>(static_cast<System::Byte>(192)), 
					static_cast<System::Int32>(static_cast<System::Byte>(0)));
				this->button8->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(0)), static_cast<System::Int32>(static_cast<System::Byte>(192)), 
					static_cast<System::Int32>(static_cast<System::Byte>(0)));
				}
				if(i==2){
				this->button3->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(0)), static_cast<System::Int32>(static_cast<System::Byte>(192)), 
					static_cast<System::Int32>(static_cast<System::Byte>(0)));
				this->button6->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(0)), static_cast<System::Int32>(static_cast<System::Byte>(192)), 
					static_cast<System::Int32>(static_cast<System::Byte>(0)));
				this->button9->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(0)), static_cast<System::Int32>(static_cast<System::Byte>(192)), 
					static_cast<System::Int32>(static_cast<System::Byte>(0)));
				}
			return Copia[0][i];
		}
	}

	// CASO 3 cruzado   [1][1]

	if (Copia[1][1] == Copia[0][0] && Copia[1][1] == Copia[2][2]&& Copia[1][1]!='0') {
		Ganador = 1;
		this->button1->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(0)), static_cast<System::Int32>(static_cast<System::Byte>(192)), 
					static_cast<System::Int32>(static_cast<System::Byte>(0)));
		this->button5->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(0)), static_cast<System::Int32>(static_cast<System::Byte>(192)), 
					static_cast<System::Int32>(static_cast<System::Byte>(0)));
		this->button9->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(0)), static_cast<System::Int32>(static_cast<System::Byte>(192)), 
					static_cast<System::Int32>(static_cast<System::Byte>(0)));
		return Copia[1][1];
	}

	if (Copia[1][1] == Copia[0][2] && Copia[1][1] == Copia[2][0]&& Copia[1][1]!='0') {
		Ganador = 1;
		this->button5->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(0)), static_cast<System::Int32>(static_cast<System::Byte>(192)), 
					static_cast<System::Int32>(static_cast<System::Byte>(0)));
		this->button3->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(0)), static_cast<System::Int32>(static_cast<System::Byte>(192)), 
					static_cast<System::Int32>(static_cast<System::Byte>(0)));
		this->button7->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(0)), static_cast<System::Int32>(static_cast<System::Byte>(192)), 
					static_cast<System::Int32>(static_cast<System::Byte>(0)));
		return Copia[1][1];
	}

	bool FULL = true;

	if (Ganador == 0) {
		for(int i=0;i<3;i++){

			for(int j=0;j<3;j++){

				if(Copia[i][j]=='0'){

					FULL = false;

				}
		}
		}
	}
	if(Ganador == 0 && FULL == false){
		return '0'; // no esta lleno 
	}
	if(Ganador == 0 && FULL == true){
		this->button1->BackColor = System::Drawing::Color::Red;
		this->button2->BackColor = System::Drawing::Color::Red;
		this->button3->BackColor = System::Drawing::Color::Red;
		this->button4->BackColor = System::Drawing::Color::Red;
		this->button5->BackColor = System::Drawing::Color::Red;
		this->button6->BackColor = System::Drawing::Color::Red;
		this->button7->BackColor = System::Drawing::Color::Red;
		this->button8->BackColor = System::Drawing::Color::Red;
		this->button9->BackColor = System::Drawing::Color::Red;
		return '-'; // empate 
	}
}

void Verificador(char a1, char a2, char a3, char b1, char b2, char b3, char c1, char c2, char c3){
		
			  if(GANADOR(a1,a2,a3,b1,b2,b3,c1,c2,c3)=='O'){
				  MessageBox::Show("GANA JUGADOR 1 = O");
				  cont1+=1;
				  this->contador1->Text=cont1.ToString();
				   button1->Enabled=false;
				   button2->Enabled=false;
				   button3->Enabled=false;
				   button4->Enabled=false;
				   button5->Enabled=false;
				   button6->Enabled=false;
				   button7->Enabled=false;

				   button8->Enabled=false;
				   button9->Enabled=false;
				  fin=true;
			  }

			  if(GANADOR(a1,a2,a3,b1,b2,b3,c1,c2,c3)=='X'){
				  MessageBox::Show("GANA JUGADOR 2 = X");
				  cont2+=1;
				  this->contador2->Text=cont2.ToString();
				   button1->Enabled=false;
				   button2->Enabled=false;
				   button3->Enabled=false;
				   button4->Enabled=false;
				   button5->Enabled=false;
				   button6->Enabled=false;
				   button7->Enabled=false;
				   button8->Enabled=false;
				   button9->Enabled=false;
				  fin=true;
			  }
			   if(GANADOR(a1,a2,a3,b1,b2,b3,c1,c2,c3)=='-'){
				  MessageBox::Show(" Empate ");
				   button1->Enabled=false;
				   button2->Enabled=false;
				   button3->Enabled=false;
				   button4->Enabled=false;
				   button5->Enabled=false;
				   button6->Enabled=false;
				   button7->Enabled=false;
				   button8->Enabled=false;
				   button9->Enabled=false;
				  fin=true;
			  }
			    if(fin==true){
				   button1->Enabled=false;
				   button2->Enabled=false;
				   button3->Enabled=false;
				   button4->Enabled=false;
				   button5->Enabled=false;
				   button6->Enabled=false;
				   button7->Enabled=false;
				   button8->Enabled=false;
				   button9->Enabled=false;

				   button_New->Enabled=true;
				   button_New->Visible=true;
			   }
	}
private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {
			 
			
			 if(turno==0){

				 button1->Text="O";
				 A1='O';

			 }else
			  {
				 button1->Text="X";
				 A1='X';
				   
			 }
			  if(turno==0){
				this->TURNO->Text = L"JUGADOR 1";
			 }
			  if(turno==1){
				 this->TURNO->Text = L"JUGADOR 2";
			 }

			  button1->Enabled=false;
			 // enviar();
			  Verificador(A1,A2,A3,B1,B2,B3,C1,C2,C3);

		button1->Enabled=false;
		button2->Enabled=false;
		button3->Enabled=false;
		button4->Enabled=false;
		button5->Enabled=false;
		button6->Enabled=false;
		button7->Enabled=false;
		button8->Enabled=false;
		button9->Enabled=false;

		array<Byte>^enviados;
		enviados = cod->GetBytes(button1->Text+"1");
		sck->Send(enviados,0,enviados->Length,SocketFlags::None);
		this->TURNO->Text = L"JUGADOR 1";
		 }
private: System::Void button2_Click(System::Object^  sender, System::EventArgs^  e) {
			 if(turno==0){
				 button2->Text="O";
				 A2='O';
				 
			 }else
			  {
				 button2->Text="X";
				 A2='X';
				 
			 }
			  if(turno==0){
				this->TURNO->Text = L"JUGADOR 1";
			 }
			  if(turno==1){
				 this->TURNO->Text = L"JUGADOR 2";
			 }
			  button2->Enabled=false;
				//enviar();
				Verificador(A1,A2,A3,B1,B2,B3,C1,C2,C3);
				button1->Enabled=false;
		button2->Enabled=false;
		button3->Enabled=false;
		button4->Enabled=false;
		button5->Enabled=false;
		button6->Enabled=false;
		button7->Enabled=false;
		button8->Enabled=false;
		button9->Enabled=false;

		array<Byte>^enviados;
		enviados = cod->GetBytes(button2->Text+"2");
		sck->Send(enviados,0,enviados->Length,SocketFlags::None);
		 this->TURNO->Text = L"JUGADOR 1";
		 }
private: System::Void button3_Click(System::Object^  sender, System::EventArgs^  e) {
			 if(turno==0){
				 button3->Text="O";
				 A3='O';
				 
			 }else
			  {
				 button3->Text="X";
				 A3='X';
			 }
			  if(turno==0){
				this->TURNO->Text = L"JUGADOR 1";
			 }
			  if(turno==1){
				 this->TURNO->Text = L"JUGADOR 2";
			 }
			  button3->Enabled=false;
				//enviar();
			   Verificador(A1,A2,A3,B1,B2,B3,C1,C2,C3);
			   button1->Enabled=false;
		button2->Enabled=false;
		button3->Enabled=false;
		button4->Enabled=false;
		button5->Enabled=false;
		button6->Enabled=false;
		button7->Enabled=false;
		button8->Enabled=false;
		button9->Enabled=false;

		array<Byte>^enviados;
		enviados = cod->GetBytes(button3->Text+"3");
		sck->Send(enviados,0,enviados->Length,SocketFlags::None);
		 this->TURNO->Text = L"JUGADOR 1";
		 }
private: System::Void button4_Click(System::Object^  sender, System::EventArgs^  e) {
			 if(turno==0){
				 button4->Text="O";
				 B1='O';
			 }else
			  {
				 button4->Text="X";
				 B1='X';
			 }
			  if(turno==0){
				this->TURNO->Text = L"JUGADOR 1";
			 }
			  if(turno==1){
				 this->TURNO->Text = L"JUGADOR 2";
			 }
			  button4->Enabled=false;
			  //enviar();
			   Verificador(A1,A2,A3,B1,B2,B3,C1,C2,C3);
			   button1->Enabled=false;
		button2->Enabled=false;
		button3->Enabled=false;
		button4->Enabled=false;
		button5->Enabled=false;
		button6->Enabled=false;
		button7->Enabled=false;
		button8->Enabled=false;
		button9->Enabled=false;

		array<Byte>^enviados;
		enviados = cod->GetBytes(button4->Text+"4");
		sck->Send(enviados,0,enviados->Length,SocketFlags::None);
		 this->TURNO->Text = L"JUGADOR 1";
		 }
private: System::Void button5_Click(System::Object^  sender, System::EventArgs^  e) {
			 if(turno==0){
				 button5->Text="O";
				 B2='O';
			 }else
			  {
				 button5->Text="X";
				 B2='X';
			 }
			  if(turno==0){
				this->TURNO->Text = L"JUGADOR 1";
			 }
			  if(turno==1){
				 this->TURNO->Text = L"JUGADOR 2";
			 }
			  button5->Enabled=false;
			  //enviar();
			 Verificador(A1,A2,A3,B1,B2,B3,C1,C2,C3);
			 button1->Enabled=false;
		button2->Enabled=false;
		button3->Enabled=false;
		button4->Enabled=false;
		button5->Enabled=false;
		button6->Enabled=false;
		button7->Enabled=false;
		button8->Enabled=false;
		button9->Enabled=false;

		array<Byte>^enviados;
		enviados = cod->GetBytes(button5->Text+"5");
		sck->Send(enviados,0,enviados->Length,SocketFlags::None);
		 this->TURNO->Text = L"JUGADOR 1";
		 }
private: System::Void button6_Click(System::Object^  sender, System::EventArgs^  e) {
			 if(turno==0){
				 button6->Text="O";
				 B3='O';
			 }else
			  {
				 button6->Text="X";
				 B3='X';
			 }
			  if(turno==0){
				this->TURNO->Text = L"JUGADOR 1";
			 }
			  if(turno==1){
				 this->TURNO->Text = L"JUGADOR 2";
			 }
			  button6->Enabled=false;
			 // enviar();
			     Verificador(A1,A2,A3,B1,B2,B3,C1,C2,C3);
				 button1->Enabled=false;
		button2->Enabled=false;
		button3->Enabled=false;
		button4->Enabled=false;
		button5->Enabled=false;
		button6->Enabled=false;
		button7->Enabled=false;
		button8->Enabled=false;
		button9->Enabled=false;

		array<Byte>^enviados;
		enviados = cod->GetBytes(button6->Text+"6");
		sck->Send(enviados,0,enviados->Length,SocketFlags::None);
		 this->TURNO->Text = L"JUGADOR 1";
		 }
private: System::Void button7_Click(System::Object^  sender, System::EventArgs^  e) {
			 if(turno==0){
				 button7->Text="O";
				 C1='O';
			 }else
			  {
				 button7->Text="X";
				 C1='X';
			 }
			  if(turno==0){
				this->TURNO->Text = L"JUGADOR 1";
			 }
			  if(turno==1){
				 this->TURNO->Text = L"JUGADOR 2";
			 }
			  button7->Enabled=false;
			 // enviar();
   Verificador(A1,A2,A3,B1,B2,B3,C1,C2,C3);
   button1->Enabled=false;
		button2->Enabled=false;
		button3->Enabled=false;
		button4->Enabled=false;
		button5->Enabled=false;
		button6->Enabled=false;
		button7->Enabled=false;
		button8->Enabled=false;
		button9->Enabled=false;

		array<Byte>^enviados;
		enviados = cod->GetBytes(button7->Text+"7");
		sck->Send(enviados,0,enviados->Length,SocketFlags::None);
		 this->TURNO->Text = L"JUGADOR 1";
		 }
private: System::Void button8_Click(System::Object^  sender, System::EventArgs^  e) {
			 if(turno==0){
				 button8->Text="O";
				 C2='O';
			 }else
			  {
				 button8->Text="X";
				 C2='X';
			 }
			  if(turno==0){
				this->TURNO->Text = L"JUGADOR 1";
			 }
			  if(turno==1){
				 this->TURNO->Text = L"JUGADOR 2";
			 }
			  button8->Enabled=false;
			  //enviar();
			      Verificador(A1,A2,A3,B1,B2,B3,C1,C2,C3);
				  button1->Enabled=false;
		button2->Enabled=false;
		button3->Enabled=false;
		button4->Enabled=false;
		button5->Enabled=false;
		button6->Enabled=false;
		button7->Enabled=false;
		button8->Enabled=false;
		button9->Enabled=false;

		array<Byte>^enviados;
		enviados = cod->GetBytes(button8->Text+"8");
		sck->Send(enviados,0,enviados->Length,SocketFlags::None);
		this->TURNO->Text = L"JUGADOR 1";
		 }
private: System::Void button9_Click(System::Object^  sender, System::EventArgs^  e) {
			 if(turno==0){
				 button9->Text="O";
				 C3='O';
			 }else
			  {
				 button9->Text="X";
				 C3='X';
			 }
			  if(turno==0){
				this->TURNO->Text = L"JUGADOR 1";
			 }
			  if(turno==1){
				 this->TURNO->Text = L"JUGADOR 2";
			 }
			  button9->Enabled=false;
			  
			  //enviar();
			  Verificador(A1,A2,A3,B1,B2,B3,C1,C2,C3);
			  button1->Enabled=false;
		button2->Enabled=false;
		button3->Enabled=false;
		button4->Enabled=false;
		button5->Enabled=false;
		button6->Enabled=false;
		button7->Enabled=false;
		button8->Enabled=false;
		button9->Enabled=false;

		array<Byte>^enviados;
		enviados = cod->GetBytes(button9->Text+"9");
		sck->Send(enviados,0,enviados->Length,SocketFlags::None);
		this->TURNO->Text = L"JUGADOR 1";
		 }
private: System::Void MyForm_Load(System::Object^  sender, System::EventArgs^  e) {

		 }
private: System::Void TURNO_Click(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void button_New_Click(System::Object^  sender, System::EventArgs^  e) {
				   button1->Enabled=false;
				   button2->Enabled=false;
				   button3->Enabled=false;
				   button4->Enabled=false;
				   button5->Enabled=false;
				   button6->Enabled=false;
				   button7->Enabled=false;
				   button8->Enabled=false;
				   button9->Enabled=false;

				   button_New->Enabled=false;
				   button_New->Visible=false;

				   this->TURNO->Text = L"JUGADOR 1";
				   turno=0;
			for(int i=0;i<9;i++){
				Ocupado[i]=0;
			}
			fin=false;
			A1='0';
			A2='0';
			A3='0';

			B1='0';
			B2='0';
			B3='0';

			C1='0';
			C2='0';
			C3='0';
			TURNO->Text=L"Jugador 1";
			button1->Text="";
			button2->Text="";
			button3->Text="";
			button4->Text="";
			button5->Text="";
			button6->Text="";
			button7->Text="";
			button8->Text="";
			button9->Text="";

			this->button1->BackColor = System::Drawing::Color::White;
			this->button2->BackColor = System::Drawing::Color::White;
			this->button3->BackColor = System::Drawing::Color::White;
			this->button4->BackColor = System::Drawing::Color::White;
			this->button5->BackColor = System::Drawing::Color::White;
			this->button6->BackColor = System::Drawing::Color::White;
			this->button7->BackColor = System::Drawing::Color::White;
			this->button8->BackColor = System::Drawing::Color::White;
			this->button9->BackColor = System::Drawing::Color::White;
		 
		 }
private: System::Void Ayuda_Click(System::Object^  sender, System::EventArgs^  e) {
			 MessageBox::Show("- Se dibuja el tablero en una hoja de papel y cada jugador escoge una figura (X O)."
				 "- \n\n Inicio el jugador escoge una casilla vac�a del tablero y coloca su figura en esa casilla."
				 "- \n\n Cuando el jugador dibuja su figura en la casilla termina su turno."
				 "- \n\n Gana el jugador que logre poner 3 figuras en una l�nea (vertical, horizontal o diagonal). Se tacha con una l�nea recta las 3 figuras que forman la l�nea ganadora."
				 "- \n\n En el caso de que se ocupen todas las casillas y ning�n jugador haya realizado una l�nea recta, se declara empate y se juega una nueva partida.");
		 
		 }
private: System::Void button10_Click(System::Object^  sender, System::EventArgs^  e) {
			 button10->Enabled=false;
			 btnSalir->Enabled=true;
			 button11->Enabled=true;
			 sck=gcnew Socket(AddressFamily::InterNetwork, SocketType::Stream,ProtocolType::Tcp);

			 sck->Connect(gcnew IPEndPoint(IPAddress::Parse("192.168.1.10"),5000));
			 socket=1;

		 }
private: System::Void button11_Click(System::Object^  sender, System::EventArgs^  e) {
			 
			 array<Byte>^recibidos=gcnew array<Byte>(256);

			 sck->Receive(recibidos,0,sck->Available,SocketFlags::None);

			 textBox1->Text=cod->GetString(recibidos);

			 if(textBox1->Text=="s" ){
				 sck->Close();
				MessageBox::Show("Uno de los jugadores quiere salir");
		        Close();
			 }
			 if(textBox1->Text=="O1" ){
				 button1->Text="O";
				 A1='O';
				   button1->Enabled=true;
				   button2->Enabled=true;
				   button3->Enabled=true;
				   button4->Enabled=true;
				   button5->Enabled=true;
				   button6->Enabled=true;
				   button7->Enabled=true;
				   button8->Enabled=true;
				   button9->Enabled=true;
				   turno=1;
				   this->TURNO->Text = L"JUGADOR 2";
			 }
			  if(textBox1->Text=="O2" ){
				 button2->Text="O";
				 A2='O';
				 button1->Enabled=true;
				   button2->Enabled=true;
				   button3->Enabled=true;
				   button4->Enabled=true;
				   button5->Enabled=true;
				   button6->Enabled=true;
				   button7->Enabled=true;
				   button8->Enabled=true;
				   button9->Enabled=true;
				   turno=1;
				   this->TURNO->Text = L"JUGADOR 2";
			 }
			   if(textBox1->Text=="O3" ){
				 button3->Text="O";
				 A3='O';
				button1->Enabled=true;
				   button2->Enabled=true;
				   button3->Enabled=true;
				   button4->Enabled=true;
				   button5->Enabled=true;
				   button6->Enabled=true;
				   button7->Enabled=true;
				   button8->Enabled=true;
				   button9->Enabled=true;
				   turno=1;
				   this->TURNO->Text = L"JUGADOR 2";
			 }
			    if(textBox1->Text=="O4" ){
				 button4->Text="O";
				 B1='O';
				 button1->Enabled=true;
				   button2->Enabled=true;
				   button3->Enabled=true;
				   button4->Enabled=true;
				   button5->Enabled=true;
				   button6->Enabled=true;
				   button7->Enabled=true;
				   button8->Enabled=true;
				   button9->Enabled=true;
				   turno=1;
				   this->TURNO->Text = L"JUGADOR 2";
			 }
			 if(textBox1->Text=="O5" ){
				 button5->Text="O";
				 B2='O';
				button1->Enabled=true;
				   button2->Enabled=true;
				   button3->Enabled=true;
				   button4->Enabled=true;
				   button5->Enabled=true;
				   button6->Enabled=true;
				   button7->Enabled=true;
				   button8->Enabled=true;
				   button9->Enabled=true;
				   turno=1;
				   this->TURNO->Text = L"JUGADOR 2";
			 }
			  if(textBox1->Text=="O6" ){
				 button6->Text="O";
				 B3='O';
				 button1->Enabled=true;
				   button2->Enabled=true;
				   button3->Enabled=true;
				   button4->Enabled=true;
				   button5->Enabled=true;
				   button6->Enabled=true;
				   button7->Enabled=true;
				   button8->Enabled=true;
				   button9->Enabled=true;
				   turno=1;
				   this->TURNO->Text = L"JUGADOR 2";
			 }
			 if(textBox1->Text=="O7" ){
				 button7->Text="O";
				 C1='O';
				 button1->Enabled=true;
				   button2->Enabled=true;
				   button3->Enabled=true;
				   button4->Enabled=true;
				   button5->Enabled=true;
				   button6->Enabled=true;
				   button7->Enabled=true;
				   button8->Enabled=true;
				   button9->Enabled=true;
				   turno=1;
				   this->TURNO->Text = L"JUGADOR 2";
			 }
			  if(textBox1->Text=="O8" ){
				 button8->Text="O";
				 C2='O';
				button1->Enabled=true;
				   button2->Enabled=true;
				   button3->Enabled=true;
				   button4->Enabled=true;
				   button5->Enabled=true;
				   button6->Enabled=true;
				   button7->Enabled=true;
				   button8->Enabled=true;
				   button9->Enabled=true;
				   turno=1;
				   this->TURNO->Text = L"JUGADOR 2";
			 }
			   if(textBox1->Text=="O9" ){
				 button9->Text="O";
				 C3='O';
				button1->Enabled=true;
				   button2->Enabled=true;
				   button3->Enabled=true;
				   button4->Enabled=true;
				   button5->Enabled=true;
				   button6->Enabled=true;
				   button7->Enabled=true;
				   button8->Enabled=true;
				   button9->Enabled=true;
				   turno=1;
				   this->TURNO->Text = L"JUGADOR 2";
			 }
			   
			   if(!(button1->Text=="") ){
				   button1->Enabled=false;
			   }
			   if(!(button2->Text=="") ){
				   button2->Enabled=false;
			   }
			   if(!(button3->Text=="") ){
				   button3->Enabled=false;
			   }
			   if(!(button4->Text=="") ){
				   button4->Enabled=false;
			   }
			   if(!(button5->Text=="") ){
				   button5->Enabled=false;
			   }
			   if(!(button6->Text=="") ){
				   button6->Enabled=false;
			   }
			   if(!(button7->Text=="") ){
				   button7->Enabled=false;
			   }
			   if(!(button8->Text=="") ){
				   button8->Enabled=false;
			   }
			   if(!(button9->Text=="") ){
				   button9->Enabled=false;
			   }
			   
			   Verificador(A1,A2,A3,B1,B2,B3,C1,C2,C3);
			 

		 }
private: System::Void Turn_Click(System::Object^  sender, System::EventArgs^  e) {

		 }
private: System::Void textBox1_TextChanged(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void btnSalir_Click(System::Object^  sender, System::EventArgs^  e) {
		array<Byte>^enviados;
		enviados = cod->GetBytes("s");
		sck->Send(enviados,0,enviados->Length,SocketFlags::None);
		sck->Close();
		MessageBox::Show("Uno de los jugadores quiere salir");
		Close();
		 
		 }
private: System::Void timer1_Tick(System::Object^  sender, System::EventArgs^  e) {
			 if (socket==1){	
		 array<Byte>^recibidos=gcnew array<Byte>(256);

			 sck->Receive(recibidos,0,sck->Available,SocketFlags::None);

			 textBox1->Text=cod->GetString(recibidos);

			 if(textBox1->Text=="s" ){
				 sck->Close();
				MessageBox::Show("Uno de los jugadores quiere salir");
		        Close();
			 }
			 if(textBox1->Text=="O1" ){
				 button1->Text="O";
				 A1='O';
				   button1->Enabled=true;
				   button2->Enabled=true;
				   button3->Enabled=true;
				   button4->Enabled=true;
				   button5->Enabled=true;
				   button6->Enabled=true;
				   button7->Enabled=true;
				   button8->Enabled=true;
				   button9->Enabled=true;
				   turno=1;
				   this->TURNO->Text = L"JUGADOR 2";
			 }
			  if(textBox1->Text=="O2" ){
				 button2->Text="O";
				 A2='O';
				 button1->Enabled=true;
				   button2->Enabled=true;
				   button3->Enabled=true;
				   button4->Enabled=true;
				   button5->Enabled=true;
				   button6->Enabled=true;
				   button7->Enabled=true;
				   button8->Enabled=true;
				   button9->Enabled=true;
				   turno=1;
				   this->TURNO->Text = L"JUGADOR 2";
			 }
			   if(textBox1->Text=="O3" ){
				 button3->Text="O";
				 A3='O';
				button1->Enabled=true;
				   button2->Enabled=true;
				   button3->Enabled=true;
				   button4->Enabled=true;
				   button5->Enabled=true;
				   button6->Enabled=true;
				   button7->Enabled=true;
				   button8->Enabled=true;
				   button9->Enabled=true;
				   turno=1;
				   this->TURNO->Text = L"JUGADOR 2";
			 }
			    if(textBox1->Text=="O4" ){
				 button4->Text="O";
				 B1='O';
				 button1->Enabled=true;
				   button2->Enabled=true;
				   button3->Enabled=true;
				   button4->Enabled=true;
				   button5->Enabled=true;
				   button6->Enabled=true;
				   button7->Enabled=true;
				   button8->Enabled=true;
				   button9->Enabled=true;
				   turno=1;
				   this->TURNO->Text = L"JUGADOR 2";
			 }
			 if(textBox1->Text=="O5" ){
				 button5->Text="O";
				 B2='O';
				button1->Enabled=true;
				   button2->Enabled=true;
				   button3->Enabled=true;
				   button4->Enabled=true;
				   button5->Enabled=true;
				   button6->Enabled=true;
				   button7->Enabled=true;
				   button8->Enabled=true;
				   button9->Enabled=true;
				   turno=1;
				   this->TURNO->Text = L"JUGADOR 2";
			 }
			  if(textBox1->Text=="O6" ){
				 button6->Text="O";
				 B3='O';
				 button1->Enabled=true;
				   button2->Enabled=true;
				   button3->Enabled=true;
				   button4->Enabled=true;
				   button5->Enabled=true;
				   button6->Enabled=true;
				   button7->Enabled=true;
				   button8->Enabled=true;
				   button9->Enabled=true;
				   turno=1;
				   this->TURNO->Text = L"JUGADOR 2";
			 }
			 if(textBox1->Text=="O7" ){
				 button7->Text="O";
				 C1='O';
				 button1->Enabled=true;
				   button2->Enabled=true;
				   button3->Enabled=true;
				   button4->Enabled=true;
				   button5->Enabled=true;
				   button6->Enabled=true;
				   button7->Enabled=true;
				   button8->Enabled=true;
				   button9->Enabled=true;
				   turno=1;
				   this->TURNO->Text = L"JUGADOR 2";
			 }
			  if(textBox1->Text=="O8" ){
				 button8->Text="O";
				 C2='O';
				button1->Enabled=true;
				   button2->Enabled=true;
				   button3->Enabled=true;
				   button4->Enabled=true;
				   button5->Enabled=true;
				   button6->Enabled=true;
				   button7->Enabled=true;
				   button8->Enabled=true;
				   button9->Enabled=true;
				   turno=1;
				   this->TURNO->Text = L"JUGADOR 2";
			 }
			   if(textBox1->Text=="O9" ){
				 button9->Text="O";
				 C3='O';
				button1->Enabled=true;
				   button2->Enabled=true;
				   button3->Enabled=true;
				   button4->Enabled=true;
				   button5->Enabled=true;
				   button6->Enabled=true;
				   button7->Enabled=true;
				   button8->Enabled=true;
				   button9->Enabled=true;
				   turno=1;
				   this->TURNO->Text = L"JUGADOR 2";
			 }
			   
			   if(!(button1->Text=="") ){
				   button1->Enabled=false;
			   }
			   if(!(button2->Text=="") ){
				   button2->Enabled=false;
			   }
			   if(!(button3->Text=="") ){
				   button3->Enabled=false;
			   }
			   if(!(button4->Text=="") ){
				   button4->Enabled=false;
			   }
			   if(!(button5->Text=="") ){
				   button5->Enabled=false;
			   }
			   if(!(button6->Text=="") ){
				   button6->Enabled=false;
			   }
			   if(!(button7->Text=="") ){
				   button7->Enabled=false;
			   }
			   if(!(button8->Text=="") ){
				   button8->Enabled=false;
			   }
			   if(!(button9->Text=="") ){
				   button9->Enabled=false;
			   }
			   
			   Verificador(A1,A2,A3,B1,B2,B3,C1,C2,C3);
			   }
		 }
private: System::Void label2_Click(System::Object^  sender, System::EventArgs^  e) {
		 }
};
}
