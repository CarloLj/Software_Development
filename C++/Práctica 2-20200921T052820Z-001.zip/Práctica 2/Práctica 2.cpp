//Pr�ctica 2 Parcial 3
#include "stdafx.h"
#include <iostream>
#include <math.h>
#include <conio.h>

using namespace std;
int portada(void);

//Comprobador de error double
double leerdouble( )
{
	bool bandera=false;
    double dat=0;

	while(bandera==false)
	{
	   if (!(cin >> dat))
		{
			dat=0;
			cin.clear();
			cin.ignore(99999, '\n');
			cout << "Solo numeros, introduce de nuevo: ";
			dat=0;
			bandera=false;
		}
	   else
		   if (dat<0)
		   {
				cout << "Solo mayores de 0, introduce de nuevo: ";
				dat=0;
				bandera=false;
		   }
		   else
			bandera=true;
   }
    return dat;
}

//Clases
class EMPLEADO{
public:
	//CONTRUCTOR Y DESTRUCTOR
	EMPLEADO(){horaDia=0;horasT=0;pago=0;}
	~EMPLEADO(){};

	virtual void HorasDia()=0;

	double horaDia,horasT, pago, pagoSin, pagoTriple, pagoDoble, dobles, triples;
};

class DIURNO:public EMPLEADO{
private:
	double diurno;
public:
	//CONTRUCTOR Y DESTRUCTOR
	DIURNO(double hd, double p, double pS, double pD, double pT,double d, double t)
	{horaDia=hd;pago=p;diurno=8;pagoDoble=pD;pagoSin=pS;pagoTriple=pT;dobles=d;triples=t;}
	~DIURNO(){};

	void HorasDia(){
		system("cls");
		int cont=0;
		double comp=0.00;

		while(cont<5){
			cout<<"Cuantas horas el dia "<<cont+1<<" ha trabajado."<<endl;
			do{
				horaDia=0.00;
				horaDia=leerdouble();
				if((horaDia>24))
					cout<<"No hay mas de 24 horas en un dia"<<endl;
			}while(horaDia>24);
			
			if(horaDia==diurno){pago+=88.33;pagoSin+=88.33;}
			if(horaDia>diurno){
				pago+=88.33;
				pagoSin+=88.33;
				horaDia=horaDia-diurno;
				comp=dobles;
				if(dobles<=6&&horaDia<=3){
					dobles+=horaDia;
					pago+=(horaDia*(88.33/diurno)*2);
					pagoDoble+=(horaDia*(88.33/diurno)*2);
				}
				else{
					if(comp<9){
						if(horaDia<=3){
							pago+=(((9-comp)*(88.33/diurno)*2));
							pagoDoble+=((9-comp)*(88.33/diurno)*2);
							dobles+=(9-comp);
						}
						else{
							pago+=((3*(88.33/diurno)*2)+((horaDia-3)*(88.33/diurno)*3));
							pagoDoble+=(3*(88.33/diurno)*2);
							pagoTriple+=((horaDia-3)*(88.33/diurno)*3); 
							dobles+=3;
							triples+=(horaDia-3);
						}
					
					}
					if(comp>=9){
						pago+=((horaDia)*(88.33/diurno)*3);
						pagoTriple+=((horaDia)*(88.33/diurno)*3);
						triples+=horaDia;
					}
				}
			}
			cont++;
		}
		cout<<endl<<"Su pago sin horas extra es de $"<<pagoSin<<endl;
		if(dobles>0){
				cout<<"Horas extra dobles "<<dobles<<" Su pago es de $"<<pagoDoble<<endl;

			if(triples>0)
				cout<<"Horas extra triples "<<triples<<" Su pago es de $"<<pagoTriple<<endl;
		}
		cout<<endl<<"Su pago semanal es de $"<<pago<<endl;

	}

};

class NOCTURNO:public EMPLEADO{
private:
	double nocturno;
public:
	//CONTRUCTOR Y DESTRUCTOR
	NOCTURNO(double hd, double p, double pS, double pD, double pT,double d, double t)
	{horaDia=hd;pago=p;nocturno=7;pagoDoble=pD;pagoSin=pS;pagoTriple=pT;dobles=d;triples=t;}
	~NOCTURNO(){};

	void HorasDia(){
		system("cls");
		int cont=0;
		double comp=0.00;

		while(cont<5){
			cout<<"Cuantas horas el dia "<<cont+1<<" ha trabajado."<<endl;
			do{
				horaDia=0.00;
				horaDia=leerdouble();
				if((horaDia>24))
					cout<<"No hay mas de 24 horas en un dia"<<endl;
			}while(horaDia>24);
			
			if(horaDia==nocturno){pago+=88.33;pagoSin+=88.33;}
			if(horaDia>nocturno){
				pago+=88.33;
				pagoSin+=88.33;
				horaDia=horaDia-nocturno;
				comp=dobles;
				if(dobles<=6&&horaDia<=3){
					dobles+=horaDia;
					pago+=(horaDia*(88.33/nocturno)*2);
					pagoDoble+=(horaDia*(88.33/nocturno)*2);
				}
				else{
					if(comp<9){
						if(horaDia<=3){
							pago+=(((9-comp)*(88.33/nocturno)*2));
							pagoDoble+=((9-comp)*(88.33/nocturno)*2);
							dobles+=(9-comp);
						}
						else{
							pago+=((3*(88.33/nocturno)*2)+((horaDia-3)*(88.33/nocturno)*3));
							pagoDoble+=(3*(88.33/nocturno)*2);
							pagoTriple+=((horaDia-3)*(88.33/nocturno)*3);
							dobles+=3;
							triples+=(horaDia-3);
						}
					
					}
					if(comp>=9){
						pago+=((horaDia)*(88.33/nocturno)*3);
						pagoTriple+=((horaDia)*(88.33/nocturno)*3);
						triples+=horaDia;
					}
				}
			}
			cont++;
		}
		cout<<endl<<"Su pago sin horas extra es de $"<<pagoSin<<endl;
		if(dobles>0){
				cout<<"Horas extra dobles "<<dobles<<" Su pago es de $"<<pagoDoble<<endl;

			if(triples>0)
				cout<<"Horas extra triples "<<triples<<" Su pago es de $"<<pagoTriple<<endl;
		}
		cout<<endl<<"Su pago semanal es de $"<<pago<<endl;

	}
};

class MIXTO:public EMPLEADO{
private:
	double mixto;
public:
	//CONTRUCTOR Y DESTRUCTOR
	MIXTO(double hd, double p, double pS, double pD, double pT,double d, double t)
	{horaDia=hd;pago=p;mixto=7.5;pagoDoble=pD;pagoSin=pS;pagoTriple=pT;dobles=d;triples=t;}
	~MIXTO(){};

	void HorasDia(){
		system("cls");
		int cont=0;
		double comp=0.00;

		while(cont<5){
			cout<<"Cuantas horas el dia "<<cont+1<<" ha trabajado."<<endl;
			do{
				horaDia=0.00;
				horaDia=leerdouble();
				if((horaDia>24))
					cout<<"No hay mas de 24 horas en un dia"<<endl;
			}while(horaDia>24);
			
			if(horaDia==mixto){pago+=88.33;pagoSin+=88.33;}
			if(horaDia>mixto){
				pago+=88.33;
				pagoSin+=88.33;
				horaDia=horaDia-mixto;
				comp=dobles;
				if(dobles<=6&&horaDia<=3){
					dobles+=horaDia;
					pago+=(horaDia*(88.33/mixto)*2);
					pagoDoble+=(horaDia*(88.33/mixto)*2);
				}
				else{
					if(comp<9){
						if(horaDia<=3){
							pago+=(((9-comp)*(88.33/mixto)*2));
							pagoDoble+=((9-comp)*(88.33/mixto)*2);
							dobles+=(9-comp);
						}
						else{
							pago+=((3*(88.33/mixto)*2)+((horaDia-3)*(88.33/mixto)*3));
							pagoDoble+=(3*(88.33/mixto)*2);
							pagoTriple+=((horaDia-3)*(88.33/mixto)*3); 
							dobles+=3;
							triples+=(horaDia-3);
						}
					
					}
					if(comp>=9){
						pago+=((horaDia)*(88.33/mixto)*3);
						pagoTriple+=((horaDia)*(88.33/mixto)*3);
						triples+=horaDia;
					}
				}
			}
			cont++;
		}
		cout<<endl<<"Su pago sin horas extra es de $"<<pagoSin<<endl;
		if(dobles>0){
				cout<<"Horas extra dobles "<<dobles<<" Su pago es de $"<<pagoDoble<<endl;

			if(triples>0)
				cout<<"Horas extra triples "<<triples<<" Su pago es de $"<<pagoTriple<<endl;
		}
		cout<<endl<<"Su pago semanal es de $"<<pago<<endl;

	}

};

int main()
{
	portada();
	return 0;
}

int portada(){
	char quehacer;
	do{
		system("cls");
		cout << "____________________________________________________" << endl;
		cout << "::::     Bienvenido al programa de salarios!    ::::" << endl;
		cout << "____________________________________________________" << endl;
		cout << "::::::::::::::::::::::::MENU::::::::::::::::::::::::" << endl;
		cout << "____________________________________________________" << endl;
		cout << "::::  A) Entrar al programa                     ::::" << endl;
		cout << "::::  B) Salir    <ESC>                         ::::" << endl;
		cout << "____________________________________________________" << endl;
		cout << "-> ";
		quehacer = _getch();
	      switch ((quehacer)){

			 case 'A':case 'a':
				char opc;
				EMPLEADO *reg[3];
				do{
				 system("cls");
				 cout << "____________________________________________________" << endl;
				 cout << "::::          Ingrese tipo de empleado          ::::" << endl;	
				 cout << "____________________________________________________" << endl;
				 cout << "::::  A) Diurno                                 ::::" << endl;
				 cout << "::::  B) Nocturno                               ::::" << endl;
				 cout << "::::  C) Mixto                                  ::::" << endl;
				 cout << "____________________________________________________" << endl;
				 opc = _getch();
				 switch(opc){
				 case 'a':case'A':{
					 reg[0]= new DIURNO(0,0,0,0,0,0,0);
					 reg[0]->HorasDia();
					 cout << "::::           Salario registrado           ::::" << endl;
					 system("pause");
					 break;}

				 case 'b':case 'B':{
					 reg[1]= new NOCTURNO(0,0,0,0,0,0,0);
					 reg[1]->HorasDia();
					 cout << "::::           Salario registrado           ::::" << endl;
					 system("pause");
					 break;}

				case 'c':case 'C':{
					reg[2]= new MIXTO(0,0,0,0,0,0,0);
					reg[2]->HorasDia();
					cout << "::::           Salario registrado           ::::" << endl;
					system("pause");
					break;}

				default:cout<<"Opcion no existente"<<endl;opc='h';
				 }
				}while(opc=='h');
			 break;

			 case 'B':case 'b': case 27:
				 return 0;
			 default:break;
		  }
	}while(quehacer != 'B');
	return 0;
}
