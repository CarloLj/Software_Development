// ConsoleApplication1.cpp: define el punto de entrada de la aplicaci�n de consola.
//

#include "stdafx.h"
#include <iostream>
#include <math.h>
#include <conio.h>

using namespace std;

//Comprobador de error double
double leerdouble( )
{
	bool bandera=false;
    double dat=0;

	while(bandera==false)
	{
	   if (!(cin >> dat))
		{
			dat=0;
			cin.clear();
			cin.ignore(99999, '\n');
			cout << "Solo numeros, introduce de nuevo: ";
			dat=0;
			bandera=false;
		}
	   else
		   if (dat==0)
		   {
				cout << "Solo mayores de 0, introduce de nuevo: ";
				dat=0;
				bandera=false;
		   }
		   else
			bandera=true;
   }
    return dat;
}

class EMPLEADO{
public:
	//CONTRUCTOR Y DESTRUCTOR
	EMPLEADO(){horaDia=0;horasT=0;pago=0;}
	~EMPLEADO(){};

	virtual void Pago()=0;
	virtual void HorasDia()=0;

	double horaDia,horasT, pago;
};

class DIURNO:public EMPLEADO{
public:
	//CONTRUCTOR Y DESTRUCTOR
	DIURNO(double hd, double ht, double p){horaDia=hd;horasT=ht;pago=p;}
	~DIURNO(){};

	void HorasDia(){
		system("cls");
		int cont=0;
		double comp=0.00;

		while(cont<5){
			//Introduce las horas por dia
			cout<<"Cuantas horas el d�a "<<cont+1<<" ha trabajado."<<endl;
			do{
				horaDia=leerdouble();
				cout<<"No hay mas de 24 horas en un dia"<<endl;
			}while(horaDia>24);

			//Suma a horas totales
			//horasT+=horaDia;
			
			if(horaDia==8){pago+=88.33;}
			if(horaDia>8){
				pago+=88.33;
				horaDia-=8;
				comp=horasT;
				horasT+=horaDia;
				if(horasT<=9){
					pago+=(horaDia*88.33*2);
				}
				else{
					if(comp<9){
					pago+=(((9-comp)*88.33*2)+((horaDia-(9-comp))*88.33*3));
					}
					if(comp>=9){
					pago+=((horaDia)*88.33*3);
					}
				}
			}
			cont++;
		}

		cout<<"Su pago semanal es de $"<<pago<<endl;

	}

};

class NOCTURNO:public EMPLEADO{
public:
	//CONTRUCTOR Y DESTRUCTOR
	NOCTURNO(double hd, double ht, double p){horaDia=hd;horasT=ht;pago=p;}
	~NOCTURNO(){};

	void HorasDia(){

	}
	void Pago(){

	}
};

class MIXTO:public EMPLEADO{
public:
	//CONTRUCTOR Y DESTRUCTOR
	MIXTO(double hd, double ht, double p){horaDia=hd;horasT=ht;pago=p;}
	~MIXTO(){};

	void HorasDia(){

	}
	void Pago(){

	}
};

int portada(void);

int main()
{
	portada();
	return 0;
}

int portada(){
	char quehacer;
	do{
		system("cls");
		cout << "____________________________________________________" << endl;
		cout << "::::     Bienvenido al programa de salarios!    ::::" << endl;
		cout << "____________________________________________________" << endl;
		cout << "::::::::::::::::::::::::MENU::::::::::::::::::::::::" << endl;
		cout << "____________________________________________________" << endl;
		cout << "::::  A) Entrar al programa                     ::::" << endl;
		cout << "::::  B) Salir    <ESC>                         ::::" << endl;
		cout << "____________________________________________________" << endl;
		cout << "-> ";
		quehacer = _getch();
	      switch ((quehacer)){

			 case 'A':case 'a':
				char opc;
				do{
				 system("cls");
				 cout << "____________________________________________________" << endl;
				 cout << "::::          Ingrese tipo de empleado          ::::" << endl;	
				 cout << "____________________________________________________" << endl;
				 cout << "::::  A) Diurno                                 ::::" << endl;
				 cout << "::::  B) Nocturno                               ::::" << endl;
				 cout << "::::  C) Mixto                                  ::::" << endl;
				 cout << "____________________________________________________" << endl;
				 switch(opc){
				 }
				}while()
			 break;

			 case 'B':case 'b': case 27:
				 return 0;
			 default:break;
		  }
	}while(quehacer != 'B');
}


