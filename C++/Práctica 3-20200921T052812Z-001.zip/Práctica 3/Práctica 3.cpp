#include "stdafx.h"
#include <iostream>
#include <windows.h>
#include <conio.h>
#include <string>
#include <limits>  
#include <iomanip>

using namespace std;

void LeeDatosRefCon(int producto2);
void LeeDatosCongelado(int producto3);

void gotoxy(int x, int y)
{
    COORD coord;
    coord.X = x;
    coord.Y = y;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}

//Comprobador de error int
int leerint( )
{
	bool bandera=false;
    int dat=0;

	while(bandera==false)
	{
	   if (!(cin >> dat))
		{
			dat=0;
			cin.clear();
			cin.ignore(99999, '\n');
			cout << "Solo numeros, introduce de nuevo: ";
			dat=0;
			bandera=false;
		}
	   else
		   if (dat==0)
		   {
				cout << "Solo numeros, introduce de nuevo: ";
				dat=0;
				bandera=false;
		   }
		   else
			bandera=true;
   }
    return dat;
}
//Comprobador de error float
float leerfloat( )
{
	bool bandera=false;
    float dat=0;

	while(bandera==false)
	{
	   if (!(cin >> dat))
		{
			dat=0;
			cin.clear();
			cin.ignore(99999, '\n');
			cout << "Solo numeros, introduce de nuevo: ";
			dat=0;
			bandera=false;
		}
	   else
		   if (dat==0)
		   {
				cout << "Solo numeros, introduce de nuevo: ";
				dat=0;
				bandera=false;
		   }
		   else
			bandera=true;
   }
    return dat;
}

//TIPOS DE CONGELADO
class C_POR_AIRE{
private:
	float perN2;
	float perO2;
	float perCO2;
	float perVapor;
public:
	void FijaPorcenteje(float,float,float,float);
	void EtiquetaAire();

	C_POR_AIRE(){}
	~C_POR_AIRE(){}
};

void C_POR_AIRE::FijaPorcenteje(float _perN2,float _perO2,float _perCO2,float _perVapor)
{
	this->perN2=_perN2;
	this->perO2=_perO2;
	this->perCO2=_perCO2;
	this->perVapor=_perVapor;
}

void C_POR_AIRE::EtiquetaAire(){
	cout<<"CONGELACION POR AIRE"<<endl<<endl;
	cout<<"Nitrogeno: "<< fixed << setprecision(3) <<perN2<<"%"<<endl;
	cout<<"Oxigeno: "<< fixed << setprecision(3) <<perO2<<"%"<<endl;
	cout<<"Dioxido de carbono: "<< fixed << setprecision(3) <<perCO2<<"%"<<endl;
	cout<<"Vapor de agua: "<< fixed << setprecision(3) <<perVapor<<"%"<<endl<<endl;
}

class C_POR_AGUA{
private:
	float sal;
	float agua;
	float salinidad;
public:
	void FijaAguaSal(float,float);
	void EtiquetaAgua();

	C_POR_AGUA(){}
	~C_POR_AGUA(){}
};

void C_POR_AGUA::FijaAguaSal(float _agua,float _sal){
	this->agua=_agua;
	this->sal=_sal;
	salinidad=sal/agua;
}

void C_POR_AGUA::EtiquetaAgua(){
	cout<<"CONGELACION POR AGUA"<<endl<<endl;
	cout<<"Salinidad del agua: "<< fixed << setprecision(3) <<salinidad<<"grm/lit"<<endl<<endl;
}

class C_POR_NITROGENO{
private:
	string info;
	float tiempo;
public:
	void FijaTiempo(float);
	void FijaInfo(string);
	void EtiquetaNitrogeno();

	C_POR_NITROGENO(){}
	~C_POR_NITROGENO(){}
};

void C_POR_NITROGENO::FijaTiempo(float _tiempo){
	this->tiempo=_tiempo;
}
void C_POR_NITROGENO::FijaInfo(string _info){
	this->info=_info;
}

void C_POR_NITROGENO::EtiquetaNitrogeno(){
	cout<<"CONGELACION POR NITROGENO"<<endl<<endl;
	cout<<"Informacion del metodo de congelacion empleado:"<<endl;
	cout<<info<<endl<<endl;
	cout<<"Tiempo de exposicion al nitrogeno: "<< fixed << setprecision(3) <<tiempo<<" s"<<endl;
}

//FIN TIPOS DE CONGELADO

//GENERAL

class PRODUCTOS
{
public:
	void FijaCaducidad( int, int, int );
	void FijaLote( int );
	void FechaEnvasado( int, int, int );
	void FijaPais (string);
	void FijaEspecie (int);
	void FijaProducto(int);

	void EtiquetaProductos();

	PRODUCTOS(){
		pro[0]="Fresco";pro[1]="Refrigerado";pro[2]="Congelado";
		esp[0]="Gallus";esp[1]="Guajolote";esp[2]="Ganso";esp[3]="Pato";esp[4]="Codorniz";
	}
	~PRODUCTOS(){}
protected:
	int caddd, cadmm, cadaa;
	int sLote;
	int envdd, envmm, envaa; 
	string paisOrigen;
	int especie;
	string esp[5];
	int producto;
	string pro[3];
};
	//Fijar
void PRODUCTOS::FijaProducto(int _producto){
	producto=_producto;
}
void PRODUCTOS::FijaEspecie (int _especie){
	this->especie = _especie;
}
void PRODUCTOS::FijaPais (string _paisOrigen){
	this->paisOrigen = _paisOrigen;
}
void PRODUCTOS::FijaCaducidad( int d, int m, int a )
{
	this->caddd = d;
	this->cadmm = m;
	this->cadaa = a;
}
void PRODUCTOS::FijaLote( int _sLote )
{
	 this->sLote= _sLote ;
}
void PRODUCTOS::FechaEnvasado( int d, int m, int a )
{
	this->envdd = d;
	this->envmm = m;
	this->envaa = a;
}

void PRODUCTOS::EtiquetaProductos(){
	cout<<"Producto: "<<pro[producto-1]<<endl<<endl;
	cout<<"Especie: "<<esp[especie-1]<<endl;
	cout<<"Fecha de caducidad: "<<caddd<<"/"<<cadmm<<"/"<<cadaa<<endl;
	cout<<"Numero de lote: "<<sLote<<endl;
	cout<<"Pais de origen: "<<paisOrigen<<endl;
	cout<<"Fecha de envasado: "<<envdd<<"/"<<envmm<<"/"<<envaa<<endl<<endl;
}
//FIN GENERAL

//CONGELADO Y REFRIGERADO
class TEMPERATURA
{
private:
	int temperatura;
	string Descripcion[2];
public:

	void FijaTemp(int);

	void EtiquetaTemperatura();

	TEMPERATURA(){
		Descripcion[0]="De refrigeracion de 0 a 4�C.";
		Descripcion[1]="De congelacion de -18�C, en el punto frio.";
	}
	~TEMPERATURA(){}
};
void TEMPERATURA::FijaTemp(int _temperatura)
{
	this->temperatura=_temperatura;
}

void TEMPERATURA::EtiquetaTemperatura(){
	cout<<"Temperatura de mantenimiento recomendada: "<<Descripcion[temperatura-1]<<endl<<endl;
}

class CONGELADO_REFRIGERADO:public PRODUCTOS, public TEMPERATURA, public C_POR_AGUA,public C_POR_AIRE, public C_POR_NITROGENO
{
private:
	string codigo;
	bool bEntero;
	int  nTipoCong;
public:
	bool ProdEntero( void ) { return( bEntero );	};
	void Trozar( void ){ bEntero = FALSE; };
	void FijarCodigo(string);
	void FijaTipoCong( int );
	
	void EtiquetaRefrigeradoCongelado( int);
	
	CONGELADO_REFRIGERADO()
	{
		bEntero = TRUE;	
	}
	~CONGELADO_REFRIGERADO(){}

};

void CONGELADO_REFRIGERADO::FijarCodigo(string _codigo){
	this->codigo=_codigo;
}
void CONGELADO_REFRIGERADO:: FijaTipoCong( int t )
{
	this->nTipoCong = t;
}

void CONGELADO_REFRIGERADO::EtiquetaRefrigeradoCongelado(int producto3)
{
	cout <<"Forma de empaquetado: "<< ( ( bEntero ) ? " ENTERO" : " A TROZOS" )<<endl;

	if (producto3==2)
		cout<<"C�digo del organismo de supervisi�n alimentaria: "<<endl<<codigo<<endl<<endl;
	else{
		if (producto3==3){
			if(nTipoCong==1)
				EtiquetaAire();
			if(nTipoCong==2)
				EtiquetaAgua();
			if(nTipoCong==3)
				EtiquetaNitrogeno();
		}
	}
}
//FIN CONGELADO Y REFRIGERADO


//ETIQUETA
class ETIQUETA: public CONGELADO_REFRIGERADO
{
public:
	void MostrarDatos(int);

	ETIQUETA(){}
	~ETIQUETA(){}
};

void ETIQUETA::MostrarDatos(int producto){
	system ("cls");
	cout<<"				ETIQUETA"<<endl<<endl;
	EtiquetaProductos();
	if (producto==2||producto==3){
		EtiquetaTemperatura();
		EtiquetaRefrigeradoCongelado(producto);
	}
}


ETIQUETA instancia;
//FIN ETIQUETA


void portada()
{
 system("cls");
    cout << "____________________________________________________" << endl;
    cout << "::::       Productos avicolas S.A. de C.V       ::::" << endl;
    cout << "____________________________________________________" << endl;
    cout << "::::::::::::::::::::::::MENU::::::::::::::::::::::::" << endl;
    cout << "____________________________________________________" << endl;
    cout << "::::  A) Entrar al programa                     ::::" << endl;
 	cout << "::::  B) Salir    <ESC>                         ::::" << endl;
    cout << "____________________________________________________" << endl;
}

//LEE DATOS GENERALES
void LeeDatos()
{
	system("cls");
	bool autorizador=false;
	int producto=0;
	int especie=0;
    int dia=0, mes=0, agno=0;
	int lote=0;
    int nTipoAve=0, nTipoProducto=0;
	string paisO;

	cout << "Ingrese producto" << endl<<"[1] Fresco"<<endl<<"[2] Refrigerado"<<endl<<"[3] Congelado"<<endl<<endl;
	autorizador=false;
	do{
	producto=leerint();
	if(!(producto<=3&&producto>=1))
		cout << "Ingrese opcion existente" << endl<<endl;
	else
		autorizador=true;
	}while(autorizador==false);
	instancia.FijaProducto(producto);
	system("cls");

	cout << "Ingrese la especie" << endl<<"[1] Gallus"<<endl<<"[2] Guajolote"<<endl<<"[3] Ganso"<<endl<<"[4] Pato"<<endl<<"[5] Codorniz"<<endl<< endl;
	autorizador=false;
	do{
	especie=leerint();
	if(!(especie<=5&&especie>=1))
		cout << "Ingrese opcion existente" << endl<<endl;
	else
		autorizador=true;
	}while(autorizador==false);
	instancia.FijaEspecie(especie);
	system("cls");

  	cout << "Ingrese la fecha de caducidad de su producto" << endl;
  	cout << endl;
  	cout << "Dia ";
  	do{
		dia=leerint();
		if (dia>31)
			cout<<"Ingrese dia real"<<endl;
	}while (dia>31);
  	cout << "Mes ";
	do{
		mes=leerint();
		if (mes>12)
			cout<<"Ingrese mes real"<<endl;
		if (mes==12&&dia>29){
			cout<<"Febrero solo tiene 28 o 29 dias. Ingresa otro mes."<<endl;
		}
  	cout << "Anio ";
	do{
		agno=leerint();
		if (agno>9999)
			cout<<"Ingrese anio real"<<endl;
	}while (agno>9999);
  	instancia.FijaCaducidad( dia, mes, agno );
	system("cls");

	cout << "Ingrese no. de lote del producto" << endl<<endl;
	lote=leerint();
	instancia.FijaLote(lote);
	system("cls");

	dia=0; mes=0; agno=0;
	cout << "Ingrese fecha de envasado" << endl;
	cout << endl;
  	cout << "Dia ";
	do{
		dia=leerint();
		if (dia>31)
			cout<<"Ingrese dia real"<<endl;
	}while (dia>31);
  	cout << "Mes ";
	do{
		mes=leerint();
		if (mes>12)
			cout<<"Ingrese mes real"<<endl;
		if (mes==12&&dia>29){
			cout<<"Febrero solo tiene 28 o 29 dias. Ingresa otro mes."<<endl;
		}
	}while (mes>12);
  	cout << "Anio ";
	do{
		agno=leerint();
		if (agno>9999)
			cout<<"Ingrese anio real"<<endl;
	}while (agno>9999);
	instancia.FechaEnvasado(dia, mes, agno);
	system("cls");

	cout << "Ingrese pais de origen" << endl<<endl;
	cin>>paisO;
	instancia.FijaPais(paisO);
	system("cls");

    if(producto==2||producto==3)
		LeeDatosRefCon(producto);
	else
		instancia.MostrarDatos(producto);
}

//LEE DATOS DE REFRIGERADOS Y CONGELADOS
void LeeDatosRefCon(int producto2){
	char nTrozado = 'S';
    int Salir=0;	
	int temperatura=0;
	string codigo;

	if (producto2==2)
		temperatura=0;
	else
		temperatura=1;
	instancia.FijaTemp(temperatura);

	do {
		cout << "El ave esta Entera?  (S/N) "<<endl;
		cin.ignore();
		nTrozado = _getch();
		if ( toupper(nTrozado) == 'N' ){
			instancia.Trozar();
			Salir = 1;
		}
		else {
			if ( toupper(nTrozado) == 'S'){
				Salir = 1;
			}
			else {
				cout << "Error solo S o N" << endl;
			}
		}	
	} while ( Salir == 0 );
	system("cls");

	if (producto2==2){
		cout << "Ingrese codigo de organismo de supervision alimentaria" << endl<<endl;
		cin>>codigo;
		instancia.FijarCodigo(codigo);
		system("cls");
		instancia.MostrarDatos(producto2);
	}
	else
		LeeDatosCongelado(producto2);

}

void LeeDatosCongelado(int producto3)
{
	bool autorizador2=false;
	int congelado=0;
	float N2=0,O2=0,CO2=0,Vap=0;
	float gSal=0,lAgua=0;
	string info;
	float seg=0;

	cout << "Ingrese tipo de congelacion" << endl<<"[1] Aire"<<endl<<"[2] Agua"<<endl<<"[3] Nitrogeno"<<endl<<endl;
	autorizador2=false;
	do{
	congelado=leerint();
	if(!(congelado<=3&&congelado>=1))
		cout << "Ingrese opcion existente" << endl<<endl;
	else
		autorizador2=true;
	}while(autorizador2==false);
	instancia.FijaTipoCong(congelado);
	system("cls");

	//POR AIRE
	if(congelado==1){
		autorizador2=false;
		cout << "Informaci�n de la composici�n del aire con que fue congelado" << endl<<endl;
  		do{
			cout << "% de nitrogeno ";
  			N2=leerfloat();
  			cout << "% de oxigeno ";
  			O2=leerfloat();
  			cout << "% de dioxio de carbono ";
  			CO2=leerfloat();
			cout << "% de vapor";
  			Vap=leerfloat();
  			if ((N2+CO2+O2+Vap)>100)
				cout << "El porcentaje da mas de 100%"<<endl;
			else{
				if ((N2+CO2+O2+Vap)<100)
					cout << "El porcentaje da menos de 100%"<<endl;
				else
					autorizador2=true;
			}

		}while (autorizador2==false);
		instancia.FijaPorcenteje( N2, O2, CO2, Vap );
		system("cls");
	}

	//POR AGUA
	if(congelado==2){
		cout << "Ingrese salinidad del agua" << endl<<endl;
		cout << "Gramos de sal ";
  		gSal=leerfloat();
  		cout << "Litros de agua ";
  		lAgua=leerfloat();
		instancia.FijaAguaSal(gSal,lAgua);
		system("cls");
	}

	//POR NITROGENO
	if(congelado==3){
		cout << "Ingrese informacion del metodo de congelacion empleado" << endl<<endl;
		cin>>info;
		instancia.FijaInfo(info);
		
		cin.ignore();
		cout <<endl<< "Ingrese tiempo de exposici�n al nitr�geno expresado en segundos" << endl<<endl;
		seg=leerfloat();
		instancia.FijaTiempo(seg);
		system("cls");
	}
	instancia.MostrarDatos(producto3);
}

int main()
{
    //Fuera del menu
    int total=0;
    

    char menu=0;

 	portada();
    
	do {
   		menu = _getch();
        switch (menu){
          
          case 'A':
		  case 'a':{
				int Correcto=0;
				do{
					LeeDatos();
					cout<<endl<<"Los datos son correctos?"<<endl<<"[1]Si"<<endl<<"[2]No"<<endl;
					Correcto=leerint();
					while(!(Correcto>0&&Correcto<=2)){
						cout<<"Elegir opcion existente"<<endl;
						Correcto=leerint();
					}
					system("cls");
					if (Correcto==1){
						cout<<"Etiqueta guardada"<<endl;
            			system("PAUSE");
						return 0;
					}
				}while(Correcto!=1);
            break;}

          case 'B':
		  case 'b':
          case 27:{
           		system("cls");
         		return 0;
            	}
        	default:
            	gotoxy(8, 10);
         		cout<<"Su opcion no es valida, seleccione <ESC>, A o B"<<endl;
        	break;
       }
 }while(menu != 'B');
	

return 0;
 
}