// ConsoleApplication1.cpp: define el punto de entrada de la aplicaci�n de consola.
//

#include "stdafx.h"
#include <iostream>
#include <conio.h>
#include <string>
#include <limits>

using namespace std;

//Variable global
bool verificador=false;

class LISTA_CALIFICACIONES
{
public:
	int numeroLista;
	void IngresarDatos();
	void MostrarDatos();
	void ListaRegistrados();
	string nombreMateria[9];
	LISTA_CALIFICACIONES();
	~LISTA_CALIFICACIONES();

private:
	string nombreAlumno;
	float calificacionMateria[9];

}*puntero = new LISTA_CALIFICACIONES[18];

//Ingreso de datos
void LISTA_CALIFICACIONES::IngresarDatos()
{
	verificador=false;
	cin.ignore();0
	cout<<"	Nombre del alumno"<<endl<<"	";
	getline(cin,nombreAlumno);
	cout<<endl<<"	Calificacion del alumno sobre 100 por materia"<<endl<<endl;
	for (int a=0;a<9;a++)
	{
		verificador=false;
		do
		{
			calificacionMateria[a]=0;
			cout<<nombreMateria[a]<<": ";
			cin>>calificacionMateria[a];
			if (0<=calificacionMateria[a]&&calificacionMateria[a]<=100)
			{
				verificador=true;
			}
			else
			{
				cout<<endl<<"Numero no valido, vuelva a insertar."<<endl;
				verificador=false;
			}
		}while (verificador==false);
	}
}
void LISTA_CALIFICACIONES::MostrarDatos()
{
	
	cout<<"			Registro #"<<numeroLista<<endl;
	cout<<endl<<"Nombre del alumno:"<<nombreAlumno<<endl<<endl;
	for(int i=0;i<9;i++)
{
	cout<<this->nombreMateria[i]<<": "<<this->calificacionMateria[i]<<endl;
}
system("pause");
	system("cls");

}
void LISTA_CALIFICACIONES::ListaRegistrados(){
	cout<<"	Registro #"<<numeroLista<<"   "<<"Nombre del alumno: "<<nombreAlumno<<endl;
}

//Constructor y destructor
LISTA_CALIFICACIONES::LISTA_CALIFICACIONES()
{
	nombreMateria[0] = "PROGRAMACION ORIENTADA A OBJETOS-";
	nombreMateria[1] = "TEMAS DE ELECTRONICA II----------";
	nombreMateria[2] = "SISTEMAS DIGITALES II------------";
	nombreMateria[3] = "ANALISIS Y DISENO DE SISTEMAS----";
	nombreMateria[4] = "INFRAESTRUCTURA DE REDES LOCALES-";
	nombreMateria[5] = "INGLES IV------------------------";
	nombreMateria[6] = "MATEMATICAS IV-------------------";
	nombreMateria[7] = "FISICA IV------------------------";
	nombreMateria[8] = "ECOLOGIA-------------------------";
}

LISTA_CALIFICACIONES::~LISTA_CALIFICACIONES()
{
	
}

int leerint(){
	int x;
	while (true){
		cin>>x;
		if(cin.good()){
			cin.ignore();
			return x;
		}
		else if(cin.fail()){
			cout<<"Solo se permite ingresar numeros enteros!"<<endl;

			cin.clear();
			cin.ignore(numeric_limits<int>::max(),'\n');
		}
	}
}
int main()
{
	//Fuera del menu
	int total=0;
	char menu;
		int ent=0;
		int numero=0;
		do {
		system("cls");
		cout << "____________________________________________________" << endl;
		cout << "::::             REGISTRO DE ALUMNOS            ::::" << endl;
		cout << "____________________________________________________" << endl;
		cout << "::::::::::::::::::::::::MENU::::::::::::::::::::::::" << endl;
		cout << "____________________________________________________" << endl;
		cout << "::::  A) Anadir ALUMNO                          ::::" << endl;
		cout << "::::  B) Mostrar ALUMNO                         ::::" << endl;
		cout << "::::  C) Mostrar REGISTRO                       ::::" << endl;
		cout << "::::  D) SALIR                                  ::::" << endl;
		cout << "____________________________________________________" << endl;

		menu = _getch();
		switch (menu){
		case 'A':
				verificador=false;

	if(total<18)
	{
		//Introduccion y validacion de numero de datos
		do
		{
			cout<<"�Cuantos alumnos desea ingresar?"<<endl;
			cin>>ent;
			if ((ent+total)>18)
			{
				cout<<"Quedan "<<18-total<<" espacios disponibles, vuelve a introducir."<<endl;
				ent=0;
			}
			else
			{
				if (ent<0)
				{
					cout<<"Poner solo numeros positivos, vuelva a introducir"<<endl;
					ent=0;
				}
				else
					verificador=true;
			}
		} while(verificador==false);
		
		//Introduccion de datos
		for(int i=0;i<ent;i++)
		{
			puntero[total].numeroLista=(total+1);
			cout<<endl<<endl<<"			Registro #"<<puntero[total].numeroLista<<endl<<endl;
			puntero[total].IngresarDatos();
			total++;
		}
	}
	else
		cout<<"Ya no hay espacio disponible."<<endl;
			system("pause");
		break;

		case 'B':

int nCual;
verificador=false;
 do
 {
  cout<<"�Que numero de lista desea consultar?"<<endl;

  nCual=leerint();



  if((0<nCual)&&(nCual<=18)&&(nCual<=total))
   verificador=true;
  else
   cout<<"Numero no valido, vuelva a introducir"<<endl;
 }while(verificador==false);
	puntero[nCual-1].MostrarDatos();

		break;

		case 'C':

			cout<<endl;
			for (int i = 0; i < total; i++)
			{
			puntero[i].ListaRegistrados();
			}
			cout<<endl<<endl<<endl;
			system("pause");
		break;

		case 'D':
			return 0;
			break;

		default:
			cout<<"INGRESA UN CARACTER VALIDO!"<<endl;	
			system("pause");
		}

	}while( menu!='D');


	//Dentro de la opcion

//Fuera del menu, al final
	//delete puntero;
	return 0;
}



